﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
using marioFrameWork.collisions;
namespace marioFrameWork.collisions
{
    public class fireEnemyCollision : IAction
    {
        public void performAction(Game game, GameObjects source1, GameObjects source2)
        {
            GameObjects Enemy;
            if (source1.Type == MyEnumTypes.fireEnemy)
            {
                Enemy = source1;
            }
            else
            {
                Enemy = source2;
            }
            game.riseEnemyHealthDec(Enemy);
        }
    }
}
