﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
namespace marioFrameWork.collisions
{
    public class playerCollision : IAction 
    {
        public void performAction(Game game , GameObjects source1, GameObjects source2)
        {
            GameObjects player;
            if (source1.Type == MyEnumTypes.player)
            {
                player = source1;
            }
            else
            {
                player = source2;
            }
            game.risePlayerHealthDec(player);
        }
    }
}
