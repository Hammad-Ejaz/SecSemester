﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.collisions;
using marioFrameWork.Core;
using marioFrameWork.Movements;
namespace marioFrameWork.collisions
{
    public class Collision
    {
        private MyEnumTypes g1;
        private MyEnumTypes g2;
        private IAction behaviour;
        public Collision(MyEnumTypes g1, MyEnumTypes g2, IAction behaviour)
        {
            this.g1 = g1;
            this.g2 = g2;
            this.Behaviour = behaviour;
        }
        public MyEnumTypes G1 { get => g1; set => g1 = value; }
        public MyEnumTypes G2 { get => g2; set => g2 = value; }
        public IAction Behaviour { get => behaviour; set => behaviour = value; }
    }
}
