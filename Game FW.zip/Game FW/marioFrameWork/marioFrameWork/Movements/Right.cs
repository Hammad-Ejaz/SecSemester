﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace marioFrameWork.Movements
{
    public class Right : Imovement
    {
        private int speed;
        public Right(int speed)
        {
            this.speed = speed;
        }
        public Point move(Point location)
        {
            location.X += speed;
            return location;
        }
    }
}
