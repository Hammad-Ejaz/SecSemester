﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace marioFrameWork.Movements
{
    public class Horizontal : Imovement
    {
        private int speed;
        private int start;
        private int end;
        private string direction;
        public Horizontal(int speed , int start , int end , string direction)
        {
            this.speed = speed;
            this.start = start;
            this.end = end;
            this.direction = direction;
        }
        public Point move(Point location)
        {
            if (location.X >= end) direction = "left";
            else if (location.X + speed <= start) direction = "right";
            if (direction == "left") location.X -= speed;
            else if (direction == "right") location.X += speed;
            return location;
        }
    }
}
