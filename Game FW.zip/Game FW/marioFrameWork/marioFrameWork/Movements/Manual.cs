﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using EZInput;
using System.Windows.Forms;
using Point = System.Drawing.Point;

namespace marioFrameWork.Movements
{
    public class Manual : Imovement
    {
        private int speed;
        private Rectangle boundary;
        public Manual(int speed , Rectangle boundary)
        {
            this.speed = speed;
            this.boundary = boundary;
        }
        public Point move(Point location)
        {

            if (Keyboard.IsKeyPressed(Key.UpArrow))
            {
                if ((location.Y - speed) >= boundary.Top)

                {
                    location.Y -= speed;
                }
            }
            if (Keyboard.IsKeyPressed(Key.DownArrow))
            {
                if((location.Y + 70 + speed) < boundary.Bottom)
                    location.Y += speed;
            }
            if (Keyboard.IsKeyPressed(Key.LeftArrow))
            {
                if (boundary.Left < location.X - speed)
                    location.X -= speed;
            }
            if (Keyboard.IsKeyPressed(Key.RightArrow))
            {
                if (boundary.Right > (location.X + speed + 30)) 
                    location.X += speed;
            }
            return location;
        }
    }
}
