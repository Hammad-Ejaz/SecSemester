﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace marioFrameWork.Movements
{
    public class Left : Imovement
    {
        private int speed;
        public Left(int speed)
        {
            this.speed = speed;
        }
        public Point move(Point location)
        {
            location.X -= speed;
            return location;
        }
    }
}
