﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
namespace marioFrameWork.Movements
{
    public class Vertical : Imovement
    {
        private int speed;
        private int start;
        private int end;
        private string direction;
        public Vertical(int speed, int start , int end, string direction)
        {
            this.speed = speed;
            this.start = start;
            this.end = end;
            this.direction = direction;
        }
        public Point move(Point location)
        {
            if (location.Y >= end) direction = "up";
            if (location.Y + speed <= start) direction = "down";
            if (direction == "up") location.Y -= speed;
            else if(direction == "down")location.Y += speed;
            return location;
        }
    }
}
