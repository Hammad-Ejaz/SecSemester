﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clock
{
    class clocktype
    {
        public clocktype()
        {
            sec = 0;
            min = 0;
            hour = 0;
        }
        public clocktype(int s)
        {
            sec = s;
        }
        public clocktype(int s , int m)
        {
            sec = s;
            min = m;
        }
        public clocktype(int s, int m , int h)
        {
            sec = s;
            min = m;
            hour = h;
        }
        public int elapsedTime()
        {
            int s;
            int h = hour * 3600;
            int m = min * 60;
            s = sec + m + h;
            return s;
        }
        public void remaining()
        {
            int h = 24;
            int s = 60;
            int m = 60;
            Console.WriteLine((h - hour) + ":" + (m - min) + ":" + (s - sec));
        }
        public void incrementsec()
        {
            sec++;
        }
        public void incrementmin()
        {
            min++;
        }
        public void incrementhour()
        {
            hour++;
        }
        public bool compare(int s , int  m , int  h)
        {
            bool flag = false;
            if (sec == s && min == m && hour == h)
            {
                flag = true;
            }

            return flag;
        }
        public bool compare(clocktype temp)
        {
            bool flag = false;
            if (sec == temp.sec && min == temp.min && hour == temp.hour)
            {
                flag = true;
            }
            return flag;
        }
        public void printime()
        {
            Console.WriteLine(hour + " " + min + " " + sec);
        }
        public int sec;
        public int min;
        public int hour;
    }
}
