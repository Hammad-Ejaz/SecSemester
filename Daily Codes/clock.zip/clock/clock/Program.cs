﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace clock
{
    class Program
    {
        static void Main(string[] args)
        {
            clocktype myclock = new clocktype();
            Console.Write("time :");
            myclock.printime();

            clocktype secclock = new clocktype(8);
            Console.Write("sec time :");
            secclock.printime();

            clocktype minclock = new clocktype(8 , 10);
            Console.Write("min time :");
            minclock.printime();

            clocktype fullclock = new clocktype(8 ,10 , 10);
            Console.Write("full time :");
            fullclock.printime();

            fullclock.incrementsec();
            Console.Write("full time (increment sec)" );
            fullclock.printime();

            fullclock.incrementmin();
            Console.Write("full time (increment min)");
            fullclock.printime();

            fullclock.incrementhour();
            Console.Write("full time (increment hour)");
            fullclock.printime();

            bool flag = fullclock.compare(9, 11, 11);
            Console.WriteLine("flag : " + flag);

            clocktype temp = new clocktype(10, 12, 1);
            flag = fullclock.compare(temp);
            Console.WriteLine("flag : " + flag);

            int elapse = fullclock.elapsedTime();
            Console.WriteLine(elapse);

            fullclock.remaining();
            Console.ReadKey();
        }
    }
}
