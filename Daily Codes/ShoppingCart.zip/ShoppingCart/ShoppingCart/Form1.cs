﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShoppingCart
{
    public partial class Form1 : Form
    {
        float total = 0.0F;
        public Form1()
        {
            InitializeComponent();
            GrandTotallbl.Text = $"Total : {total}";
        }

        private void Label3_Click(object sender, EventArgs e)
        {

        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void CheckBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (item2cmb.Checked)
            {
                total += float.Parse(item2totallbl.Text);
            }
            else
            {
                total -= float.Parse(item2totallbl.Text);
            }
            GrandTotallbl.Text = $"Total : {total}";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Item1Txt_TextChanged(object sender, EventArgs e)
        {
            item1totallbl.Text = (int.Parse(item1Txt.Text) * 900).ToString();
        }

        private void Item2Txt_TextChanged(object sender, EventArgs e)
        {
            item2totallbl.Text = (int.Parse(item2Txt.Text) * 1400).ToString();
        }

        private void Item2Pricelbl_Click(object sender, EventArgs e)
        {

        }

        private void Itme2totallbl_Click(object sender, EventArgs e)
        {

        }

        private void Item3Txt_TextChanged(object sender, EventArgs e)
        {
            item3totallbl.Text = (int.Parse(Item3Txt.Text) * 2000).ToString();
        }

        private void Item1cmb_CheckedChanged(object sender, EventArgs e)
        {
            if(item1cmb.Checked)
            {
                total += float.Parse(item1totallbl.Text);
            }
            else
            {
                total -= float.Parse(item1totallbl.Text);
            }
            GrandTotallbl.Text = $"Total : {total}";
        }

        private void GrandTotallbl_Click(object sender, EventArgs e)
        {

        }

        private void Item3cmb_CheckedChanged(object sender, EventArgs e)
        {
            if (item3cmb.Checked)
            {
                total += float.Parse(item3totallbl.Text);
            }
            else
            {
                total -= float.Parse(item3totallbl.Text);
            }
            GrandTotallbl.Text = $"Total : {total}";
        }
    }
}
