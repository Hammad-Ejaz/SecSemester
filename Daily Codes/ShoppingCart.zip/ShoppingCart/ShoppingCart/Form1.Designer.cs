﻿namespace ShoppingCart
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Descriptionlbl = new System.Windows.Forms.Label();
            this.Quantitylbl = new System.Windows.Forms.Label();
            this.Pricelbl = new System.Windows.Forms.Label();
            this.Totallbl = new System.Windows.Forms.Label();
            this.item1cmb = new System.Windows.Forms.CheckBox();
            this.item2cmb = new System.Windows.Forms.CheckBox();
            this.item3cmb = new System.Windows.Forms.CheckBox();
            this.item1Txt = new System.Windows.Forms.TextBox();
            this.item2Txt = new System.Windows.Forms.TextBox();
            this.Item3Txt = new System.Windows.Forms.TextBox();
            this.item2Pricelbl = new System.Windows.Forms.Label();
            this.item1Pricelbl = new System.Windows.Forms.Label();
            this.item1totallbl = new System.Windows.Forms.Label();
            this.item3Pricelbl = new System.Windows.Forms.Label();
            this.item2totallbl = new System.Windows.Forms.Label();
            this.item3totallbl = new System.Windows.Forms.Label();
            this.GrandTotallbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Descriptionlbl
            // 
            this.Descriptionlbl.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.Descriptionlbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Descriptionlbl.Location = new System.Drawing.Point(150, 130);
            this.Descriptionlbl.Name = "Descriptionlbl";
            this.Descriptionlbl.Size = new System.Drawing.Size(150, 23);
            this.Descriptionlbl.TabIndex = 0;
            this.Descriptionlbl.Text = "Description";
            // 
            // Quantitylbl
            // 
            this.Quantitylbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Quantitylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Quantitylbl.Location = new System.Drawing.Point(297, 130);
            this.Quantitylbl.Name = "Quantitylbl";
            this.Quantitylbl.Size = new System.Drawing.Size(150, 23);
            this.Quantitylbl.TabIndex = 1;
            this.Quantitylbl.Text = "Quantity";
            // 
            // Pricelbl
            // 
            this.Pricelbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Pricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Pricelbl.Location = new System.Drawing.Point(442, 130);
            this.Pricelbl.Name = "Pricelbl";
            this.Pricelbl.Size = new System.Drawing.Size(150, 23);
            this.Pricelbl.TabIndex = 2;
            this.Pricelbl.Text = "Price";
            this.Pricelbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Pricelbl.Click += new System.EventHandler(this.Label3_Click);
            // 
            // Totallbl
            // 
            this.Totallbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.Totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Totallbl.Location = new System.Drawing.Point(529, 130);
            this.Totallbl.Name = "Totallbl";
            this.Totallbl.Size = new System.Drawing.Size(103, 23);
            this.Totallbl.TabIndex = 3;
            this.Totallbl.Text = "Total";
            this.Totallbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Totallbl.Click += new System.EventHandler(this.Label4_Click);
            // 
            // item1cmb
            // 
            this.item1cmb.AutoSize = true;
            this.item1cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item1cmb.Location = new System.Drawing.Point(153, 174);
            this.item1cmb.Name = "item1cmb";
            this.item1cmb.Size = new System.Drawing.Size(69, 21);
            this.item1cmb.TabIndex = 4;
            this.item1cmb.Text = "Shirts";
            this.item1cmb.UseVisualStyleBackColor = true;
            this.item1cmb.CheckedChanged += new System.EventHandler(this.Item1cmb_CheckedChanged);
            // 
            // item2cmb
            // 
            this.item2cmb.AutoSize = true;
            this.item2cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item2cmb.Location = new System.Drawing.Point(153, 211);
            this.item2cmb.Name = "item2cmb";
            this.item2cmb.Size = new System.Drawing.Size(68, 21);
            this.item2cmb.TabIndex = 5;
            this.item2cmb.Text = "Pents";
            this.item2cmb.UseVisualStyleBackColor = true;
            this.item2cmb.CheckedChanged += new System.EventHandler(this.CheckBox2_CheckedChanged);
            // 
            // item3cmb
            // 
            this.item3cmb.AutoSize = true;
            this.item3cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item3cmb.Location = new System.Drawing.Point(153, 249);
            this.item3cmb.Name = "item3cmb";
            this.item3cmb.Size = new System.Drawing.Size(61, 17);
            this.item3cmb.TabIndex = 6;
            this.item3cmb.Text = "Shoes";
            this.item3cmb.UseVisualStyleBackColor = true;
            this.item3cmb.CheckedChanged += new System.EventHandler(this.Item3cmb_CheckedChanged);
            // 
            // item1Txt
            // 
            this.item1Txt.Location = new System.Drawing.Point(300, 175);
            this.item1Txt.Name = "item1Txt";
            this.item1Txt.Size = new System.Drawing.Size(100, 20);
            this.item1Txt.TabIndex = 7;
            this.item1Txt.TextChanged += new System.EventHandler(this.Item1Txt_TextChanged);
            // 
            // item2Txt
            // 
            this.item2Txt.Location = new System.Drawing.Point(300, 211);
            this.item2Txt.Name = "item2Txt";
            this.item2Txt.Size = new System.Drawing.Size(100, 20);
            this.item2Txt.TabIndex = 8;
            this.item2Txt.TextChanged += new System.EventHandler(this.Item2Txt_TextChanged);
            // 
            // Item3Txt
            // 
            this.Item3Txt.Location = new System.Drawing.Point(300, 246);
            this.Item3Txt.Name = "Item3Txt";
            this.Item3Txt.Size = new System.Drawing.Size(100, 20);
            this.Item3Txt.TabIndex = 9;
            this.Item3Txt.TextChanged += new System.EventHandler(this.Item3Txt_TextChanged);
            // 
            // item2Pricelbl
            // 
            this.item2Pricelbl.BackColor = System.Drawing.SystemColors.Control;
            this.item2Pricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item2Pricelbl.Location = new System.Drawing.Point(441, 208);
            this.item2Pricelbl.Name = "item2Pricelbl";
            this.item2Pricelbl.Size = new System.Drawing.Size(121, 23);
            this.item2Pricelbl.TabIndex = 10;
            this.item2Pricelbl.Text = "1400 RS";
            this.item2Pricelbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.item2Pricelbl.Click += new System.EventHandler(this.Item2Pricelbl_Click);
            // 
            // item1Pricelbl
            // 
            this.item1Pricelbl.BackColor = System.Drawing.SystemColors.Control;
            this.item1Pricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item1Pricelbl.Location = new System.Drawing.Point(441, 172);
            this.item1Pricelbl.Name = "item1Pricelbl";
            this.item1Pricelbl.Size = new System.Drawing.Size(121, 23);
            this.item1Pricelbl.TabIndex = 11;
            this.item1Pricelbl.Text = "900 RS";
            this.item1Pricelbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // item1totallbl
            // 
            this.item1totallbl.BackColor = System.Drawing.SystemColors.Control;
            this.item1totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item1totallbl.Location = new System.Drawing.Point(568, 172);
            this.item1totallbl.Name = "item1totallbl";
            this.item1totallbl.Size = new System.Drawing.Size(64, 23);
            this.item1totallbl.TabIndex = 12;
            this.item1totallbl.Text = "0.0";
            this.item1totallbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // item3Pricelbl
            // 
            this.item3Pricelbl.BackColor = System.Drawing.SystemColors.Control;
            this.item3Pricelbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item3Pricelbl.Location = new System.Drawing.Point(441, 243);
            this.item3Pricelbl.Name = "item3Pricelbl";
            this.item3Pricelbl.Size = new System.Drawing.Size(115, 23);
            this.item3Pricelbl.TabIndex = 13;
            this.item3Pricelbl.Text = "2000 RS";
            this.item3Pricelbl.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // item2totallbl
            // 
            this.item2totallbl.BackColor = System.Drawing.SystemColors.Control;
            this.item2totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item2totallbl.Location = new System.Drawing.Point(532, 208);
            this.item2totallbl.Name = "item2totallbl";
            this.item2totallbl.Size = new System.Drawing.Size(100, 23);
            this.item2totallbl.TabIndex = 14;
            this.item2totallbl.Text = "0.0";
            this.item2totallbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.item2totallbl.Click += new System.EventHandler(this.Itme2totallbl_Click);
            // 
            // item3totallbl
            // 
            this.item3totallbl.BackColor = System.Drawing.SystemColors.Control;
            this.item3totallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.item3totallbl.Location = new System.Drawing.Point(540, 243);
            this.item3totallbl.Name = "item3totallbl";
            this.item3totallbl.Size = new System.Drawing.Size(92, 23);
            this.item3totallbl.TabIndex = 15;
            this.item3totallbl.Text = "0.0";
            this.item3totallbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // GrandTotallbl
            // 
            this.GrandTotallbl.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.GrandTotallbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GrandTotallbl.Location = new System.Drawing.Point(153, 294);
            this.GrandTotallbl.Name = "GrandTotallbl";
            this.GrandTotallbl.Size = new System.Drawing.Size(479, 23);
            this.GrandTotallbl.TabIndex = 16;
            this.GrandTotallbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.GrandTotallbl.Click += new System.EventHandler(this.GrandTotallbl_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.GrandTotallbl);
            this.Controls.Add(this.item3totallbl);
            this.Controls.Add(this.item2totallbl);
            this.Controls.Add(this.item3Pricelbl);
            this.Controls.Add(this.item1totallbl);
            this.Controls.Add(this.item1Pricelbl);
            this.Controls.Add(this.item2Pricelbl);
            this.Controls.Add(this.Item3Txt);
            this.Controls.Add(this.item2Txt);
            this.Controls.Add(this.item1Txt);
            this.Controls.Add(this.item3cmb);
            this.Controls.Add(this.item2cmb);
            this.Controls.Add(this.item1cmb);
            this.Controls.Add(this.Totallbl);
            this.Controls.Add(this.Pricelbl);
            this.Controls.Add(this.Quantitylbl);
            this.Controls.Add(this.Descriptionlbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Descriptionlbl;
        private System.Windows.Forms.Label Quantitylbl;
        private System.Windows.Forms.Label Pricelbl;
        private System.Windows.Forms.Label Totallbl;
        private System.Windows.Forms.CheckBox item1cmb;
        private System.Windows.Forms.CheckBox item2cmb;
        private System.Windows.Forms.CheckBox item3cmb;
        private System.Windows.Forms.TextBox item1Txt;
        private System.Windows.Forms.TextBox item2Txt;
        private System.Windows.Forms.TextBox Item3Txt;
        private System.Windows.Forms.Label item2Pricelbl;
        private System.Windows.Forms.Label item1Pricelbl;
        private System.Windows.Forms.Label item1totallbl;
        private System.Windows.Forms.Label item3Pricelbl;
        private System.Windows.Forms.Label item2totallbl;
        private System.Windows.Forms.Label item3totallbl;
        private System.Windows.Forms.Label GrandTotallbl;
    }
}

