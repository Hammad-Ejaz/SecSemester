﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace PdTask
{
    public partial class Form1 : Form
    {
        private int MaximumSize = 100;
        public Form1()
        {
            InitializeComponent();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            if (textBox_txt.Font.Bold != true) textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Bold);
            else textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Regular);
        }

        private void UnderLine_Cmd_Click(object sender, EventArgs e)
        {
            if (textBox_txt.Font.Underline != true) textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Underline);
            else textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Regular);
        }
        
        private void Italic_Cmd_Click(object sender, EventArgs e)
        {
            if (textBox_txt.Font.Italic != true) textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Italic);
            else textBox_txt.Font = new Font(textBox_txt.Font, FontStyle.Regular);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            sizeTxt_cmb.ComboBox.DataSource = setsize();
            FontFamily_cmb.ComboBox.DataSource = FontFamily.Families;
            FontFamily_cmb.ComboBox.DisplayMember = "Name";
        }
        private List<int> setsize()
        {
            List<int> sizes = new List<int>();
            for (int i = 1; i < MaximumSize; i++) sizes.Add(i);
            return sizes;
        }
        private void FontFamily_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            //  textBox_txt.Font = new Font(FontFamily_cmb.ComboBox.Text, int.Parse(FontSize_cmb.Text));
            Font myfont = new Font(FontFamily_cmb.ComboBox.Text, int.Parse(sizeTxt_cmb.ComboBox.Text));
            textBox_txt.Font = myfont;
        } 
        private void SizeTxt_cmb_SelectedIndexChanged(object sender, EventArgs e)
        {
            Font myfont = new Font(FontFamily_cmb.ComboBox.Text, int.Parse(sizeTxt_cmb.ComboBox.Text));
            textBox_txt.Font = myfont;
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (save_cmb.Text == "SAVE")
            {
                SaveFileDialog save = new SaveFileDialog();
                save.ShowDialog();
                SaveData(save.FileName);
            }
            else
            {
                OpenFileDialog open = new OpenFileDialog();
                open.ShowDialog();
                loadData(open.FileName);
            }
        }
        private void SaveData(string path)
        {
            try
            {
                StreamWriter file = new StreamWriter(path);
                file.WriteLine(textBox_txt.Text);
                file.Close();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
        }
        private void loadData(string path)
        {
            try
            {
                StreamReader file = new StreamReader(path);
                textBox_txt.Text = file.ReadToEnd().ToString();
                file.Close();
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.ToString());
            }
        }

        private void SizeTxt_cmb_Click(object sender, EventArgs e)
        {

        }
    }
}
