﻿namespace PdTask
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.textBox_txt = new System.Windows.Forms.TextBox();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.bold_Cmd = new System.Windows.Forms.ToolStripButton();
            this.underLine_Cmd = new System.Windows.Forms.ToolStripButton();
            this.Italic_Cmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.FontFamily_cmb = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripLabel2 = new System.Windows.Forms.ToolStripLabel();
            this.sizeTxt_cmb = new System.Windows.Forms.ToolStripComboBox();
            this.save_cmb = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.toolStrip1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox_txt
            // 
            this.textBox_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_txt.Location = new System.Drawing.Point(3, 104);
            this.textBox_txt.Multiline = true;
            this.textBox_txt.Name = "textBox_txt";
            this.textBox_txt.Size = new System.Drawing.Size(1104, 580);
            this.textBox_txt.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bold_Cmd,
            this.underLine_Cmd,
            this.Italic_Cmd,
            this.toolStripLabel1,
            this.FontFamily_cmb,
            this.toolStripLabel2,
            this.sizeTxt_cmb});
            this.toolStrip1.Location = new System.Drawing.Point(0, 40);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(481, 61);
            this.toolStrip1.TabIndex = 1;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // bold_Cmd
            // 
            this.bold_Cmd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bold_Cmd.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.bold_Cmd.Image = ((System.Drawing.Image)(resources.GetObject("bold_Cmd.Image")));
            this.bold_Cmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bold_Cmd.Name = "bold_Cmd";
            this.bold_Cmd.Size = new System.Drawing.Size(23, 58);
            this.bold_Cmd.Text = "B";
            this.bold_Cmd.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // underLine_Cmd
            // 
            this.underLine_Cmd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.underLine_Cmd.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))));
            this.underLine_Cmd.Image = ((System.Drawing.Image)(resources.GetObject("underLine_Cmd.Image")));
            this.underLine_Cmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.underLine_Cmd.Name = "underLine_Cmd";
            this.underLine_Cmd.Size = new System.Drawing.Size(23, 22);
            this.underLine_Cmd.Text = "U";
            this.underLine_Cmd.Click += new System.EventHandler(this.UnderLine_Cmd_Click);
            // 
            // Italic_Cmd
            // 
            this.Italic_Cmd.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.Italic_Cmd.Font = new System.Drawing.Font("Segoe UI", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.Italic_Cmd.Image = ((System.Drawing.Image)(resources.GetObject("Italic_Cmd.Image")));
            this.Italic_Cmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Italic_Cmd.Name = "Italic_Cmd";
            this.Italic_Cmd.Size = new System.Drawing.Size(23, 22);
            this.Italic_Cmd.Text = "I";
            this.Italic_Cmd.Click += new System.EventHandler(this.Italic_Cmd_Click);
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(69, 22);
            this.toolStripLabel1.Text = "Font Family";
            // 
            // FontFamily_cmb
            // 
            this.FontFamily_cmb.Name = "FontFamily_cmb";
            this.FontFamily_cmb.Size = new System.Drawing.Size(121, 25);
            this.FontFamily_cmb.SelectedIndexChanged += new System.EventHandler(this.FontFamily_cmb_SelectedIndexChanged);
            // 
            // toolStripLabel2
            // 
            this.toolStripLabel2.Name = "toolStripLabel2";
            this.toolStripLabel2.Size = new System.Drawing.Size(54, 22);
            this.toolStripLabel2.Text = "Font SIze";
            // 
            // sizeTxt_cmb
            // 
            this.sizeTxt_cmb.Name = "sizeTxt_cmb";
            this.sizeTxt_cmb.Size = new System.Drawing.Size(121, 61);
            this.sizeTxt_cmb.SelectedIndexChanged += new System.EventHandler(this.SizeTxt_cmb_SelectedIndexChanged);
            this.sizeTxt_cmb.Click += new System.EventHandler(this.SizeTxt_cmb_Click);
            // 
            // save_cmb
            // 
            this.save_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.save_cmb.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.save_cmb.FormattingEnabled = true;
            this.save_cmb.Items.AddRange(new object[] {
            "OPEN NEW",
            "SAVE"});
            this.save_cmb.Location = new System.Drawing.Point(3, 3);
            this.save_cmb.Name = "save_cmb";
            this.save_cmb.Size = new System.Drawing.Size(152, 24);
            this.save_cmb.TabIndex = 0;
            this.save_cmb.SelectedIndexChanged += new System.EventHandler(this.ComboBox1_SelectedIndexChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.save_cmb, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.toolStrip1, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox_txt, 0, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 39.60396F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 60.39604F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 585F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1110, 687);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 687);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_txt;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton bold_Cmd;
        private System.Windows.Forms.ToolStripButton underLine_Cmd;
        private System.Windows.Forms.ToolStripButton Italic_Cmd;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox FontFamily_cmb;
        private System.Windows.Forms.ToolStripLabel toolStripLabel2;
        private System.Windows.Forms.ComboBox save_cmb;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.ToolStripComboBox sizeTxt_cmb;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}

