﻿using CoffeeShop.BL;
using CoffeeShop.DL;
using CoffeeShop.UI;
namespace CoffeeShop
{
    class Program
    {
        static void Main(string[] args)
        {
            MenuItemDL.readFromFile("menuItem.txt");
            CoffeeShopBL shop = CoffeeShopDL.readFromFile("shop.txt");
            if(shop == null) shop = new CoffeeShopBL("second cup");
            int op = 0;
            while (op != 9)
            {
                MainUI.Header();
                op = MainUI.MainMenu();
                if (op == 1)
                {
                    shop.AddMenuItem(MenuItemUI.takeInputForItem());
                }
                else if (op == 2)
                {
                    CoffeeShopUI.ShowCheapestItem(shop);
                }
                else if (op == 3)
                {
                    CoffeeShopUI.ViewDrinks(shop);
                }
                else if (op == 4)
                {
                    CoffeeShopUI.ViewFoods(shop);
                }
                else if (op == 5)
                {
                    if (MenuItemDL.getMenuList() != null) MainUI.PrintMessage(shop.addOrder(CoffeeShopUI.InputTOAddOrder()));
                    else MainUI.PrintMessage("nothing is available now");
                }
                else if (op == 6)
                {
                    CoffeeShopUI.ViewFulFilOrder(shop);
                }
                else if (op == 7)
                {
                    CoffeeShopUI.ViewOrderList(shop);
                }
                else if (op == 8)
                {
                    CoffeeShopUI.TotalPrice(shop);
                }
                MainUI.ClearScreen();
            }
            MenuItemDL.storeintoFile("menuItem.txt", shop.getMenu());
            CoffeeShopDL.storeintoFile("shop.txt", shop);
        }
    }
}
