﻿using System.IO;
using System.Linq;
using CoffeeShop.BL;
namespace CoffeeShop.DL
{
    class CoffeeShopDL
    {
        public static void storeintoFile(string path, CoffeeShopBL store)
        {

            StreamWriter f = new StreamWriter(path);
            string items = "", orders = "";

            items = string.Join(";", store.getMenu().Select(o => o.getName()));
            orders = string.Join(":", store.getOrders());
            f.WriteLine(store.getName() + "," + items + "," + orders);
            f.Flush();
            f.Close();
        }
        public static CoffeeShopBL readFromFile(string path)
        {
            StreamReader f = new StreamReader(path);
            string record;
            CoffeeShopBL shops = null;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    
                    string[] splittedRecord = record.Split(',');
                    string ShopName = splittedRecord[0];
                    string[] splittedRecordForMenu = splittedRecord[1].Split(';');
                    CoffeeShopBL shop = new CoffeeShopBL(ShopName);
                    for (int x = 0; x < splittedRecordForMenu.Length; x++)
                    {
                        MenuItemBL menu = MenuItemDL.isItemExist(splittedRecordForMenu[x]);
                        if (menu != null)
                        {
                            shop.AddMenuItem(menu);
                        }
                    }

                    string[] splittedRecordForOrder = splittedRecord[splittedRecordForMenu.Length + 1].Split(':');
                    for (int x = 0; x < splittedRecordForOrder.Length; x++)
                    {
                        string order = splittedRecordForOrder[x];
                        shop.addOrder(order);
                        shops = shop;
                    }
                }
                f.Close();
                return shops;
            }
                return null;
        }
    }
}
