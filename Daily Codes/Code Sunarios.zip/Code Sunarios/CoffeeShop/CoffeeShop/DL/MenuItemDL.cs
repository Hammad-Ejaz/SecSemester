﻿using System;
using System.Collections.Generic;
using System.IO;
using CoffeeShop.BL;
namespace CoffeeShop.DL
{
    class MenuItemDL
    {
        static List<MenuItemBL> menuList = new List<MenuItemBL>();

        public static List<MenuItemBL> getMenuList() => menuList;

        public static void addMenuToList(MenuItemBL item)
        {
            menuList.Add(item);
        }
        public static MenuItemBL isItemExist(string name)
        {
            foreach(MenuItemBL i in menuList)
            {
                if (name == i.getName())
                {
                    return i;
                }
            }
           return null;
        }
        public static bool readFromFile(string path)
        {
            StreamReader f = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string type = splittedRecord[1];
                    int price = int.Parse(splittedRecord[2]);
                    MenuItemBL item = new MenuItemBL(name ,type, price);
                    addMenuToList(item);
                }
                f.Close();
                return true;
            }
            else
            {
                return false;
            }
        }

        public static void storeintoFile(string path, List<MenuItemBL> item)
        {
            StreamWriter f = new StreamWriter(path);
            foreach(MenuItemBL i in item)
            {
                f.WriteLine(i.getName() + "," + i.getType() + "," + i.getPrice());
            }
            f.Flush();
            f.Close();
        }
    }
}
