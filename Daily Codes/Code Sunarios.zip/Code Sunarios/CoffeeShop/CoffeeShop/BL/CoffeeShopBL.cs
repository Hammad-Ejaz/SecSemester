﻿using System;
using System.Collections.Generic;
namespace CoffeeShop.BL
{
    class CoffeeShopBL
    {
        public CoffeeShopBL(string shopName)
        {
            this.shopName = shopName;
            menuItems = new List<MenuItemBL>();
            orders = new List<string>();
        }
        private string shopName;
        private List<MenuItemBL> menuItems;
        private List<string> orders;

        public string getName() => shopName;
        public List<MenuItemBL> getMenu() => menuItems;
        public List<string> getOrders() => orders;
        public void AddMenuItem(MenuItemBL MenuItem)
        {
            menuItems.Add(MenuItem);
        }
        public string addOrder(string name)
        {
            string message = "This item is currently unavailable!";
            foreach (MenuItemBL item in menuItems)
            {
                if (item.getName() == name)
                {
                    orders.Add(name);
                    message = "Order Added";
                    return message;
                }
            }
            return message;
        }
        public string fulfillOrder()
        {
            string message = "All orders have been fulfilled!";
            if (orders.Count != 0)
            {
                message = orders[0] + "is Ready";
                orders.RemoveAt(0);
                return message;
            }
            else return message;
        }
        public List<string> GetOrdersList()
        {
            return orders;
        }
        public int dueAmount()
        {
            int price = 0;
            foreach (string name in orders)
            {
                foreach (MenuItemBL item in menuItems)
                {
                    if (item.getName()== name)
                    {
                        price += item.getPrice();
                    }
                }
            }
            return price;
        }
        public string cheapestItem()
        {
            if(menuItems.Count == 0)
            {
                return "N/A";
            }
            MenuItemBL item = menuItems[0];
            foreach (MenuItemBL i in menuItems)
            {
                if (i.getPrice() < item.getPrice())
                {
                    item = i;
                }
            }
            return item.getName();
        }
        public List<String> drinksOnly()
        {
            List<string> drinks = new List<string>();
            foreach (MenuItemBL i in menuItems)
            {
                if (i.getType() == "drink") drinks.Add(i.getName());
            }
            return drinks;
        }
        public List<String> foodOnly()
        {
            List<string> drinks = new List<string>();
            foreach (MenuItemBL i in menuItems)
            {
                if (i.getType() == "food") drinks.Add(i.getName());
            }
            return drinks;
        }

    }
}
