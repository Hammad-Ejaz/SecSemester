﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoffeeShop.BL
{
    class MenuItemBL
    {
        public MenuItemBL(string name , string type , int price)
        {
            this.name = name;
            this.type = type;
            this.price = price;
        }
        private string name;
        private string type;
        private int price;
        public string getName() => name;
        public string getType() => type;
        public int getPrice() => price;
    }
}
