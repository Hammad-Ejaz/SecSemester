﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoffeeShop.BL;
using CoffeeShop.DL;
namespace CoffeeShop.UI
{
    class CoffeeShopUI
    { 
        public static void ShowCheapestItem(CoffeeShopBL shop)
        {
            if(shop != null) Console.WriteLine($"the cheapest item in menue is : {shop.cheapestItem()}");
            else  Console.WriteLine("nothing is availabe now");
        }
        public static void ViewDrinks(CoffeeShopBL shop)
        {
            int n = 1;
            if (shop != null)
            {
                foreach (string i in shop.drinksOnly())
                {
                    Console.WriteLine(n + "_ " + i);
                    n++;
                }
            }
            else Console.WriteLine("no drink is available now");
        }
        public static void ViewFoods(CoffeeShopBL shop)
        {
            int n = 1;
            if (shop != null)
            {
                foreach (string i in shop.foodOnly())
                {
                    Console.WriteLine(n + "_ " + i);
                    n++;
                }
            }
            else Console.WriteLine("no food is available now");
        }
        public static string InputTOAddOrder()
        {
                Console.WriteLine("enter the item name you want to order");
                string itemName = Console.ReadLine();
                foreach (MenuItemBL i in MenuItemDL.getMenuList())
                {
                    if (itemName == i.getName())
                    {
                        return itemName;
                    }
                }
                Console.WriteLine("this product is not available right now");
                return null;
        }
        public static void ViewFulFilOrder(CoffeeShopBL shop)
        {
            Console.WriteLine(shop.fulfillOrder());
        }
        public static void ViewOrderList(CoffeeShopBL shop)
        {
            int n = 1;
            foreach(string i in shop.GetOrdersList())
            {
                Console.WriteLine(n + i);
                n++;
            }
        }
        public static void TotalPrice(CoffeeShopBL shop)
        {
            Console.WriteLine($"the total net amount is : {shop.dueAmount()}");
        }
    }
}
