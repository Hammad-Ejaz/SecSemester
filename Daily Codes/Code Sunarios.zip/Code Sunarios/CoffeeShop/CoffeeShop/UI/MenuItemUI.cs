﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CoffeeShop.BL;
using CoffeeShop.DL;
namespace CoffeeShop.UI
{
    class MenuItemUI
    {
        public static MenuItemBL takeInputForItem()
        {
            Console.WriteLine("enter the name of item");
            string name = Console.ReadLine();
            Console.WriteLine("enter the type of item");
            string type = Console.ReadLine();
            while (type != "drink" && type != "food")
            {
                Console.WriteLine("invalid type");
                type = Console.ReadLine();
            }
            Console.WriteLine("enter the price of item");
            int price = int.Parse(Console.ReadLine());
            while (price < 0)
            {
                price = int.Parse(Console.ReadLine());
            }
            MenuItemBL item = new MenuItemBL(name, type, price);
            return item;
        }
    }
}
