﻿using System;
namespace CoffeeShop.UI
{
    class MainUI
    {
        public static void Header()
        {
            Console.WriteLine("************************************");
            Console.WriteLine("             COFFEE SHOP            ");
            Console.WriteLine("************************************");
        }
        public static int MainMenu()
        {
            Console.WriteLine("1.Add a Menu Item");
            Console.WriteLine("2.View the Cheapest item in the menu");
            Console.WriteLine("3.View the Drink's Menu");
            Console.WriteLine("4.View the Food's Menu");
            Console.WriteLine("5.Add order");
            Console.WriteLine("6.Fulfil the Order");
            Console.WriteLine("7.View the Order's List");
            Console.WriteLine("8.Total Payable Amount");
            Console.WriteLine("9.Exit");
            int op = int.Parse(Console.ReadLine());
            while(op > 9 || op < 0)
            {
                op = int.Parse(Console.ReadLine());
            }
            return op;
        }
        public static void ClearScreen()
        {
            Console.WriteLine("press any key to continue..");
            Console.ReadKey();
            Console.Clear();
        }
        public static void PrintMessage(string message)
        {
            Console.WriteLine(message);
        }
    }
}
