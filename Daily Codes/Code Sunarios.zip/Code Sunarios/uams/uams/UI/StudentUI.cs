﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using uams.BL;
using uams.DL;

namespace uams.UI
{
    class StudentUI
    {
        public static void printStudents(List<Student> students)
        {
            foreach (Student s in students)
            {
                if (s.getRegDegree() != null)
                {
                    Console.WriteLine(s.getName() + " got Admission in " + s.getRegDegree().getDegreeName());
                }
                else
                {
                    Console.WriteLine(s.getName() + " did not get Admission");

                }
            }
        }
        public static void viewStudentInDegree(string degName)
        {
            Console.WriteLine("Name\tFSC\tEcat\tAge");
            foreach (Student s in StudentDL.getRegisteredStudents())
            {
               
                if (degName == s.getRegDegree().getDegreeName())
                {
                    Console.WriteLine(s.getName() + "\t" + s.getFscMarks() + "\t" + s.getEcatMarks() + "\t" + s.getAge());
                }
                
            }
        }
        public static void viewRegisteredStudents(List<Student> registered)
        {
            Console.WriteLine("Name\tFSC\tEcat\tAge");
            foreach (Student s in registered)
            {
                if (s.getRegDegree() != null)
                {
                    Console.WriteLine(s.getName() + "\t" + s.getFscMarks() + "\t" + s.getEcatMarks() + "\t" + s.getAge());
                }
            }
        }

        public static Student takeInputForStudent()
        {
            string name;
            int age;
            double fscMarks;
            double ecatMarks;
            DegreeProgram preferences;
            Console.Write("Enter Student Name: ");
            name = Console.ReadLine();
            Console.Write("Enter Student Age: ");
            age = int.Parse(Console.ReadLine());
            Console.Write("Enter Student FSc Marks: ");
            fscMarks = double.Parse(Console.ReadLine());
            Console.Write("Enter Student Ecat Marks: ");
            ecatMarks = double.Parse(Console.ReadLine());
            Student s = new Student(name, age, fscMarks, ecatMarks);
            Console.WriteLine("Available Degree Programs");
            DegreeProgramUI.viewDegreePrograms();

            Console.Write("Enter how many preferences to Enter: ");
            int Count = int.Parse(Console.ReadLine());
            for (int x = 0; x < Count; x++)
            {
                string degName = Console.ReadLine();
                while ((preferences = DegreeProgramDL.isDegreeExists(degName)) == null)
                {
                    Console.WriteLine("Invalid preference");
                    degName = Console.ReadLine();
                }
                s.addPreference(preferences);   
            }
            return s;
        }

        public static void ShowFeeForAllStudents()
        {
            foreach (Student s in StudentDL.getRegisteredStudents())
            {
                    Console.WriteLine(s.getName() + " has " + s.calculateFee() + " fees");   
            }
        }
    }
}
