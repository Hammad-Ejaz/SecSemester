﻿using System;
using uams.BL;
using uams.DL;
using uams.UI;

namespace uams
{
    public class Program
    {
        static void Main(string[] args)
        {
            string subjectPath = "subject.txt";
            string degreePath = "degree.txt";
            string studentPath = "student.txt";
            if (SubjectDL.readFromFile(subjectPath))
            {
                Console.WriteLine("Subject Data Loaded Successfully");
            }
            if (DegreeProgramDL.readFromFile(degreePath))
            {
                Console.WriteLine("DegreeProgram Data Loaded Successfully");
            }
            if (StudentDL.readFromFile(studentPath))
            {
                Console.WriteLine("Student Data Loaded Successfully");
            }
            int option = 0;
            while(option != 8)
            {
                option = MenuUI.Menu();
                MenuUI.clearScreen();
                if (option == 1)
                {
                    if (DegreeProgramDL.programList.Count > 0)
                    {
                        StudentDL.addIntoStudentList(StudentUI.takeInputForStudent());
                    }
                }
                else if (option == 2)
                {
                    DegreeProgramDL.addIntoDegreeList(DegreeProgramUI.takeInputForDegree());
                }
                else if (option == 3)
                {
                    StudentDL.giveAdmission(StudentDL.sortStudentsByMerit());
                }
                else if (option == 4)
                {
                    
                    StudentUI.viewRegisteredStudents(StudentDL.getRegisteredStudents());
                }
                else if (option == 5)
                {
                    StudentUI.viewStudentInDegree(MenuUI.showAndInputMessage("enter degree name"));
                }
                else if (option == 6)
                {
                    Student s = StudentDL.StudentPresent(MenuUI.showAndInputMessage("enter student name"));
                    if (s != null)
                    {
                        SubjectUI.viewSubjects(s);
                        SubjectUI.registerSubjects(s);
                    }
                 
                }
                else if (option == 7)
                {
                    StudentUI.ShowFeeForAllStudents();
                }
                MenuUI.clearScreen();
            }
            SubjectDL.storeintoFile("subject.txt");
            DegreeProgramDL.storeintoFile("degree.txt");
            StudentDL.storeintoFile("student.txt");
        }
    }
}
