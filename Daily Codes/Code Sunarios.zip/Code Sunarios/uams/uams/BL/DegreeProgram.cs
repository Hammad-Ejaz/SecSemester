﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uams.BL
{
    class DegreeProgram
    {
        private string degreeName;
        private float degreeDuration;
        private List<Subject> subjects;
        private int seats;

        public string getDegreeName() => degreeName;
        public float getDegreeDuration() => degreeDuration;
        public List<Subject> getSubject() => subjects;
        public int getSeats() => seats;

        public void setDegreeName(string degreeName) => this.degreeName = degreeName;
        public void setDegreeDuration(float degreeDuration) => this.degreeDuration = degreeDuration;
        public void setSubject(List<Subject> subjects) => this.subjects = subjects;
        public void setSeats(int seats) => this.seats = seats;

        public DegreeProgram(string degreeName, float degreeDuration, int seats)
        {
            this.degreeName = degreeName;
            this.degreeDuration = degreeDuration;
            this.seats = seats;
            subjects = new List<Subject>();
        }
        public List<Subject> getSubjects() => subjects;
        public bool availableSeats()
        {
            if (seats > 0) return true;
            else return false;
        }

        public bool decrementSeats()
        { 
            if (availableSeats())
            {
                seats--;
                return true;
            }
            else return false;
        }
        public bool isSubjectExists(Subject sub)
        {
            foreach (Subject s in subjects)
            {
                if (s.getCode() == sub.getCode())
                {
                    return true;
                }
            }
            return false;
        }

        public bool AddSubject(Subject s)
        {
            int creditHours = calculateCreditHours();
            if(creditHours + s.getCreditHours() <= 20)
            {
                subjects.Add(s);
                return true;
            }
            else
            {
                return false;
            }
        }

        public int calculateCreditHours()
        {
            int total = 0;
            foreach (Subject s in subjects)
           {
                total = total + s.getCreditHours();
            }
            return total;
        }

    }
}
