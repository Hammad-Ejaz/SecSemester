﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace uams.BL
{
    class Student
    {

        private string name;
        private int age;
        private double fscMarks;
        private double ecatMarks;
        private double merit;
        private List<DegreeProgram> preferences;
        private List<Subject> regSubject;
        private DegreeProgram regDegree;

        public string getName() => name;
        public int getAge() => age;
        public double getFscMarks() => fscMarks;
        public double getEcatMarks() => ecatMarks;
        public double getMerit() => merit;
        public List<DegreeProgram> getPreferences() => preferences;
        public List<Subject> getREgSubject() => regSubject;
        public DegreeProgram getRegDegree() => regDegree;

        public void setName(string name) => this.name = name;
        public void setAge(int age) => this.age = age;
        public void setFscMarks(double fscMarks) => this.fscMarks = fscMarks;
        public void setEcatMarks(double ecatMarks) => this.ecatMarks = ecatMarks;
        public void setMerit(double merit) => this.merit = merit;
        public void setPreferences(List<DegreeProgram> preferences) => this.preferences = preferences;
        public void setREgSubject(List<Subject> regSubject) => this.regSubject = regSubject;
        public void setRegDegree(DegreeProgram regDegree) => this.regDegree = regDegree;


        public Student(string name, int age, double fscMarks, double ecatMarks, List<DegreeProgram> preferences)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.preferences = preferences;
            regSubject = new List<Subject>();
            
        }
        public Student(string name, int age, double fscMarks, double ecatMarks)
        {
            this.name = name;
            this.age = age;
            this.fscMarks = fscMarks;
            this.ecatMarks = ecatMarks;
            this.preferences = new List<DegreeProgram>();
            regSubject = new List<Subject>();
            
        }
        public void addPreference(DegreeProgram p)
        {
            preferences.Add(p);
        }

        public void calculateMerit()
        {
            this.merit = (((fscMarks / 1100) * 0.65F) + ((ecatMarks / 400) * 0.4F)) * 100;
         
        }
        public bool addSubject(Subject s)
        {
            if (!regDegree.getSubjects().Contains(s) || getCreditHours() >= 9)
            {
                return false;
            }
            regSubject.Add(s);
            return true;
        }
        public int getCreditHours()
        {
            int total = 0;
            foreach (Subject sub in regSubject)
            {
                total += sub.getCreditHours();
            }
            return total;
        }

        public float calculateFee()
        {
            float fee = 0;
            if (regDegree != null)
            {
                foreach (Subject sub in regSubject)
                {
                    fee += sub.getSubjectFees();
                }
            }
            return fee;
        }

        
    }
}
