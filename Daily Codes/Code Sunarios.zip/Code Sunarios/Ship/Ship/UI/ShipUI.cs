﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.BL;
using Ship.DL;
namespace Ship.UI
{
    class ShipUI
    {
        
        public static void ChangeShipPossition()
        {
            Console.WriteLine("1_ENTER SHIP SERIAL NUMBER");
            string serialNumber = Console.ReadLine();
            ShipBL s = new ShipBL();
            if (ShipDL.isFound(serialNumber) != null)
            {
                s = ShipDL.isFound(serialNumber);
                s.UpdateShipLatitude(AngleUI.takeAngleInput("LATITUDE'S"));
                s.UpdateShipLongitude(AngleUI.takeAngleInput("LONGITUDE'S"));
            }
            else
            {
                Console.WriteLine("NO SHIP FOUND");
            }
        }
        public static void ViewShipPossition()
        {
            Console.WriteLine("1_ENTER SHIP SERIAL NUMBER");
            string serialNumber = Console.ReadLine();
            ShipBL s = new ShipBL();
            if (ShipDL.isFound(serialNumber) != null)
            {
                s = ShipDL.isFound(serialNumber);
                Console.WriteLine("THE SHIP IS AT  ");
                AngleUI.PrintAngle(s.GetLongitude().makeAngleString());
                Console.WriteLine(" , ");
                AngleUI.PrintAngle(s.GetLatitude().makeAngleString());
            }
            else
            {
                Console.WriteLine("NO SHIP FOUND");
            }
        }
        public static ShipBL InputToAddShip()
        {
            Console.WriteLine("1_ENTER SHIP NUMBER");
            string serialNumber = Console.ReadLine();
            AngleBL latitude = new AngleBL();
            latitude = AngleUI.takeAngleInput("LATITUDE'S");
            AngleBL longitude = new AngleBL();
            longitude = AngleUI.takeAngleInput("LONGITUDE'S");
            ShipBL s = new ShipBL(serialNumber, latitude, longitude);
            return s;
        }
        public static void PrintSerialNumber()
        {
            AngleBL latitude = new AngleBL();
            latitude = AngleUI.takeAngleInput("LATITUDE'S");
            AngleBL longitude = new AngleBL();
            longitude = AngleUI.takeAngleInput("LONGITUDE'S");
            if(ShipDL.isFound(latitude, longitude) != null)
            {
                Console.WriteLine($"the ship Serial number is : {ShipDL.isFound(latitude, longitude).GetSerialNumber()}");
            }
            else Console.WriteLine("NO SHIP FOUND");
        }
    }
}
