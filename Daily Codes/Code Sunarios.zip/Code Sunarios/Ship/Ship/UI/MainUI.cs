﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.BL;
namespace Ship.UI
{
    class MainUI
    {
        public static int Menu()
        {
            Console.WriteLine("******************************");
            Console.WriteLine("       OCEAN NAVIGATION       ");
            Console.WriteLine("******************************");
            Console.WriteLine("1_ADD SHIP");
            Console.WriteLine("2_VIEW SHIP POSSITION");
            Console.WriteLine("3_VIEW SHIP SERIAL NUMBER");
            Console.WriteLine("4_CHANGE SHIP POSSITION");
            Console.WriteLine("5_EXIT");
            int op = int.Parse(Console.ReadLine());
            return op;
        }
        public static void ClearScreen()
        {
            Console.WriteLine("PRESS ANY KEY TO CONTINUE");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
