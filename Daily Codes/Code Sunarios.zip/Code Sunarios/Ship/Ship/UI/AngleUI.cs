﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.BL;
namespace Ship.UI
{
    class AngleUI
    {
        public static AngleBL takeAngleInput(string direction)
        {
            Console.WriteLine("1_ENTER " + direction + " DEGREE");
            int Degree = int.Parse(Console.ReadLine());
            Console.WriteLine("1_ENTER " + direction + " MINUTE");
            float Minute = float.Parse(Console.ReadLine());
            Console.WriteLine("1_ENTER " + direction + " DIRECTION");
            char Direction = char.Parse(Console.ReadLine());
            AngleBL Angle = new AngleBL(Degree, Minute, Direction);
            return Angle;
        }
        public static void PrintAngle(string angle)
        {
            Console.Write(angle);
        }
    }
}
