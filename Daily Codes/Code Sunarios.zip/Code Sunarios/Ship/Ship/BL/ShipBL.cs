﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.UI;
using Ship.DL;
namespace Ship.BL
{
    class ShipBL
    {
        public ShipBL(string shipSerialNumber, AngleBL shipLatitude, AngleBL shipLongitude)
        {
            this.shipSerialNumber = shipSerialNumber;
            this.shipLatitude = shipLatitude;
            this.shipLongitude = shipLongitude;
        }
        public ShipBL() { }
        private string shipSerialNumber;
        private AngleBL shipLatitude;
        private AngleBL shipLongitude;
        public void SetSerialNumber(string shipSerialNumber) => this.shipSerialNumber = shipSerialNumber;
        public void UpdateShipLatitude(AngleBL angle) => shipLatitude = angle;
        public void UpdateShipLongitude(AngleBL angle) => shipLongitude = angle;
        public string GetSerialNumber() => shipSerialNumber;
        public AngleBL GetLatitude() => shipLatitude;
        public AngleBL GetLongitude() => shipLongitude;
        public void setLatiude(AngleBL angle) => shipLatitude = angle;
        public void setLongitude(AngleBL angle) => shipLongitude = angle;
    }
}
