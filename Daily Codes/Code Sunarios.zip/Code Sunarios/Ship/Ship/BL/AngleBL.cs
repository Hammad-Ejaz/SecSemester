﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.DL;
namespace Ship.BL
{
    class AngleBL
    {
        public AngleBL(int degree, float minute, char direction)
        {
            this.degree = degree;
            this.minute = minute;
            this.direction = direction;
        }
        public AngleBL() { }
        private int degree;
        private float minute;
        private char direction;
        public int getDegree() => degree;
        public float getMinute() => minute;
        public char getDirection() => direction;
        public void setDegree(int degree) => this.degree = degree;
        public void setMinute(float minute) => this.minute = minute;
        public void setDirection(char direction) => this.direction = direction;
        public void UpdateAngle(int degree, float minute, char direction)
         {
            this.degree = degree;
            this.minute = minute;
            this.direction = direction;
         }
        public string makeAngleString()
        {
            string angle;
            angle = degree + ("\u00b0") + minute + "'" + direction;
            return angle;
        }

    }
}
