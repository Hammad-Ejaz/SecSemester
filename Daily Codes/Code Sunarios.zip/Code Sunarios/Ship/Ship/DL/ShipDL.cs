﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Ship.BL;
namespace Ship.DL
{
    class ShipDL
    {
        static List<ShipBL> Listship = new List<ShipBL>();
        public static void storeintoFile(string path)
        {
            StreamWriter f = new StreamWriter(path, true);
            foreach (ShipBL i in Listship)
            {
                f.WriteLine(i.GetSerialNumber() + "," + i.GetLatitude().getDegree() + "," + i.GetLatitude().getMinute() + "," + i.GetLatitude().getDirection() + "," + i.GetLongitude().getDegree() + "," + i.GetLongitude().getMinute() + "," + i.GetLongitude().getDirection());
            }
            f.Flush();
            f.Close();
        }
        public static void readFromFile(string path)
        {
            string record;
            if (File.Exists(path))
            {
               StreamReader f = new StreamReader(path);
                while ((record = f.ReadLine()) != null)
                { 
                    string[] splittedRecord = record.Split(',');
                    for (int x = 0; x < splittedRecord.Length; x++)
                    {
                        AngleBL longitude = new AngleBL();
                        AngleBL latitude = new AngleBL();
                        ShipBL ship = new ShipBL();
                        ship.SetSerialNumber(splittedRecord[0]);
                        latitude.setDegree(int.Parse(splittedRecord[1]));
                        latitude.setMinute(float.Parse(splittedRecord[2]));
                        latitude.setDirection(char.Parse(splittedRecord[3]));

                        longitude.setDegree(int.Parse(splittedRecord[4]));
                        longitude.setMinute(float.Parse(splittedRecord[5]));
                        longitude.setDirection(char.Parse(splittedRecord[6]));
                        ship.setLatiude(latitude);
                        ship.setLongitude(longitude);
                        Listship.Add(ship);
                    }
                }
                f.Close();
            }
        }
        public static ShipBL isFound(AngleBL latitude, AngleBL longitude)
        {
            foreach (ShipBL i in Listship)
            {
                if (i.GetLatitude().getDegree() == latitude.getDegree() && i.GetLatitude().getMinute() == latitude.getMinute() && i.GetLatitude().getDirection() == latitude.getDirection())
                {
                    if (i.GetLongitude().getDegree() == longitude.getDegree() && i.GetLongitude().getMinute() == longitude.getMinute() && i.GetLongitude().getDirection() == longitude.getDirection())
                    {
                        return i;
                    }
                }
            }
            return null;
        }
        public static ShipBL isFound(string serialNumber)
        {
            foreach (ShipBL i in Listship)
            {
                if (serialNumber == i.GetSerialNumber())
                {
                    return i;
                }
            }
            return null;
        }
        public static void AddShipToList(ShipBL ship)
        {
            Listship.Add(ship);
        }
    }
}
