﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Ship.BL;
using Ship.UI;
using Ship.DL;
namespace Ship
{
    class Program
    {
        static void Main(string[] args)
        {
            int op = 0;
            while(op != 5)
            {
                ShipDL.readFromFile("ship.txt");
                op = MainUI.Menu();
                if(op == 1)
                {
                    ShipDL.AddShipToList(ShipUI.InputToAddShip());
                }
                else if (op == 2)
                {
                    ShipUI.ViewShipPossition();
                }
                else if (op == 3)
                {
                    ShipUI.PrintSerialNumber();
                }
                else if (op == 4)
                {
                    ShipUI.ChangeShipPossition();
                }
                MainUI.ClearScreen();
            }
            ShipDL.storeintoFile("ship.txt");
        }
    }
}
