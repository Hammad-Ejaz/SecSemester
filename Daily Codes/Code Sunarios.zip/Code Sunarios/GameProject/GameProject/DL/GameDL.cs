﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameProject.BL;
namespace GameProject.DL
{
    class GameDL
    {
        static List<GameBL> objects = new List<GameBL>();
        public static void AddObjects(GameBL Object) => objects.Add(Object);
        public static List<GameBL> getObject() => objects;
    }
}
