﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject.BL
{
    class BoundaryBL
    {
        public BoundaryBL()
        {
            topLeft.setXY(0, 0);
            topRight.setXY(90, 0);
            bottomLeft.setXY(0, 90);
            bottomRight.setXY(90, 90);
        }
        public BoundaryBL(PointBL topLeft, PointBL topRight, PointBL bottomLeft, PointBL bottomRight)
        {
            this.topLeft = topLeft;
            this.topRight = topRight;
            this.bottomLeft = bottomLeft;
            this.bottomRight = bottomRight;
        }
        private PointBL topLeft = new PointBL();
        private PointBL topRight = new PointBL();
        private PointBL bottomLeft = new PointBL();
        private PointBL bottomRight = new PointBL();
        public PointBL getTopLeft()
        {
            return topLeft;
        }
        public PointBL getTopRight()
        {
            return topRight;
        }
        public PointBL getBottomLeft()
        {
            return bottomLeft;
        }
        public PointBL getBottomRight()
        {
            return bottomRight;
        }
    }
}
