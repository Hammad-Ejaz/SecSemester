﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject.BL
{
    class PointBL
    {
        public PointBL()
        {
            X = 0;
            Y = 0;
        }
        public PointBL(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
        private int X;
        private int Y;
        public void setX(int X)
        {
            this.X = X;
        }
        public void setY(int Y)
        {
            this.Y = Y;
        }
        public int getX()
        {
            return X;
        }
        public int getY()
        {
            return Y;
        }
        public void setXY(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }
    }
}
