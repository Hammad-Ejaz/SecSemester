﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameProject.BL
{
    class GameBL
    {
        public GameBL()
        {
            char[,] shape = new char[1, 3] { { '-', '-', '-' } };
            direction = "LeftToRight";
        }
        public GameBL(char[,] shape, PointBL startingPoint, BoundaryBL premises, string direction)
        {
            this.shape = shape;
            this.startingPoint = startingPoint;
            this.premises = premises;
            this.direction = direction;
            directionPatrol = "right";
            ProjectileSteps = 0;
        }
        private char[,] shape;
        private PointBL startingPoint;
        private BoundaryBL premises;
        private string direction;
        private string directionPatrol;
        private uint ProjectileSteps;
        public void SetShape(char[,] shape) => this.shape = shape;
        public void SetStartPoint(PointBL startingPoint) => this.startingPoint = startingPoint;
        public void SetPremises(BoundaryBL premises) => this.premises = premises;
        public void SetDirection(string direction) => this.direction = direction;
        public char[,] GetShape() => shape;
        public PointBL GetStartPoint() => startingPoint;
        public BoundaryBL GetPremises() => premises;
        public string GetDirection() => direction;
        public void Move()
        {
            if (direction == "LeftToRight")
            {
                MoveLeftToRight();
            }
            else if (direction == "RightToLeft")
            {
                MoveRightToLeft();
            }
            else if (direction == "Patrol")
            {
                if (directionPatrol == "right")
                {
                    MoveLeftToRight();
                    if (startingPoint.getX() == premises.getTopRight().getX() - 1)
                    {
                        directionPatrol = "left";
                    }
                }
                else if (directionPatrol == "left")
                {
                    MoveRightToLeft();
                    if (startingPoint.getX() == premises.getTopLeft().getX())
                    {
                        directionPatrol = "right";
                    }
                }
            }
            else if (direction == "Projectile")
            {
                if(ProjectileSteps <= 5)
                {
                   TopRightDiagonal();// left bottom (0 , 90) say top right (90 , 0)  
                    ProjectileSteps++;
                }
                else if(ProjectileSteps > 5 && ProjectileSteps <= 10 )
                {
                   MoveLeftToRight(); // top left (0 , 0) say top right (90 , 0) 
                   ProjectileSteps++;
                }
                else if(ProjectileSteps > 10 && ProjectileSteps <= 16)
                {
                   BottomRightDiagonal(); //top left ( 0 , 0) say bottom right (90 , 90)
                   ProjectileSteps++;
                   if (ProjectileSteps == 16) ProjectileSteps = 0;
                }
            }
            else if (direction == "Diagonal")
            {

                BottomRightDiagonal();
            }
        }
        public void MoveLeftToRight() // top left (0 , 0) say top right (90 , 0)
        {
            if (startingPoint.getX() < premises.getTopRight().getX())
            {
                startingPoint.setX(startingPoint.getX() + 1);
            }
        }
        public void MoveRightToLeft() // top right(90 , 0) say top left(0,0)
        {
            if (startingPoint.getX() > premises.getTopLeft().getX())
            {
                startingPoint.setX(startingPoint.getX() - 1);
            }
        }
        public void TopLeftDiagonal() // bottom right (90 , 90) say top left (0 , 0)
        {
            if (startingPoint.getX() > premises.getTopLeft().getX() && startingPoint.getY() > premises.getTopLeft().getY())
            {
                startingPoint.setX(startingPoint.getX() - 1);
                startingPoint.setY(startingPoint.getY() - 1);
            }
        }
        public void TopRightDiagonal() // left bottom (0 , 90) say top right (90 , 0) 
        {
            if (startingPoint.getX() < premises.getTopRight().getX() && startingPoint.getY() > premises.getTopRight().getY())
            {
                startingPoint.setX(startingPoint.getX() + 1);
                startingPoint.setY(startingPoint.getY() - 1);
            }
        }
        public void BottomLefttDiagonal() // top right (90 , 0) say bottom left (0 , 90)
        {
            if (startingPoint.getX() > premises.getBottomLeft().getX() && startingPoint.getY() < premises.getBottomLeft().getY())
            {
                startingPoint.setX(startingPoint.getX() - 1);
                startingPoint.setY(startingPoint.getY() + 1);
            }
        }
        public void BottomRightDiagonal() // top left( 0 , 0) say bottom right(90 , 90)
        {
            if (startingPoint.getX() < premises.getBottomRight().getX() && startingPoint.getY() < premises.getBottomRight().getY())
            {
                startingPoint.setX(startingPoint.getX() + 1);
                startingPoint.setY(startingPoint.getY() + 1);
            }
        }
        
    }
}
