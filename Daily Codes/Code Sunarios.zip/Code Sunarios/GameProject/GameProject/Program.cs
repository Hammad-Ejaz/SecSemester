﻿using System;
using System.Threading;
using GameProject.BL;
using GameProject.DL;
using GameProject.UI;
namespace GameProject
{
    class Program
    {
        static void Main(string[] args)
        {
            char[,] triangle = new char[5, 3] { { '@', ' ', ' ' }, { '@', '@', ' ' }, { '@', '@', '@' }, { '@', '@', ' ' }, { '@', ' ', ' ' } };
            BoundaryBL b = new BoundaryBL();
            PointBL point = new PointBL();
            GameBL g1 = new GameBL(triangle, new PointBL(0,50) , b, "Projectile");;
            GameDL.AddObjects(g1);
            while (true)
            {
                Thread.Sleep(1000);
                foreach (GameBL i in GameDL.getObject())
                {
                    Console.Clear();
                    i.Move();
                    GameUI.Draw(i);
                }
            }
        }
    }
}
