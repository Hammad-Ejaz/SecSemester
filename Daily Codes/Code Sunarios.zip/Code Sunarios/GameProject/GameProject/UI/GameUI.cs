﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameProject.BL;
namespace GameProject.UI
{
    class GameUI
    {
        public static void Draw(GameBL Object)
        {

            for (int i = 0; i < Object.GetShape().GetLength(0); i++)
            {
                Console.SetCursorPosition(Object.GetStartPoint().getX(), Object.GetStartPoint().getY() + i);
                for (int j = 0; j < Object.GetShape().GetLength(1); j++)
                {
                    Console.Write(Object.GetShape()[i, j]);
                }
            }
        }
    }
}
