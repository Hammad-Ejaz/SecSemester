﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyPoint.BL;
namespace MyPoint.DL
{
    class LineDL
    {
        public static LineBL myLine = new LineBL();
        public static void readFromFile(string path)
        {
            StreamReader f = new StreamReader(path);
            string record;
            if (File.Exists(path))
            {
                record = f.ReadLine();
                string[] splittedRecord = record.Split(',');
                int X = int.Parse(splittedRecord[0]);
                int Y = int.Parse(splittedRecord[1]);
                PointBL point = new PointBL(X, Y);
                myLine.setBegin(point);
                X = int.Parse(splittedRecord[2]);
                Y = int.Parse(splittedRecord[3]);
                point = new PointBL(X, Y);
                myLine.setEnd(point);
            }
            f.Close();
        }

        public static void storeintoFile(string path)
        {
            StreamWriter f = new StreamWriter(path);
            f.WriteLine(myLine.getBegin().getX() + "," + myLine.getBegin().getY() + "," + myLine.getEnd().getX() + "," + myLine.getEnd().getY());
            f.Flush();
            f.Close();
        }
    }
}
