﻿using MyPoint.BL;
using MyPoint.UI;
using MyPoint.DL;
namespace MyPoint
{
    class Program
    {
        static void Main(string[] args)
        {
            LineDL.readFromFile("line.txt");
            int op = 0; 
            while (op != 10)
            {
                op = MainUI.MainMenu();
                if(op == 1)
                {
                    LineDL.myLine = LineUI.makeLine();
                }
                else if (op == 2)
                {
                    LineDL.myLine.setBegin(PointUI.inputForBeginUpdate());
                }
                else if (op == 3)
                {
                    LineDL.myLine.setEnd(PointUI.inputForEndUpdate());
                }
                else if (op == 4)
                {
                    PointUI.showBeginUpdatedPoints(LineDL.myLine);
                }
                else if (op == 5)
                {
                    PointUI.showEndUpdatedPoints(LineDL.myLine);
                }
                else if (op == 6)
                {
                    LineUI.showLineLength(LineDL.myLine);
                }
                else if (op == 7)
                {
                    LineUI.showGradientofLine(LineDL.myLine);
                }
                else if (op == 8)
                {
                    PointUI.DistancetofOriginfromBegIn(LineDL.myLine.getBegin());

                }
                else if (op == 9)
                {
                    PointUI.DistancetofOriginfromEnd(LineDL.myLine.getEnd());
                }
                MainUI.ClearScreen();
            }
            LineDL.storeintoFile("line.txt");
        }
    }
}
