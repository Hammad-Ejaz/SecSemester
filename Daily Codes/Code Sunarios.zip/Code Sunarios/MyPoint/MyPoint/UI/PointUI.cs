﻿using System;
using MyPoint.BL;
namespace MyPoint.UI
{
    class PointUI
    {
        public static PointBL takeCordinatesInput(string possition)
        {
            Console.WriteLine(possition);
            Console.WriteLine("WRITE THE X CORDINATE");
            int x = int.Parse(Console.ReadLine());
            Console.WriteLine("WRITE THE Y CORDINATE");
            int y = int.Parse(Console.ReadLine());
            PointBL Cordinate = new PointBL(x, y);
            return Cordinate;
        }
        public static PointBL inputForBeginUpdate()
        {
            PointBL begin = new PointBL();
            begin = takeCordinatesInput("BEGIN");
            return begin;
        }
        public static PointBL inputForEndUpdate()
        {
            PointBL end = new PointBL();
            end = takeCordinatesInput("END");
            return end;
        }
        public static void showBeginUpdatedPoints(LineBL line)
        {
            Console.WriteLine($"THE X CORDINATE OF BEGIN POINT IS : {line.getBegin().getX()}");
            Console.WriteLine($"THE Y CORDINATE OF BEGIN POINT IS : {line.getBegin().getY()}");
        }
        public static void showEndUpdatedPoints(LineBL line)
        {
            Console.WriteLine($"THE X CORDINATE OF END POINT IS : {line.getEnd().getX()}");
            Console.WriteLine($"THE Y CORDINATE OF END POINT IS : {line.getEnd().getY()}");
        }
        public static void DistancetofOriginfromBegIn(PointBL point)
        {
            Console.WriteLine($"THE DISTANCE OF ORIGIN FROM BEGIN POINT IS :{point.distanceFronZero()}");
        }
        public static void DistancetofOriginfromEnd(PointBL point)
        {
            Console.WriteLine($"THE DISTANCE OF ORIGIN FROM END POINT IS :{point.distanceFronZero()}");
        }
    }
}
