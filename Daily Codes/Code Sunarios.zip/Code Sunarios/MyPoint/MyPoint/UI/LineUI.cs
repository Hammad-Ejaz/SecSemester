﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyPoint.BL;
namespace MyPoint.UI
{
    class LineUI
    {
        public static LineBL makeLine()
        {
            PointBL begin = PointUI.takeCordinatesInput("BEGIN");
            PointBL end = PointUI.takeCordinatesInput("END");
            return new LineBL(begin, end);
        }
        public static void showLineLength(LineBL line)
        {
            Console.WriteLine($"THE LENGTH OF LINE IS : {line.getLength()}");
        }
        public static void showGradientofLine(LineBL Line)
        {
            Console.WriteLine($"THE GRADIENT OF LINE IS : {Line.getGradient()}");
        }
    }
}
