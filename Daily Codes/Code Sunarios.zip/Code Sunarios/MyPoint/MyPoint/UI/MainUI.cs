﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyPoint.UI
{
    class MainUI
    {
        public static int MainMenu()
        {
            Console.WriteLine("1.MAKE A LINE");
            Console.WriteLine("2.UPDATE THE BEGIN POINT");
            Console.WriteLine("3.UPDATE TH EEND POINT");
            Console.WriteLine("4.SHOW THE UPDATED BEGIN POINT");
            Console.WriteLine("5.SHOW THE UPDATED END POINT");
            Console.WriteLine("6.GET THE LENGHT OF THE LINE");
            Console.WriteLine("7.GET THE GRADIENT OF THE LINE");
            Console.WriteLine("8.FIND THE DISTANCE OF BEGIN POINT FORM ZERO CORDIENATES");
            Console.WriteLine("9.FIND THE DISTANCE OF END POINT FORM ZERO CORDIENATES");
            Console.WriteLine("10.EXIT");
            int op = int.Parse(Console.ReadLine());
            return op;
        }
        public static void ClearScreen()
        {
            Console.WriteLine("PRESS ANY KER TO CONTINUE...");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
