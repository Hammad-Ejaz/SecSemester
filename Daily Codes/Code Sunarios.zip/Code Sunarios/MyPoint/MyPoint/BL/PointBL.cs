﻿using System;

namespace MyPoint.BL
{
    class PointBL
    {
        int x;
        int y;
        public PointBL()
        {
            x = 0;
            y = 0;
        }
        public PointBL(int x, int y)
        {
            this.x = x;
            this.y = y;
        }

        public int getX() => x;
        public int getY() => y;
        public void setX(int x) => this.x = x;
        public void setY(int y) => this.y = y;
        public void setXY(int x, int y)
        {
            this.x = x;
            this.y = y;
        }
        public double distanceWithCords(int x, int y)
        {
            double d;
            d = Math.Sqrt(Math.Pow(this.x - x, 2) + Math.Pow(this.y - y, 2));
            return d;
        }
        public double distanceWithObject(PointBL p)
        {
            double d;
            d = Math.Sqrt(Math.Pow(x - p.x, 2) + Math.Pow(y - p.x, 2));
            return d;
        }
        public double distanceFronZero()
        {
            double d;
            d = Math.Sqrt(Math.Pow(x - 0, 2) + Math.Pow(y - 0, 2));
            return d;
        }
    }
}
