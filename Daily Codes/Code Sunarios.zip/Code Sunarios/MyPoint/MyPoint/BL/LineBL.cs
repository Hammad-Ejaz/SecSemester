﻿using System;
namespace MyPoint.BL
{
    class LineBL
    {
        private PointBL begin;
        private PointBL end;
        public LineBL()
        {
            begin = new PointBL();
            end = new PointBL();
        }
        public LineBL(PointBL begin, PointBL end)
        {
            this.begin = begin;
            this.end = end;
        }
        public PointBL getBegin() => begin;
        public void setBegin(PointBL begin) => this.begin = begin;
        public PointBL getEnd() => end;
        public void setEnd(PointBL end) => this.end = end;
        public double getLength()
        {
            double d;
            d = Math.Sqrt(Math.Pow(end.getX() - begin.getX(), 2) + Math.Pow(end.getY() - begin.getY(), 2));
            return d;
        }
        public double getGradient()
        {
            double d;
            d = ((end.getY() - begin.getY()) / (end.getX() - begin.getY()));
            return d;
        }
    }
}
