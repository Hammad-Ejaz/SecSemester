﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.BL;
namespace store.DL
{
    class ProductDL
    {
        static List<ProductsBL> products = new List<ProductsBL>();
        public static void storeintoFile(string path)
        {
            StreamWriter f = new StreamWriter(path);
            foreach (ProductsBL i in products)
            {
                f.WriteLine(i.getName() + "," + i.getCatagory() + "," + i.getPrice() + "," + i.getQuantity() + "," + i.getMinquantity() + "," + i.getTax());
            }
            f.Flush();
            f.Close();
        }
        public static void readFromFile(string path)
        {
            string record;
            if (File.Exists(path))
            {
                StreamReader f = new StreamReader(path);
                while ((record = f.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    for (int x = 0; x < splittedRecord.Length; x++)
                    {
                        string name = splittedRecord[0];
                        string catagory = splittedRecord[1];
                        float price = float.Parse(splittedRecord[2]);
                        int quantity = int.Parse(splittedRecord[3]);
                        int Minquantity = int.Parse(splittedRecord[4]);
                        float tax = float.Parse(splittedRecord[5]);
                        ProductsBL p = new ProductsBL(name, catagory, price, quantity, Minquantity);
                        p.setTax(tax);
                        products.Add(p);
                    }
                }
                f.Close();
            }
        }


        public static List<ProductsBL> higest()
        {
            List<ProductsBL> sorted = products.OrderByDescending(o => o.getPrice()).ToList();
            return sorted;
        }
        public static void Store(ProductsBL product)
        {
            products.Add(product);
        }
        public static ProductsBL isFoudProduct(string name)
        {
            for(int i = 0; i < products.Count; i++)
            {
                if (name == products[i].getName())
                {
                    products[i].decrementQuantity();
                    return products[i];
                }
            }
            return null;
        }
        public static List<ProductsBL> getProductsList()
        {
            return products;
        }

    }
}
