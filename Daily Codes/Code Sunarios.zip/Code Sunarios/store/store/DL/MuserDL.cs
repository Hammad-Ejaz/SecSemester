﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.BL;
namespace store.DL
{
    class MuserDL
    {
        static List<MuserBL> login = new List<MuserBL>();
        public static bool CheckUser(string name, string password ,string role)
        {
            foreach (MuserBL i in login)
            { 
                if (name == i.getUserName() && password == i.getUserPassword() && role == i.getUserRole())return true;
            }
            return false;
        }
        public static void adduseritoList(string Newname, string NewPassword , string NewRole)
        {
            MuserBL log = new MuserBL(Newname,NewPassword , NewRole);
            login.Add(log);
        }
        public static void SaveData(string path)
        {
            StreamWriter newfile = new StreamWriter(path);
            foreach(MuserBL i in login)
            {
                newfile.WriteLine(i.getUserName() + "," + i.getUserPassword() + "," + i.getUserRole());
            }
            newfile.Flush();
            newfile.Close();
        }
        public static void LoadData(string path)
        {
            if (File.Exists(path))
            {
                string record;
                StreamReader newfile = new StreamReader(path);
                while ((record = newfile.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string Name = splittedRecord[0];
                    string Password = splittedRecord[1];
                    string Role = splittedRecord[2];
                    MuserBL log = new MuserBL(Name , Password , Role);
                    login.Add(log);
                }
                newfile.Close();
            }
        }

    }
}

