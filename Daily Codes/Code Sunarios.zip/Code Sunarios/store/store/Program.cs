﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.UI;
using store.BL;
using store.DL;

namespace store
{
    class Program
    {
        static void Main(string[] args)
        {
            MuserDL.LoadData("Store.txt");
            ProductDL.readFromFile("product.txt");
            uint option = 0;
            while (option != 3)
            {
                option = MuserUI.Loginmenue();
                if (option == 1)
                {
                    MuserBL user = MuserUI.Login();
                    if (user != null)
                    {
                        if (user.isAdmin())
                        { uint choice = 0;
                            while (choice != 6)
                            {
                                choice = ProductUI.AdminMenu();
                                if(choice == 1)
                                {
                                    ProductDL.Store((ProductUI.inputToAddProducts()));
                                }
                                else if (choice == 2)
                                {
                                    ProductUI.ViewAllProducts();
                                }
                                else if (choice == 3)
                                {
                                    ProductUI.higestPricedPro();
                                }
                                else if (choice == 4)
                                {
                                    ProductUI.ViewAllProductsTaxes();
                                }
                                else if (choice == 5)
                                {
                                    ProductUI.ViewOrderProduct();
                                }
                                MuserUI.ClearScreen();
                            }
                            ProductDL.storeintoFile("product.txt");
                        }
                        else
                        {
                            int uChoice = 0;
                            while(uChoice != 4)
                            {
                                CoustomerBL coustomer = new CoustomerBL();
                                if(uChoice == 1)
                                {
                                    CoustomerUI.ViewAllProducts();
                                }
                                else if (uChoice == 2)
                                {
                                    coustomer.AddProduct((CoustomerUI.inputToOrderProducts()));
                                }
                                else if (uChoice == 3)
                                {
                                    CoustomerUI.GenerateInvoice(coustomer);
                                }
                            }
                        }
                    }
                }
                else if (option == 2)
                {    
                    MuserUI.SignUp();
                    MuserDL.SaveData("Store.txt");
                    MuserUI.ClearScreen();
                }
            } 
        }
        
    }
}
