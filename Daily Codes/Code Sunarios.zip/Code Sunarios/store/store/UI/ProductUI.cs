﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.BL;
using store.DL;
namespace store.UI
{
    class ProductUI
    {
        public static uint AdminMenu()
        {
            uint op;
            Console.WriteLine("1_Add Product. ");
            Console.WriteLine("2_View All Product. ");
            Console.WriteLine("3_Higest Priced Product. ");
            Console.WriteLine("4_Sale taxes. ");
            Console.WriteLine("5_ordered products. ");
            Console.WriteLine("6.Back");
            op = uint.Parse(Console.ReadLine());
            return op;
        }

        public static ProductsBL inputToAddProducts()
        {
            Console.WriteLine("enter name :");
            string name = Console.ReadLine();
            Console.WriteLine("enter catagory :");
            string catagory = Console.ReadLine();
            Console.WriteLine("enter price :");
            int price = int.Parse(Console.ReadLine());
            Console.WriteLine("enter stock quantity :");
            int quantity = int.Parse(Console.ReadLine());
            Console.WriteLine("enter minimum stock quantity :");
            int Minquantity = int.Parse(Console.ReadLine());
            ProductsBL product = new ProductsBL(name, catagory, price, quantity, Minquantity);
            return product;
        }
        public static void ViewAllProducts()
        {
            foreach (ProductsBL i in ProductDL.getProductsList())
            {
                Console.WriteLine("name :" + i.getName());
                Console.WriteLine("catagory :" + i.getCatagory());
                Console.WriteLine("price :" + i.getPrice());
                Console.WriteLine("stock quantity :" + i.getQuantity());
                Console.WriteLine("minimum stock quantity :" + i.getMinquantity());
                Console.WriteLine();
            }
        }
        public static void higestPricedPro()
        {
            Console.WriteLine($"the higest priced product if : {ProductDL.higest()[0].getName()} ");
        }
        public static void ViewAllProductsTaxes()
        {
            foreach (ProductsBL i in ProductDL.getProductsList())
            {
                i.calculateTax();
                Console.WriteLine("the tax of " + i.getName() + " is :" + i.getTax());
            }
        }
        public static void ViewOrderProduct()
        {
            foreach (ProductsBL i in ProductDL.getProductsList())
            {
                if(i.getQuantity() <= i.getMinquantity())
                Console.WriteLine("the order product is :" + i.getName());
            }
        }
    }
}