﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.BL;
using store.DL;
namespace store.UI
{
    class CoustomerUI
    {

        public static uint UserMenu()
        {
            uint op;
            Console.WriteLine("1.View All Product");
            Console.WriteLine("2.Buy the product");
            Console.WriteLine("3.Generate Invoice");
            Console.WriteLine("4.Back");
            op = uint.Parse(Console.ReadLine());
            return op;
        }
        public static void ViewAllProducts()
        {
            foreach (ProductsBL i in ProductDL.getProductsList())
            {
                Console.WriteLine("name :" + i.getName());
                Console.WriteLine("catagory :" + i.getCatagory());
                Console.WriteLine("price :" + i.getPrice());
                Console.WriteLine();
            }
        }
        public static ProductsBL inputToOrderProducts()
        {
            Console.WriteLine("enter name :");
            string name = Console.ReadLine();
            Console.WriteLine("enter catagory :");
            string catagory = Console.ReadLine();
            if (ProductDL.isFoudProduct(name) != null)
            {
                return ProductDL.isFoudProduct(name);
            }
            else
            {
                Console.WriteLine("not found...");
                return null;
            }
        }
        public static void GenerateInvoice(CoustomerBL coustomer)
        {
            double GrandTotal = 0 ;
            foreach (ProductsBL i in coustomer.getOrderProducts())
            {
                Console.WriteLine("name " + i.getName());
                Console.Write(" catagory " + i.getCatagory());
                Console.Write(" Price " + i.getPrice());
                i.calculateTax();
                Console.Write(" Tax " + i.getTax());
                Console.Write(" Total Price" + coustomer.totalPrice(i));
                GrandTotal += coustomer.totalPrice(i);
            }
            Console.WriteLine("Grand Total Price " + GrandTotal);
        }
    }
}
