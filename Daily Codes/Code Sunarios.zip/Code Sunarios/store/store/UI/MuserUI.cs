﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using store.DL;
using store.BL;
namespace store.UI
{
    class MuserUI
    {
        public static uint Loginmenue()
        {
            uint op;
            Console.WriteLine("1.Login");
            Console.WriteLine("2.Sign Up");
            Console.WriteLine("3.Exit");
            op = uint.Parse(Console.ReadLine());
            return op;
        }
        public static void SignUp()
        {
            string NewName, NewPassword , NewRole;
            Console.WriteLine("Name: ");
            NewName = Console.ReadLine();
            Console.WriteLine("Password: ");
            NewPassword = Console.ReadLine();
            Console.WriteLine("Role: ");
            NewRole = Console.ReadLine();
            MuserDL.adduseritoList(NewName, NewPassword , NewRole);
        }
        public static MuserBL Login()
        {
            string name, password , role;
            Console.WriteLine("Name: ");
            name = Console.ReadLine();
            Console.WriteLine("Password: ");
            password = Console.ReadLine();
            Console.WriteLine("Role: ");
            role = Console.ReadLine();
            if (MuserDL.CheckUser(name, password , role))
            {
                Console.WriteLine("valid user");
                MuserBL u = new MuserBL(name, password, role);
                return u;
            }
            else
            {
                Console.WriteLine("invalid user");
                return null;
            }
        }
        public static void ClearScreen()
        {
            Console.WriteLine("press any key to back...");
            Console.ReadKey();
            Console.Clear();
        }
    }
}
