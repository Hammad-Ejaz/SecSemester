﻿using System.Collections.Generic;

namespace store.BL
{
    class CoustomerBL
    {
        List<ProductsBL> orderProducts = new List<ProductsBL>();
        public void AddProduct(ProductsBL product)
        {
            orderProducts.Add(product);
        }
        public double totalPrice(ProductsBL product)
        {
            return product.getTax() + product.getPrice();
        }
        public List<ProductsBL> getOrderProducts()
        {
            return orderProducts;
        }
    }
}
