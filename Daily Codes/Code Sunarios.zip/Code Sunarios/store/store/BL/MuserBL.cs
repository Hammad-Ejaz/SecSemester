﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace store.BL
{
    class MuserBL
    {
        public MuserBL(string name , string password)
        {
            this.Name = name;
            this.Password = password;
        }
        public MuserBL(string name, string password ,string Role)
        {
            this.Name = name;
            this.Password = password;
            this.Role = Role;
        }
        private string Name;
        private string Password;
        private string Role;
        public string getUserName() => Name;
        public string getUserPassword() => Password;
        public string getUserRole() => Role;
        public bool isAdmin()
        {
            if (Role == "admin") return true;
            else return false;
        }
    }
}
