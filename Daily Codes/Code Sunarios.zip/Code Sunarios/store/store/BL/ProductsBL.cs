﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace store.BL
{
    class ProductsBL
    {
        public ProductsBL() {}
        public ProductsBL(string name)
        {
            this.name = name;
        }
        public ProductsBL(string name , string catagory)
        {
            this.name = name;
            this.catagory = catagory;
        }
        public ProductsBL(string name, string catagory, int price)
        {
            this.name = name;
            this.catagory = catagory;
            this.price = price;
        }
        public ProductsBL(string name , string catagory , int price , int quantity)
        {
            this.name = name;
            this.catagory = catagory;
            this.price = price;
            this.quantity = quantity;
        }
        public ProductsBL(string name, string catagory , float price, int quantity, int Minquantity)
        {
            this.name = name;
            this.catagory = catagory;
            this.price = price;
            this.quantity = quantity;
            this.Minquantity = Minquantity;
        }
        private string name;
        private string catagory;
        private float price;
        private int quantity;
        private int Minquantity;
        private float tax;
        public string getName() => name;     
        public void decrementQuantity() => quantity--;
        public string getCatagory() => catagory;
        public float getPrice() => price;
        public int getQuantity() => quantity;
        public int getMinquantity() => Minquantity;
        public float getTax() => tax;


        public void setName(string name) => this.name = name;
        public void setCatagory(string catagory) => this.catagory = catagory;
        public void setPrice(float price) => this.price = price;
        public void setQuantity(int quantity) => this.quantity = quantity;
        public void setMinquantity(int Minquantity) => this.Minquantity= Minquantity;
        public void setTax(float tax) => this.tax = tax ;

        public void calculateTax()
        {
            if(catagory == "grocery")tax = (price *10)/100;
            else if (catagory == "fruit") tax = (price * 5) / 100;
            else tax = (price * 15) / 100;
        }

    }
}

