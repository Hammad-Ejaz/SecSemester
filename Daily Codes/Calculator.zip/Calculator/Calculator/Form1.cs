﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        string num;
        Char operation =' ';
        float total = 0.0F;
        public Form1()
        {
            InitializeComponent();
        }

        private void Button15_Click(object sender, EventArgs e)
        {
                    }

        private void Button11_Click(object sender, EventArgs e)
        {
                    }

        private void Button7_Click(object sender, EventArgs e)
        {
            TextBox.Text = " ";
            if (operation != ' ')
            {
                if (operation == '+') total = (total + float.Parse(num));
                else if (operation == '-') total = (total - float.Parse(num));
                else if (operation == '*') total = (total * float.Parse(num));
                else if (operation == '/') total = (total / float.Parse(num));
            }
            else total = float.Parse(num);
            TextBox.Text = total.ToString();
            operation = '-';
            num = " ";
        }
        private void Button4_Click(object sender, EventArgs e)
        {
            if(operation != ' ') TextBox.Text = "";
            TextBox.Text += "1";
            num = TextBox.Text;
        }

        private void Button5_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "2";
            num = TextBox.Text;
        }

        private void Button16_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "9";
            num = TextBox.Text;
        }

        private void Cmd3_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "3";
            num = TextBox.Text;
        }

        private void Cmd4_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "4";
            num = TextBox.Text;
        }

        private void Cmd5_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "5";
            num = TextBox.Text;
        }

        private void Cmd6_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "6";
            num = TextBox.Text;
        }

        private void Cmd7_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "7";
            num = TextBox.Text;
        }

        private void Cmd8_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "8";
            num = TextBox.Text;
        }

        private void Cmd0_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += "0";
            num = TextBox.Text;
        }

        private void CmdPoint_Click(object sender, EventArgs e)
        {
            if (operation != ' ') TextBox.Text = "";
            TextBox.Text += ".";
            num = TextBox.Text;
        }

        private void CmdPlus_Click(object sender, EventArgs e)
        {
            TextBox.Text = " ";
            if (operation != ' ')
            {
                if (operation == '+') total = (total + float.Parse(num));
                else if (operation == '-') total = (total - float.Parse(num));
                else if (operation == '*') total = (total * float.Parse(num));
                else if (operation == '/') total = (total / float.Parse(num));
            }
            else total = float.Parse(num);
            TextBox.Text = total.ToString();
            operation = '+';
            num = "";
        }

        private void CmdMultiply_Click(object sender, EventArgs e)
        {
            TextBox.Text = " ";
            if (operation != ' ')
            {
                if (operation == '+') total = (total + float.Parse(num));
                else if (operation == '-') total = (total - float.Parse(num));
                else if (operation == '*') total = (total * float.Parse(num));
                else if (operation == '/') total = (total / float.Parse(num));
            }
            else total = float.Parse(num);
            TextBox.Text = total.ToString();
            operation = '*';
            num = "";
        }

        private void CmdDivide_Click(object sender, EventArgs e)
        {
            TextBox.Text = " ";
            if (operation != ' ')
            {
                if (operation == '+') total = (total + float.Parse(num));
                else if (operation == '-') total = (total - float.Parse(num));
                else if (operation == '*') total = (total * float.Parse(num));
                else if (operation == '/') total = (total / float.Parse(num));
            }
            else total = float.Parse(num);
            TextBox.Text = total.ToString();
            operation = '/';
            num = "";
        }

        private void CmdEqual_Click(object sender, EventArgs e)
        {
            if(operation == '+') TextBox.Text = (total + float.Parse(TextBox.Text)).ToString();
            else if (operation == '-') TextBox.Text = (total - float.Parse(TextBox.Text)).ToString();
            else if (operation == '*') TextBox.Text = (total * float.Parse(TextBox.Text)).ToString();
            else if (operation == '/') TextBox.Text = (total / float.Parse(TextBox.Text)).ToString();
        }

        private void CmdCLearAll_Click(object sender, EventArgs e)
        {
            TextBox.Text = TextBox.Text.Substring(0, TextBox.Text.Length - 1);
        }

        private void CmdClear_Click(object sender, EventArgs e)
        {
            TextBox.Text = "";
            operation = ' ';
            num = "";
        }
    }
}
