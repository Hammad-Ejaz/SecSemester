﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TextBox = new System.Windows.Forms.TextBox();
            this.cmd0 = new System.Windows.Forms.Button();
            this.cmdPoint = new System.Windows.Forms.Button();
            this.Backlbl = new System.Windows.Forms.Label();
            this.cmdPlus = new System.Windows.Forms.Button();
            this.cmd1 = new System.Windows.Forms.Button();
            this.cmd2 = new System.Windows.Forms.Button();
            this.cmd3 = new System.Windows.Forms.Button();
            this.cmdMinus = new System.Windows.Forms.Button();
            this.cmd4 = new System.Windows.Forms.Button();
            this.cmd5 = new System.Windows.Forms.Button();
            this.cmdEqual = new System.Windows.Forms.Button();
            this.cmd6 = new System.Windows.Forms.Button();
            this.cmdMultiply = new System.Windows.Forms.Button();
            this.cmdClear = new System.Windows.Forms.Button();
            this.cmd7 = new System.Windows.Forms.Button();
            this.cmd8 = new System.Windows.Forms.Button();
            this.cmd9 = new System.Windows.Forms.Button();
            this.cmdDivide = new System.Windows.Forms.Button();
            this.cmdCLearAll = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TextBox
            // 
            this.TextBox.Location = new System.Drawing.Point(229, 61);
            this.TextBox.Multiline = true;
            this.TextBox.Name = "TextBox";
            this.TextBox.Size = new System.Drawing.Size(329, 59);
            this.TextBox.TabIndex = 1;
            // 
            // cmd0
            // 
            this.cmd0.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd0.Location = new System.Drawing.Point(229, 346);
            this.cmd0.Name = "cmd0";
            this.cmd0.Size = new System.Drawing.Size(128, 53);
            this.cmd0.TabIndex = 2;
            this.cmd0.Text = "0";
            this.cmd0.UseVisualStyleBackColor = true;
            this.cmd0.Click += new System.EventHandler(this.Cmd0_Click);
            // 
            // cmdPoint
            // 
            this.cmdPoint.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPoint.Location = new System.Drawing.Point(363, 346);
            this.cmdPoint.Name = "cmdPoint";
            this.cmdPoint.Size = new System.Drawing.Size(61, 53);
            this.cmdPoint.TabIndex = 3;
            this.cmdPoint.Text = ".";
            this.cmdPoint.UseVisualStyleBackColor = true;
            this.cmdPoint.Click += new System.EventHandler(this.CmdPoint_Click);
            // 
            // Backlbl
            // 
            this.Backlbl.BackColor = System.Drawing.Color.Silver;
            this.Backlbl.Font = new System.Drawing.Font("MT Extra", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Backlbl.ForeColor = System.Drawing.SystemColors.WindowFrame;
            this.Backlbl.Location = new System.Drawing.Point(212, 29);
            this.Backlbl.Name = "Backlbl";
            this.Backlbl.Size = new System.Drawing.Size(364, 384);
            this.Backlbl.TabIndex = 0;
            this.Backlbl.Text = "CALCULATOR";
            this.Backlbl.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // cmdPlus
            // 
            this.cmdPlus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdPlus.Location = new System.Drawing.Point(430, 346);
            this.cmdPlus.Name = "cmdPlus";
            this.cmdPlus.Size = new System.Drawing.Size(61, 53);
            this.cmdPlus.TabIndex = 4;
            this.cmdPlus.Text = "+";
            this.cmdPlus.UseVisualStyleBackColor = true;
            this.cmdPlus.Click += new System.EventHandler(this.CmdPlus_Click);
            // 
            // cmd1
            // 
            this.cmd1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd1.Location = new System.Drawing.Point(229, 272);
            this.cmd1.Name = "cmd1";
            this.cmd1.Size = new System.Drawing.Size(61, 54);
            this.cmd1.TabIndex = 5;
            this.cmd1.Text = "1";
            this.cmd1.UseVisualStyleBackColor = true;
            this.cmd1.Click += new System.EventHandler(this.Button4_Click);
            // 
            // cmd2
            // 
            this.cmd2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd2.Location = new System.Drawing.Point(296, 272);
            this.cmd2.Name = "cmd2";
            this.cmd2.Size = new System.Drawing.Size(61, 54);
            this.cmd2.TabIndex = 6;
            this.cmd2.Text = "2";
            this.cmd2.UseVisualStyleBackColor = true;
            this.cmd2.Click += new System.EventHandler(this.Button5_Click);
            // 
            // cmd3
            // 
            this.cmd3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd3.Location = new System.Drawing.Point(363, 272);
            this.cmd3.Name = "cmd3";
            this.cmd3.Size = new System.Drawing.Size(61, 54);
            this.cmd3.TabIndex = 7;
            this.cmd3.Text = "3";
            this.cmd3.UseVisualStyleBackColor = true;
            this.cmd3.Click += new System.EventHandler(this.Cmd3_Click);
            // 
            // cmdMinus
            // 
            this.cmdMinus.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdMinus.Location = new System.Drawing.Point(430, 272);
            this.cmdMinus.Name = "cmdMinus";
            this.cmdMinus.Size = new System.Drawing.Size(61, 54);
            this.cmdMinus.TabIndex = 8;
            this.cmdMinus.Text = "-";
            this.cmdMinus.UseVisualStyleBackColor = true;
            this.cmdMinus.Click += new System.EventHandler(this.Button7_Click);
            // 
            // cmd4
            // 
            this.cmd4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd4.Location = new System.Drawing.Point(229, 202);
            this.cmd4.Name = "cmd4";
            this.cmd4.Size = new System.Drawing.Size(61, 52);
            this.cmd4.TabIndex = 9;
            this.cmd4.Text = "4";
            this.cmd4.UseVisualStyleBackColor = true;
            this.cmd4.Click += new System.EventHandler(this.Cmd4_Click);
            // 
            // cmd5
            // 
            this.cmd5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd5.Location = new System.Drawing.Point(296, 202);
            this.cmd5.Name = "cmd5";
            this.cmd5.Size = new System.Drawing.Size(61, 52);
            this.cmd5.TabIndex = 10;
            this.cmd5.Text = "5";
            this.cmd5.UseVisualStyleBackColor = true;
            this.cmd5.Click += new System.EventHandler(this.Cmd5_Click);
            // 
            // cmdEqual
            // 
            this.cmdEqual.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdEqual.Location = new System.Drawing.Point(497, 272);
            this.cmdEqual.Name = "cmdEqual";
            this.cmdEqual.Size = new System.Drawing.Size(61, 127);
            this.cmdEqual.TabIndex = 11;
            this.cmdEqual.Text = "=";
            this.cmdEqual.UseVisualStyleBackColor = true;
            this.cmdEqual.Click += new System.EventHandler(this.CmdEqual_Click);
            // 
            // cmd6
            // 
            this.cmd6.Font = new System.Drawing.Font("Microsoft YaHei Light", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd6.Location = new System.Drawing.Point(363, 202);
            this.cmd6.Name = "cmd6";
            this.cmd6.Size = new System.Drawing.Size(61, 52);
            this.cmd6.TabIndex = 12;
            this.cmd6.Text = "6";
            this.cmd6.UseVisualStyleBackColor = true;
            this.cmd6.Click += new System.EventHandler(this.Cmd6_Click);
            // 
            // cmdMultiply
            // 
            this.cmdMultiply.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdMultiply.Location = new System.Drawing.Point(430, 202);
            this.cmdMultiply.Name = "cmdMultiply";
            this.cmdMultiply.Size = new System.Drawing.Size(61, 52);
            this.cmdMultiply.TabIndex = 13;
            this.cmdMultiply.Text = "*";
            this.cmdMultiply.UseVisualStyleBackColor = true;
            this.cmdMultiply.Click += new System.EventHandler(this.CmdMultiply_Click);
            // 
            // cmdClear
            // 
            this.cmdClear.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdClear.Location = new System.Drawing.Point(497, 202);
            this.cmdClear.Name = "cmdClear";
            this.cmdClear.Size = new System.Drawing.Size(61, 52);
            this.cmdClear.TabIndex = 14;
            this.cmdClear.Text = "C";
            this.cmdClear.UseVisualStyleBackColor = true;
            this.cmdClear.Click += new System.EventHandler(this.CmdClear_Click);
            // 
            // cmd7
            // 
            this.cmd7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd7.Location = new System.Drawing.Point(229, 136);
            this.cmd7.Name = "cmd7";
            this.cmd7.Size = new System.Drawing.Size(61, 50);
            this.cmd7.TabIndex = 15;
            this.cmd7.Text = "7";
            this.cmd7.UseVisualStyleBackColor = true;
            this.cmd7.Click += new System.EventHandler(this.Cmd7_Click);
            // 
            // cmd8
            // 
            this.cmd8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd8.Location = new System.Drawing.Point(296, 136);
            this.cmd8.Name = "cmd8";
            this.cmd8.Size = new System.Drawing.Size(61, 50);
            this.cmd8.TabIndex = 16;
            this.cmd8.Text = "8";
            this.cmd8.UseVisualStyleBackColor = true;
            this.cmd8.Click += new System.EventHandler(this.Cmd8_Click);
            // 
            // cmd9
            // 
            this.cmd9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmd9.Location = new System.Drawing.Point(363, 136);
            this.cmd9.Name = "cmd9";
            this.cmd9.Size = new System.Drawing.Size(61, 50);
            this.cmd9.TabIndex = 17;
            this.cmd9.Text = "9";
            this.cmd9.UseVisualStyleBackColor = true;
            this.cmd9.Click += new System.EventHandler(this.Button16_Click);
            // 
            // cmdDivide
            // 
            this.cmdDivide.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdDivide.Location = new System.Drawing.Point(430, 136);
            this.cmdDivide.Name = "cmdDivide";
            this.cmdDivide.Size = new System.Drawing.Size(61, 50);
            this.cmdDivide.TabIndex = 18;
            this.cmdDivide.Text = "/";
            this.cmdDivide.UseVisualStyleBackColor = true;
            this.cmdDivide.Click += new System.EventHandler(this.CmdDivide_Click);
            // 
            // cmdCLearAll
            // 
            this.cmdCLearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmdCLearAll.Location = new System.Drawing.Point(497, 136);
            this.cmdCLearAll.Name = "cmdCLearAll";
            this.cmdCLearAll.Size = new System.Drawing.Size(61, 50);
            this.cmdCLearAll.TabIndex = 19;
            this.cmdCLearAll.Text = "CE";
            this.cmdCLearAll.UseVisualStyleBackColor = true;
            this.cmdCLearAll.Click += new System.EventHandler(this.CmdCLearAll_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(838, 563);
            this.Controls.Add(this.cmdCLearAll);
            this.Controls.Add(this.cmdDivide);
            this.Controls.Add(this.cmd9);
            this.Controls.Add(this.cmd8);
            this.Controls.Add(this.cmd7);
            this.Controls.Add(this.cmdClear);
            this.Controls.Add(this.cmdMultiply);
            this.Controls.Add(this.cmd6);
            this.Controls.Add(this.cmdEqual);
            this.Controls.Add(this.cmd5);
            this.Controls.Add(this.cmd4);
            this.Controls.Add(this.cmdMinus);
            this.Controls.Add(this.cmd3);
            this.Controls.Add(this.cmd2);
            this.Controls.Add(this.cmd1);
            this.Controls.Add(this.cmdPlus);
            this.Controls.Add(this.cmdPoint);
            this.Controls.Add(this.cmd0);
            this.Controls.Add(this.TextBox);
            this.Controls.Add(this.Backlbl);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox TextBox;
        private System.Windows.Forms.Button cmd0;
        private System.Windows.Forms.Button cmdPoint;
        private System.Windows.Forms.Label Backlbl;
        private System.Windows.Forms.Button cmdPlus;
        private System.Windows.Forms.Button cmd1;
        private System.Windows.Forms.Button cmd2;
        private System.Windows.Forms.Button cmd3;
        private System.Windows.Forms.Button cmdMinus;
        private System.Windows.Forms.Button cmd4;
        private System.Windows.Forms.Button cmd5;
        private System.Windows.Forms.Button cmdEqual;
        private System.Windows.Forms.Button cmd6;
        private System.Windows.Forms.Button cmdMultiply;
        private System.Windows.Forms.Button cmdClear;
        private System.Windows.Forms.Button cmd7;
        private System.Windows.Forms.Button cmd8;
        private System.Windows.Forms.Button cmd9;
        private System.Windows.Forms.Button cmdDivide;
        private System.Windows.Forms.Button cmdCLearAll;
    }
}

