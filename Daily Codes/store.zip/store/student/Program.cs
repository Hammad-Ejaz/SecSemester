﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.BL;

namespace student
{
    class Program
    {
        static List<Info> data = new List<Info>();
        static void Main(string[] args)
        {
            char op ='0';
            load();
            for (int i = 0; op != '4' ; i++)
            {
                op = Manu();
                if (op == '1')
                {
                    data.Add(Input());
                    store();
                }
                if(op == '2')
                {
                    Display();
                    Console.ReadKey();
                }
                if(op == '3')
                {
                    int total = 0;
                    for (int k = 0; k < data.Count; k++)
                    {
                        total += data[k].price;
                    }
                    Console.WriteLine($"the total worth price is : {total}");
                    Console.ReadKey();
                }
                if(op == '4')
                {
                    break;
                }
            }
        }
        static char Manu()
        {
            Console.Clear();
            char op;
            Console.WriteLine("1_Add Products.");
            Console.WriteLine("2.Show Products.");
            Console.WriteLine("3.Total Store Worth.");
            Console.WriteLine("4_Back.");
            op = char.Parse(Console.ReadLine());
            return op;
        }
        static Info Input()
        {
            
            Info data = new Info();
            Console.WriteLine("enter the Name of product :");
            data.name = Console.ReadLine();
            Console.WriteLine("enter the Brand Name :");
            data.BrandName = Console.ReadLine();
            Console.WriteLine("enter the Product ID :");
            data.ID = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the Price :");
            data.price = int.Parse(Console.ReadLine());
            Console.WriteLine("enter the catagory of product :");
            data.catagory = Console.ReadLine();
            Console.WriteLine("enter the country :");
            data.country = Console.ReadLine();
            Console.ReadKey();
            return data;
        }
        static void Display()
        {
            Console.Write("Name");
            Console.Write("\t");
            Console.Write("Brand Name");
            Console.Write("\t");
            Console.Write("ID");
            Console.Write("\t");
            Console.Write("price");
            Console.Write("\t");
            Console.Write("Catagory");
            Console.Write("\t");
            Console.Write("Country");
            Console.Write("\n");
            for (int i = 0; i < data.Count; i++)
            {
                Console.Write("\n");
                Console.Write(data[i].name);
                Console.Write("\t");
                Console.Write(data[i].BrandName);
                Console.Write("\t");
                Console.Write(data[i].ID);
                Console.Write("\t");
                Console.Write(data[i].price);
                Console.Write("\t");
                Console.Write(data[i].catagory);
                Console.Write("\t");
                Console.Write(data[i].country);
            }
        }
        static void store()
        {
            StreamWriter file = new StreamWriter("products.txt");
            for (int i = 0; i < data.Count; i++)
            {
                file.WriteLine("{0},{1},{2},{3},{4},{5}", data[i].name,data[i].BrandName,data[i].ID,data[i].price,data[i].catagory,data[i].country);
            }
            file.Flush();
            file.Close();
        }
        static string parsedata(string line , int field)
        {
            int comma = 1;
            string item = "";
           for(int i = 0; i < line.Length ;i++)
           {
                if(line[i] == ',')
                {
                    comma++;
                }
                else if (comma == field)
                {
                    item += line[i];
                }
           }
           return item;
        }
        static void load()
        { 
            StreamReader file = new StreamReader("products.txt");
            string record;
            while ((record = file.ReadLine()) != null)
            {
                Info recor;
                recor = new Info();
                recor.name = parsedata(record, 1);
                recor.BrandName = parsedata(record, 2);
                Console.WriteLine(parsedata(record, 3));
                recor.ID = int.Parse(parsedata(record, 3));
                recor.price = int.Parse(parsedata(record, 4));
                recor.catagory = parsedata(record, 5);
                recor.country = parsedata(record, 6);
                data.Add(recor);
            }
            file.Close();
        }
    }
}
