﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.BL
{
    class Info 
    {
        public string name;
        public int ID;
        public int price;
        public string catagory;
        public string BrandName;
        public string country;
    }
}
