﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Famework_1.BL;
using Famework_1.DL;
using EZInput;
namespace Consumer
{
    public partial class Form1 : Form
    {
        vertically ver;
        Preodically per;
        ManualMotion manual;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            per = new Preodically(Properties.Resources.dragon_left_3, 10, 10, 0, 500, 10);
            ver = new vertically(Properties.Resources.dragon_left_3, 10, 10 , 10);
            manual = new ManualMotion(Properties.Resources.dragon_left_3, 10 , 10 , 10);
            MoveDL.MotionAdded += Game_objectAdded;
            MoveDL.addMotionIntoList(ver); // add into framework list
            MoveDL.addMotionIntoList(per);
            MoveDL.addMotionIntoList(manual);
        }
        private void Game_objectAdded(object sender, EventArgs e)
        {
            PictureBox box = (PictureBox)sender;
            this.Controls.Add(box);
        }
        private void Timer1_Tick(object sender, EventArgs e)
        {
            MoveDL.updatAllMotion(); // update all the motion of frame work using list of Move parent class
        }
    }
}
