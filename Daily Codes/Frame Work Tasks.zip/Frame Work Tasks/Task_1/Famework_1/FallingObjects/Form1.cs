﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Famework_1;
namespace FallingObjects
{
    public partial class Form1 : Form
    {
        Random r = new Random();
        GameClass game;
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            game = new GameClass(10);
            game.GameobjectAdded += Game_objectAdded;
            game.addGameObject(Properties.Resources.balls, r.Next(0, 20), r.Next(0, 10));
        }

        private void Game_objectAdded(object sender, EventArgs e)
        {
            PictureBox box = (PictureBox)sender;
            this.Controls.Add(box);
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            game.Update();
        }
      /*  private void Game_objectAdded(object sender , EventArgs  e)
        {
            PictureBox box = (PictureBox)sender;
            this.Controls.Add(box);
        }
        */
    }
}
