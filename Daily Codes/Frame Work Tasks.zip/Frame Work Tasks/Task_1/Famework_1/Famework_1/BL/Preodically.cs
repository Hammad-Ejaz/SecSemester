﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace Famework_1.BL
{
    public class Preodically : Move
    {
        private int start;
        private int end;
        private int speed;
        private string direction = "left";
        public Preodically(Image img, int X, int Y, int start , int end , int speed)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = X;
            pb.Top = Y;
            this.start = start;
            this.end = end;
            this.Speed = speed;
        }
        public int Start { get => start; set => start = value; }
        public int End { get => end; set => end = value; }
        public int Speed { get => speed; set => speed = value; }

        public override void update()
        {
            if (direction == "left")
            {
                pb.Left -= speed;
                if (pb.Left == start) direction = "right";
            }
            if(direction == "right")
            {
                pb.Left += speed;
                if (pb.Left == end) direction = "left";
            }
        }
    }
}
