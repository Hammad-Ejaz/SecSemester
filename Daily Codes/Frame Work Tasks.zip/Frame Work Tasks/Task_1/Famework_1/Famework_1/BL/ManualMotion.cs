﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using EZInput;
namespace Famework_1.BL
{
    public class ManualMotion : Move
    {
        private int speed = 0;
        public ManualMotion(Image img, int X, int Y, int speed)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = X;
            pb.Top = Y;
            this.Speed = speed;
        }
        public int Speed { get => speed; set => speed = value;}
        public override void update()
        {
            if (Keyboard.IsKeyPressed(Key.LeftArrow)) pb.Left -= speed;
            if (Keyboard.IsKeyPressed(Key.RightArrow)) pb.Left += speed;
            if (Keyboard.IsKeyPressed(Key.UpArrow)) pb.Top -= speed;
            if (Keyboard.IsKeyPressed(Key.DownArrow)) pb.Top += speed;
        }
    }
}
