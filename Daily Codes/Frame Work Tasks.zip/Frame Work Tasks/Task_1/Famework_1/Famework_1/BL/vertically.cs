﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace Famework_1.BL
{
    public class vertically : Move
    {
        private int gravity = 0;
        public vertically(Image img , int X , int Y , int gravity)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = X;
            pb.Top = Y;
            this.gravity = gravity;
        }
        public int Gravity { get => gravity; set => gravity = value; }
        public override void  update()
        {
            pb.Top += gravity;
        }
    }
}
