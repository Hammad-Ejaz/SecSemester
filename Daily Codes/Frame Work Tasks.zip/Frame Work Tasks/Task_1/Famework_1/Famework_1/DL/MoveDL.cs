﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using Famework_1.BL;
namespace Famework_1.DL
{
    public class MoveDL
    {
        private static List<Move> allMotions = new List<Move>();
        private static EventHandler motionAdded;
        public static List<Move> AllMotions { get => allMotions;}
        public static EventHandler MotionAdded { get => motionAdded; set => motionAdded = value; }

        public static void addMotionIntoList(Move move)
        {
            AllMotions.Add(move);
            MotionAdded?.Invoke(move.Pb, EventArgs.Empty);
                     
        }
        public static void updatAllMotion()
        {
            foreach(Move i in allMotions)
            {
                i.update();
            }
        }

    }
}
