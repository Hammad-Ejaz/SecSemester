﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Famework_1.BL;
using System.Windows.Forms;
using System.Drawing;
namespace Consumer.Extend
{
    class ZigZag : Move // inherit with framework parent class {Move}
    {
        private int speed = 0;
        public ZigZag(Image img, int X, int Y, int speed)
        {
            pb = new PictureBox();
            pb.Image = img;
            pb.Width = img.Width;
            pb.Height = img.Height;
            pb.BackColor = Color.Transparent;
            pb.Left = X;
            pb.Top = Y;
            this.Speed = speed;
        }
        public int Speed { get => speed; set => speed = value; }
        public override void update() // parent abstract function i override it to add my extended motion
        {
            pb.Top += speed;
            pb.Left += speed;
        }
    }
}
