﻿using System.IO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myUserGUI.BL;
namespace myUserGUI.DL
{
    class InfoLeadDL
    {
        private static List<InfoClientsBL> infoClientsList = new List<InfoClientsBL>();

        public static List<InfoClientsBL> InfoClientsList { get => infoClientsList; set => infoClientsList = value; }

        
        public static void addLeadToList(InfoClientsBL Lead) => InfoClientsList.Add(Lead);
        public static List<InfoClientsBL> getLeadofSpecificSPO(string name)
        {
            List<InfoClientsBL> Leads = new List<InfoClientsBL>();
            foreach (InfoClientsBL i in InfoClientsList)
            {
                if (i.SpoName == name)
                { Leads.Add(i); }
            }
            return Leads;
        }
        public static void delLead(InfoClientsBL Lead) => InfoClientsList.Remove(Lead);
        public static void editLead(InfoClientsBL previous , InfoClientsBL update)
        {
            foreach(InfoClientsBL i in InfoClientsList)
            {
                if (i.Name == previous.Name)
                {
                    i.Name = update.Name;
                    i.Phone = update.Phone;
                    i.Project = update.Project;
                    i.Source = update.Source;
                    i.SpoName = update.SpoName;
                    i.Date = update.Date;
                }
            }
        }
        public static List<InfoClientsBL> getTodayLeadsOfSpecificSpo(string name)
        {
            List<InfoClientsBL> todayLeads = new List<InfoClientsBL>();
            List<InfoClientsBL> totalLeads = getLeadofSpecificSPO(name);
            DateTime date = DateTime.UtcNow.Date;
            foreach (InfoClientsBL lead in totalLeads)
            {
                if (lead.Date == date) todayLeads.Add(lead);
            }
            return todayLeads;
        }
        public static List<InfoClientsBL> TodayTotalLeads()
        {
            List<InfoClientsBL> TtodayLead = new List<InfoClientsBL>();
            DateTime date = DateTime.UtcNow.Date;
            foreach (InfoClientsBL i in InfoClientsList)
                if (i.Date == date) TtodayLead.Add(i);
            return TtodayLead;
        }
        public static InfoClientsBL getSpecificLead(string name)
        {
            foreach (InfoClientsBL i in InfoClientsList)
            { if (i.Name == name) return i; }
            return null;
        }
        public static int getTotalLeadsNo() => InfoClientsList.Count;
        public static int getClientNoBySchedule(string schedule , List<InfoClientsBL>Lead)
        {
            int no = 0;
            foreach (InfoClientsBL i in Lead)
            {
                if (i.Schedule == schedule) no++;
            }
            return no;
        }
        public static void saveData(string path)
        {
            StreamWriter file = new StreamWriter(path);
            foreach (InfoClientsBL i in InfoClientsList)
            {
                file.WriteLine(i.Name + "," + i.SpoName + "," + i.Phone + "," + i.Project + "," + i.Schedule + "," + i.Source + "," + i.DealDone + "," + i.Response + "," + i.Date);
            }
            file.Flush();
            file.Close();
        }
        public static void loadData(string path)
        {
            infoClientsList = new List<InfoClientsBL>();
            if (File.Exists(path))
            {
                string record;
                StreamReader newfile = new StreamReader(path);
                while ((record = newfile.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string spoName = splittedRecord[1];
                    string phone = splittedRecord[2];
                    string project = splittedRecord[3];
                    string schedule = splittedRecord[4];
                    string source = splittedRecord[5];
                    bool DealDone = bool.Parse(splittedRecord[6]);
                    string Response = splittedRecord[7];
                    DateTime Date = DateTime.Parse(splittedRecord[8]);
                    InfoClientsBL lead = new InfoClientsBL(spoName, name, phone, project, source);
                    lead.Schedule = schedule;
                    lead.Response = Response;
                    lead.DealDone = DealDone;
                    lead.Date = Date;
                    InfoClientsList.Add(lead);
                }
                newfile.Close();
            }
        }
    }
}
