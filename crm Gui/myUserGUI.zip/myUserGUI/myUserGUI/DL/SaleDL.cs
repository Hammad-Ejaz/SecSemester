﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.DL
{
    class SaleDL
    {
        static List<SaleClientsBL> salesList = new List<SaleClientsBL>();
        public static void addSalesToList(SaleClientsBL sale) => salesList.Add(sale);
        public static List<SaleClientsBL> getTotalSalesList() => salesList;
        public static List<SaleClientsBL> getSaleofSpecificSPO(string name)
        {
            List<SaleClientsBL> sale = new List<SaleClientsBL>();
            foreach (SaleClientsBL i in salesList)
            {
                if (i.SpoName == name) sale.Add(i);
            }
            return sale;
        }
        public static void storeData(string path)
        {
            if (File.Exists(path))
            {
                StreamWriter file = new StreamWriter(path);
                foreach (SaleClientsBL i in salesList)
                {
                    file.WriteLine(i.SpoName + "," + i.Name + ',' + i.Phone + ',' + i.Project + ',' + i.Source + ',' + i.Cnic + ',' + i.Area + ',' + i.PlotNo + ',' + i.Price + ',' + i.BlockNoOrAddrees + ',' + i.City);
                }
                file.Flush();
                file.Close();
            }
        }

        public static void readData(string path)
        {
            salesList = new List<SaleClientsBL>();
            if (File.Exists(path))
            {
                string line;
                StreamReader file = new StreamReader(path);
                while ((line = file.ReadLine()) != null)
                {
                    string[] splitedArray = line.Split(',');
                    string spoName = splitedArray[0];
                    string Name = splitedArray[1];
                    string phone = splitedArray[2];
                    string project = splitedArray[3];
                    string source = splitedArray[4];
                    string cnic = splitedArray[5];
                    int area = int.Parse(splitedArray[6]);
                    int plotNo = int.Parse(splitedArray[7]);
                    int price = int.Parse(splitedArray[8]);
                    string blockNo = splitedArray[9];
                    string city = splitedArray[10];
                    SaleClientsBL sale = new SaleClientsBL(spoName, Name, phone, project, source, cnic, area, plotNo, price, blockNo, city);
                    salesList.Add(sale);
                }
                file.Close();
            }
        }

    }
}
