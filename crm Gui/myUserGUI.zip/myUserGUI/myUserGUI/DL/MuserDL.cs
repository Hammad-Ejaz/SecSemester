﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myUserGUI.BL;
namespace myUserGUI.DL
{
    class MuserDL
    {
        static List<MuserBL> myUsers = new List<MuserBL>();
        public static List<MuserBL> MyUsers { get => myUsers; set => myUsers = value; }
        public static void delUser(MuserBL user) => myUsers.Remove(user);
        public static void editUser(MuserBL previous , MuserBL update)
        {
            foreach(MuserBL user in MyUsers)
            {
                if(user.Email == previous.Email && user.Password == previous.Password && user.Category == previous.Category)
                {
                    user.Name = update.Name;
                    user.Email = update.Email;
                    user.Password = update.Password;
                    user.City = update.City;
                    user.Cnic = update.Cnic;
                    user.Category = update.Category;
                    user.PhoneNo = update.PhoneNo;
                }
            }
        }
        public static List<MuserBL> myEmployes()
        {
            List<MuserBL> employes = new List<MuserBL>();
            foreach (MuserBL i in myUsers)
            {
                if (i.Category != "Admin") employes.Add(i);
            }
            return employes;
        }
        public static MuserBL isValidUser(string email, string password)
        {
            foreach (MuserBL i in MyUsers)
            {
                if (email == i.Email && password == i.Password) return i;
            }
            return null;
        }
        public static void adduseritoList(MuserBL user)
        {
            MyUsers.Add(user);
        }
        public static void saveUserData(string path)
        {
            StreamWriter newfile = new StreamWriter(path);
            foreach (MuserBL i in MyUsers)
            {
                newfile.WriteLine(i.Name + "," + i.Email + "," + i.Password + "," + i.Category + "," + i.PhoneNo + "," + i.Cnic + "," + i.City);
            }
            newfile.Flush();
            newfile.Close();
        }
        public static void loadUserData(string path)
        {
            MyUsers = new List<MuserBL>(); 
            if (File.Exists(path))
            {
                string record;
                StreamReader newfile = new StreamReader(path);
                while ((record = newfile.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string name = splittedRecord[0];
                    string email = splittedRecord[1];
                    string password = splittedRecord[2];
                    string category = splittedRecord[3];
                    string phoneNo = splittedRecord[4];
                    string cnic = splittedRecord[5];
                    string city = splittedRecord[6];
                    MuserBL log = new MuserBL(name , email , password , category , phoneNo , cnic , city);
                    MyUsers.Add(log);
                }
                newfile.Close();
            }
        }
    }
}
