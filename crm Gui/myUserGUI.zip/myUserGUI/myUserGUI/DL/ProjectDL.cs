﻿using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myUserGUI.BL;
namespace myUserGUI.DL
{
    class ProjectDL
    {
       static List<ProjectBL> allProjects = new List<ProjectBL>();

        public static List<ProjectBL> AllProjects { get => allProjects; set => allProjects = value; }

        public static ProjectBL getSpecificProject(string name , string city)
        {
            foreach
                (ProjectBL i in allProjects) if (i.Name == name && i.City == city) return i;
            return null;
        }
        public static void EditProject(ProjectBL previous , ProjectBL update)
        {
            foreach(ProjectBL i in allProjects)
            {
                if (i.Name == previous.Name && i.City == previous.City)
                {
                    foreach(AreaBL j in i.Area)
                    {
                        if(j.Marla == update.Area[0].Marla)
                        {
                            j.Plots = update.Area[0].Plots;
                        }
                    }
                }
            }
        }
        public static void addProject(ProjectBL project) => allProjects.Add(project);
        public static void deleteProject(string name , string city)
        {
            ProjectBL project = getSpecificProject(name , city);
            if (project != null)
            {
                AllProjects.Remove(project);
            }
        }
        public static void storeData(string path)
        {
            if (File.Exists(path))
            {
                StreamWriter file = new StreamWriter(path);
                foreach (ProjectBL i in allProjects)
                {
                    string area = null;
                    for (int x = 0; x < i.Area.Count - 1; x++)
                    {
                        AreaBL j = i.Area[x];
                        area += j.Marla.ToString() + "_" + j.Plots.ToString() + "|";
                    }
                    area += i.Area[i.Area.Count - 1].Marla.ToString() + "_" + i.Area[i.Area.Count - 1].Plots.ToString();
                    file.WriteLine(i.Name + "," + i.City + ':' + area);
                }
                file.Flush();
                file.Close();
            }
        }
        public static void readData(string path)
        {
            allProjects = new List<ProjectBL>();
            if (File.Exists(path))
            {
                string line;
                StreamReader file = new StreamReader(path);
                while ((line = file.ReadLine()) != null)
                {
                    List<AreaBL> area = new List<AreaBL>();
                    string[] splitedArray = line.Split(':');
                    string[] projectinfo = splitedArray[0].Split(',');
                    string name = projectinfo[0];
                    string city = projectinfo[1];
                    ProjectBL project = new ProjectBL(name, city);
                    string[] areainfo = splitedArray[1].Split('|');
                    string[] sepratedAreaInfo = areainfo[0].Split('_');
                    int marla = int.Parse(sepratedAreaInfo[0]);
                    int plots = int.Parse(sepratedAreaInfo[1]);
                    AreaBL Area = new AreaBL(marla, plots);
                    area.Add(Area);
                    for (int i = 1; i < areainfo.Length; i++)
                    {
                        sepratedAreaInfo = areainfo[i].Split('_');
                        if (areainfo[i] == null) break;
                        marla = int.Parse(sepratedAreaInfo[0]);
                        plots = int.Parse(sepratedAreaInfo[1]);
                        AreaBL Area1 = new AreaBL(marla, plots);
                        area.Add(Area1);
                    }
                    project.Area = area;
                    ProjectDL.addProject(project);
                }
                file.Close();
            }
        }
    }
}
