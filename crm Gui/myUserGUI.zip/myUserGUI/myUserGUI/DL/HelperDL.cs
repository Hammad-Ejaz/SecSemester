﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.DL
{
    class HelperDL
    {
        public static bool isValidEMAIL(string text)
        {
            int atIndex = -1, dotIndex = -1;
            for (int i = 0; i < text.Length; i++)
            {
                if (text[i] == '@')
                {
                    atIndex = i;
                    break;
                }
            }
            if (atIndex != -1)
            {
                for (int i = atIndex; i < text.Length; i++)
                {
                    if (text[i] == '.')
                    {
                        dotIndex = i;
                        break;
                    }
                }
            }
            if (atIndex != -1 && dotIndex != -1)
            {
                return true;
            }
            return false;
        }
    }
}
