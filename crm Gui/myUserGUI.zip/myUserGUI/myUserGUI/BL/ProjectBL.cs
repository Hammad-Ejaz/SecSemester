﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    public class ProjectBL
    {
        public ProjectBL(string name, string city)
        {
            this.name = name;
            this.city = city;
            area = new List<AreaBL>();
        }
        private string name;
        private string city;
        private List<AreaBL> area;

        public string Name { get => name; set => name = value; }
        public string City { get => city; set => city = value; }
        public List<AreaBL> Area { get => area; set => area = value; }

        internal DL.ProjectDL ProjectDL
        {
            get => default;
            set
            {
            }
        }

        public bool areaExist(AreaBL Area)
        {
            foreach(AreaBL i in area)
            {
                if(i.Marla == Area.Marla) return true;
            }
            return false;
        }
    }
}
