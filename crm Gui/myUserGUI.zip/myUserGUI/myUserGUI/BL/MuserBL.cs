﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    public class MuserBL
    {
        public MuserBL(string email, string password)
        {
            this.email = email;
            this.password = password;
        }
        public MuserBL(string name , string email, string password , string category , string phoneNo , string cnic , string city)
        {
            this.email = email;
            this.password = password;
            this.name = name;
            this.category = category;
            this.phoneNo = phoneNo;
            this.city = city;
            this.cnic = cnic;
        }
        private string name;
        private string password;
        private string email;
        private string category;
        private string phoneNo;
        private string cnic;
        private string city;

        public string Name { get => name; set => name = value; }
        public string Password { get => password; set => password = value; }
        public string Email { get => email; set => email = value; }
        public string Category { get => category; set => category = value; }
        public string PhoneNo { get => phoneNo; set => phoneNo = value; }
        public string Cnic { get => cnic; set => cnic = value; }
        public string City { get => city; set => city = value; }

        internal DL.MuserDL MuserDL
        {
            get => default;
            set
            {
            }
        }

        internal DL.MuserDL MuserDL1
        {
            get => default;
            set
            {
            }
        }

        public bool isAdmin()
        {
            if (Category == "Admin") return true;
            else return false;
        }
    }
}
