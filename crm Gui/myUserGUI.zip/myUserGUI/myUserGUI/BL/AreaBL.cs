﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    public class AreaBL
    {
        public AreaBL(int marla, int plots)
        {
            this.marla = marla;
            this.plots = plots;
        }
        private int marla;
        private int plots;
        public int Marla { get => marla; set => marla = value; }
        public int Plots { get => plots; set => plots = value; }

        public ProjectBL ProjectBL
        {
            get => default;
            set
            {
            }
        }
    }
}
