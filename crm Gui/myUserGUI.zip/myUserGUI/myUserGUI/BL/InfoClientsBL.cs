﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    public class InfoClientsBL : LeadBL
    {
        public InfoClientsBL(string spoName, string name, string phone, string project, string source) : base(spoName, name, phone, project, source)
        {
            date = DateTime.UtcNow.Date;
            schedule = "FOLLOW UPS";
            response = "give info";
        }
        private DateTime date;
        private string schedule;
        private string response;
        public DateTime Date { get => date; set => date = value; }
        public string Schedule { get => schedule; set => schedule = value; }
        public string Response { get => response; set => response = value; }

        internal DL.InfoLeadDL InfoLeadDL
        {
            get => default;
            set
            {
            }
        }

        public override void SaleDone() => DealDone = true;
    }
}
