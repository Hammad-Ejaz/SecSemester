﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    class SaleClientsBL : LeadBL
    {
        public SaleClientsBL(string spoName, string name, string phone, string project, string source, string cnic, int area, int plotNo, int price, string blockNoOrAddress, string city) : base(spoName, name, phone, project, source)
        {
            this.Cnic = cnic;
            this.area = area;
            this.plotNo = plotNo;
            this.price = price;
            this.blockNoOrAddress = blockNoOrAddress;
            this.city = city;
        }
        private string cnic;
        private int area;
        private int plotNo;
        private int price;
        private string blockNoOrAddress;
        private string city;
        public int Area { get => area; set => area = value; }
        public int PlotNo { get => plotNo; set => plotNo = value; }
        public int Price { get => price; set => price = value; }
        public string BlockNoOrAddrees { get => blockNoOrAddress; set => blockNoOrAddress = value; }
        public string City { get => city; set => city = value; }
        public string Cnic { get => cnic; set => cnic = value; }

        internal DL.SaleDL SaleDL
        {
            get => default;
            set
            {
            }
        }

        public override void SaleDone() => DealDone = true;
    }
}
