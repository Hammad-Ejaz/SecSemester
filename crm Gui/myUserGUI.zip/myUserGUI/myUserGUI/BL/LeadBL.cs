﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myUserGUI.BL
{
    public abstract class LeadBL
    {
        public LeadBL(string spoName, string name, string phone, string project, string source)
        {
            this.spoName = spoName;
            this.name = name;
            this.phone = phone;
            this.project = project;
            this.source = source;
        }
        protected string spoName;
        protected string name;
        protected string phone;
        protected string project;
        protected string source;
        private bool dealDone;
        public string SpoName { get => spoName; set => spoName = value; }
        public string Name { get => name; set => name = value; }
        public string Phone { get => phone; set => phone = value; }
        public string Source { get => source; set => source = value; }
        public string Project { get => project; set => project = value; }
        public bool DealDone { get => dealDone; set => dealDone = value; }
        public abstract void SaleDone();
    }
}
