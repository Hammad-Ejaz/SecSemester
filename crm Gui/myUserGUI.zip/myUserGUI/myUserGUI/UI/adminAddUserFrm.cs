﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
using myUserGUI.UI;
namespace myUserGUI
{
    public partial class adminAddUserFrm : adminModel
    {
        public adminAddUserFrm()
        {
            InitializeComponent();
        }
        private void AddUserSave_cmd_Click(object sender, EventArgs e)
        {
            if (addUserName_txt.Text != null && addUserPhoneNo_txt.Text != null && addUserPwd_txt.Text != null && addUserEmail_txt.Text != null && addUserCity_txt.Text != null && addUserCnic_txt.Text != null && addUserCtgry_CmbTxt.Text != "")
            {
                if (addUserPhoneNo_txt.Text.Length == 11 && HelperDL.isValidEMAIL(addUserEmail_txt.Text) && addUserCnic_txt.Text.Length == 15)
                {
                    string name = addUserName_txt.Text;
                    string phoneNo = addUserPhoneNo_txt.Text;
                    string password = addUserPwd_txt.Text;
                    string email = addUserEmail_txt.Text;
                    string city = addUserCity_txt.Text;
                    string cnic = addUserCnic_txt.Text;
                    string category = addUserCtgry_CmbTxt.Text;
                    MuserBL user = new MuserBL(name, email, password, category, phoneNo, cnic, city);
                    MuserDL.adduseritoList(user);
                    MuserDL.saveUserData("Store.txt");
                    MessageBox.Show("User Added Successfuly");
                    addUserName_txt.Text = "";
                    addUserPhoneNo_txt.Text = "";
                    addUserPwd_txt.Text = "";
                    addUserEmail_txt.Text = "";
                    addUserCity_txt.Text = "";
                    addUserCnic_txt.Text = "";
                    addUserCtgry_CmbTxt.Text = "";

                }
                else MessageBox.Show("invalid Information");
            }
            else MessageBox.Show("invalid Information");
        }
    }
}
