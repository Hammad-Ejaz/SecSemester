﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class userResponseFrm : Form
    {
        private InfoClientsBL prvious;
        public userResponseFrm(InfoClientsBL lead)
        {
            InitializeComponent();
            prvious = lead;
        }
        private void Form15_Load(object sender, EventArgs e)
        {
            Name_lbl.Text = prvious.Name;
            project_lbl.Text = prvious.Project;
            source_lbl.Text = prvious.Source;
            phone_lbl.Text = prvious.Phone;
            spoName_lbl.Text = prvious.SpoName;
            response_txt.Text = prvious.Response;
        }

        private void Save_cmd_Click(object sender, EventArgs e)
        {
            InfoClientsBL update = new InfoClientsBL(spoName_lbl.Text, Name_lbl.Text, phone_lbl.Text, project_lbl.Text, source_lbl.Text);
            if (response_txt.Text != null && scheddule_cmb.Text != "")
            {
                update.Response = response_txt.Text;
                update.Schedule = scheddule_cmb.Text;
                update.Date = DateTime.Parse(editDate.Text);
                InfoLeadDL.editLead(prvious, update);
                InfoLeadDL.saveData("Lead.txt");
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid Data");
            }
        }
    }
}
