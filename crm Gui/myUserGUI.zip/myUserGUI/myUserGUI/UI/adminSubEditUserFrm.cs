﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminSubEditUserFrm : Form
    {
        private MuserBL previous;
        public adminSubEditUserFrm(MuserBL previous)
        {
            InitializeComponent();
            this.previous = previous;
        }
        private void AdminSubEditUserFrm_Load(object sender, EventArgs e)
        {
            editUserCity_txt.Text = previous.City;
            editUserName_txt.Text = previous.Name;
            editUserEmail_txt.Text = previous.Email;
            editUserPhoneNo_txt.Text = previous.PhoneNo;
            editUserCtgry_CmbTxt.Text = previous.Category;
            editUserPwd_txt.Text = previous.Password;
            editUserCnic_txt.Text = previous.Cnic;
        }
        private void AddUserSave_cmd_Click(object sender, EventArgs e)
        {
            if(editUserName_txt.Text != null && editUserEmail_txt.Text != null && editUserPwd_txt.Text != null && editUserCtgry_CmbTxt.Text != "" && editUserPhoneNo_txt.Text.Length == 11  &&  editUserCnic_txt.Text.Length == 15 && editUserCity_txt.Text != null)
            {
                MuserBL update = new MuserBL(editUserName_txt.Text, editUserEmail_txt.Text, editUserPwd_txt.Text, editUserCtgry_CmbTxt.Text, editUserPhoneNo_txt.Text, editUserCnic_txt.Text, editUserCity_txt.Text);
                MuserDL.editUser(previous, update);
                this.Close();
            }
            else MessageBox.Show("invalid data");
        }
    }
}
