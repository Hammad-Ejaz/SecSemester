﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI.UI
{
    public partial class userTotalLeadsFrm : Form
    {
        MuserBL currentUser;
        public userTotalLeadsFrm(MuserBL currentUser)
        {
            InitializeComponent();
            this.currentUser = currentUser;
        }
        private void UserTotalLeadsFrm_Load(object sender, EventArgs e)
        {
            userTotalLead_GV.DataSource = InfoLeadDL.getLeadofSpecificSPO(currentUser.Name);
            userTotalLead_GV.Columns["date"].Visible = false;
            userTotalLead_GV.Columns["response"].Visible = false;
            userTotalLead_GV.Columns["schedule"].Visible = false;
        }

        private void SaleHomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMainHomeFrm home = new UserMainHomeFrm(currentUser);
            home.Show();
        }

        private void SaleTodayLeadCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTodayLeadsFrm lead = new userTodayLeadsFrm(currentUser);
            lead.Show();
        }

        private void SaleProjectCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userProjectInfoFrm project = new userProjectInfoFrm(currentUser);
            project.Show();
        }

        private void SaleAddSaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userAddSaleFrm sale = new userAddSaleFrm(currentUser);
            sale.Show();
        }

        private void SaleViewAllCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userViewTotalSale allSale = new userViewTotalSale(currentUser);
            allSale.Show();
        }

        private void SaleLogoutCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
            login.Show();
        }
    }
}
