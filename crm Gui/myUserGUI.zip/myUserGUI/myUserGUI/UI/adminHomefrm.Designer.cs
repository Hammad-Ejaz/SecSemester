﻿namespace myUserGUI.UI
{
    partial class adminHomefrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel8 = new System.Windows.Forms.TableLayoutPanel();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel7 = new System.Windows.Forms.TableLayoutPanel();
            this.adminDoneHot_lbl = new System.Windows.Forms.Label();
            this.adminDoneMeeting_lbl = new System.Windows.Forms.Label();
            this.adminDoneVisit_lbl = new System.Windows.Forms.Label();
            this.adminDoneFollow_lbl = new System.Windows.Forms.Label();
            this.adminDoneLead_lbl = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.adminHomeHot_lbl = new System.Windows.Forms.Label();
            this.adminHomeMeeting_lbl = new System.Windows.Forms.Label();
            this.adminHomeVisit_lbl = new System.Windows.Forms.Label();
            this.adminHomeFollowUp_lbl = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.adminHomeTotalLead_lbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel8.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel7.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel8, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(198, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(895, 660);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel8
            // 
            this.tableLayoutPanel8.ColumnCount = 1;
            this.tableLayoutPanel8.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel8.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel8.Controls.Add(this.tableLayoutPanel9, 0, 1);
            this.tableLayoutPanel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel8.Location = new System.Drawing.Point(450, 3);
            this.tableLayoutPanel8.Name = "tableLayoutPanel8";
            this.tableLayoutPanel8.RowCount = 2;
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 9.190031F));
            this.tableLayoutPanel8.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 90.80997F));
            this.tableLayoutPanel8.Size = new System.Drawing.Size(442, 654);
            this.tableLayoutPanel8.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(436, 60);
            this.label3.TabIndex = 0;
            this.label3.Text = "NOTES";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel9.Controls.Add(this.button1, 0, 1);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 63);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 2;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.52941F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.47059F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(436, 588);
            this.tableLayoutPanel9.TabIndex = 1;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(430, 426);
            this.textBox1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(327, 435);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 41);
            this.button1.TabIndex = 1;
            this.button1.Text = "SAVE";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel7, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.tableLayoutPanel6, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 2;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.90698F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.09302F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(441, 654);
            this.tableLayoutPanel5.TabIndex = 1;
            // 
            // tableLayoutPanel7
            // 
            this.tableLayoutPanel7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel7.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel7.ColumnCount = 3;
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 368F));
            this.tableLayoutPanel7.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel7.Controls.Add(this.adminDoneHot_lbl, 1, 6);
            this.tableLayoutPanel7.Controls.Add(this.adminDoneMeeting_lbl, 1, 5);
            this.tableLayoutPanel7.Controls.Add(this.adminDoneVisit_lbl, 1, 4);
            this.tableLayoutPanel7.Controls.Add(this.adminDoneFollow_lbl, 1, 3);
            this.tableLayoutPanel7.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel7.Controls.Add(this.adminDoneLead_lbl, 1, 2);
            this.tableLayoutPanel7.Location = new System.Drawing.Point(3, 316);
            this.tableLayoutPanel7.Name = "tableLayoutPanel7";
            this.tableLayoutPanel7.RowCount = 8;
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 35.71429F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 64.28571F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel7.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel7.Size = new System.Drawing.Size(435, 335);
            this.tableLayoutPanel7.TabIndex = 1;
            // 
            // adminDoneHot_lbl
            // 
            this.adminDoneHot_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminDoneHot_lbl.AutoSize = true;
            this.adminDoneHot_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminDoneHot_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDoneHot_lbl.Location = new System.Drawing.Point(42, 267);
            this.adminDoneHot_lbl.Name = "adminDoneHot_lbl";
            this.adminDoneHot_lbl.Size = new System.Drawing.Size(362, 40);
            this.adminDoneHot_lbl.TabIndex = 19;
            this.adminDoneHot_lbl.Text = "HOT CLIENTS";
            this.adminDoneHot_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminDoneMeeting_lbl
            // 
            this.adminDoneMeeting_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminDoneMeeting_lbl.AutoSize = true;
            this.adminDoneMeeting_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminDoneMeeting_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDoneMeeting_lbl.Location = new System.Drawing.Point(42, 225);
            this.adminDoneMeeting_lbl.Name = "adminDoneMeeting_lbl";
            this.adminDoneMeeting_lbl.Size = new System.Drawing.Size(362, 42);
            this.adminDoneMeeting_lbl.TabIndex = 16;
            this.adminDoneMeeting_lbl.Text = "MEETINGS";
            this.adminDoneMeeting_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminDoneVisit_lbl
            // 
            this.adminDoneVisit_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminDoneVisit_lbl.AutoSize = true;
            this.adminDoneVisit_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminDoneVisit_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDoneVisit_lbl.Location = new System.Drawing.Point(42, 183);
            this.adminDoneVisit_lbl.Name = "adminDoneVisit_lbl";
            this.adminDoneVisit_lbl.Size = new System.Drawing.Size(362, 42);
            this.adminDoneVisit_lbl.TabIndex = 13;
            this.adminDoneVisit_lbl.Text = "VISITS";
            this.adminDoneVisit_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminDoneFollow_lbl
            // 
            this.adminDoneFollow_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminDoneFollow_lbl.AutoSize = true;
            this.adminDoneFollow_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminDoneFollow_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDoneFollow_lbl.Location = new System.Drawing.Point(42, 138);
            this.adminDoneFollow_lbl.Name = "adminDoneFollow_lbl";
            this.adminDoneFollow_lbl.Size = new System.Drawing.Size(362, 45);
            this.adminDoneFollow_lbl.TabIndex = 10;
            this.adminDoneFollow_lbl.Text = "FOLLOW UPS";
            this.adminDoneFollow_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminDoneLead_lbl
            // 
            this.adminDoneLead_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminDoneLead_lbl.AutoSize = true;
            this.adminDoneLead_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminDoneLead_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminDoneLead_lbl.Location = new System.Drawing.Point(42, 90);
            this.adminDoneLead_lbl.Name = "adminDoneLead_lbl";
            this.adminDoneLead_lbl.Size = new System.Drawing.Size(362, 48);
            this.adminDoneLead_lbl.TabIndex = 7;
            this.adminDoneLead_lbl.Text = "LEADS";
            this.adminDoneLead_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(42, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(362, 58);
            this.label2.TabIndex = 0;
            this.label2.Text = "DONE";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel6.ColumnCount = 3;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 368F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 28F));
            this.tableLayoutPanel6.Controls.Add(this.adminHomeHot_lbl, 1, 6);
            this.tableLayoutPanel6.Controls.Add(this.adminHomeMeeting_lbl, 1, 5);
            this.tableLayoutPanel6.Controls.Add(this.adminHomeVisit_lbl, 1, 4);
            this.tableLayoutPanel6.Controls.Add(this.adminHomeFollowUp_lbl, 1, 3);
            this.tableLayoutPanel6.Controls.Add(this.label9, 2, 2);
            this.tableLayoutPanel6.Controls.Add(this.adminHomeTotalLead_lbl, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.label1, 1, 1);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 8;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.80597F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.19403F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(435, 307);
            this.tableLayoutPanel6.TabIndex = 0;
            // 
            // adminHomeHot_lbl
            // 
            this.adminHomeHot_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminHomeHot_lbl.AutoSize = true;
            this.adminHomeHot_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminHomeHot_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminHomeHot_lbl.Location = new System.Drawing.Point(42, 239);
            this.adminHomeHot_lbl.Name = "adminHomeHot_lbl";
            this.adminHomeHot_lbl.Size = new System.Drawing.Size(362, 40);
            this.adminHomeHot_lbl.TabIndex = 19;
            this.adminHomeHot_lbl.Text = "TOTAL HOT CLIENTS";
            this.adminHomeHot_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminHomeMeeting_lbl
            // 
            this.adminHomeMeeting_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminHomeMeeting_lbl.AutoSize = true;
            this.adminHomeMeeting_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminHomeMeeting_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminHomeMeeting_lbl.Location = new System.Drawing.Point(42, 197);
            this.adminHomeMeeting_lbl.Name = "adminHomeMeeting_lbl";
            this.adminHomeMeeting_lbl.Size = new System.Drawing.Size(362, 42);
            this.adminHomeMeeting_lbl.TabIndex = 16;
            this.adminHomeMeeting_lbl.Text = "TOTAL MEETINGS";
            this.adminHomeMeeting_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminHomeVisit_lbl
            // 
            this.adminHomeVisit_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminHomeVisit_lbl.AutoSize = true;
            this.adminHomeVisit_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminHomeVisit_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminHomeVisit_lbl.Location = new System.Drawing.Point(42, 155);
            this.adminHomeVisit_lbl.Name = "adminHomeVisit_lbl";
            this.adminHomeVisit_lbl.Size = new System.Drawing.Size(362, 42);
            this.adminHomeVisit_lbl.TabIndex = 13;
            this.adminHomeVisit_lbl.Text = "TOTAL VISITS";
            this.adminHomeVisit_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminHomeFollowUp_lbl
            // 
            this.adminHomeFollowUp_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminHomeFollowUp_lbl.AutoSize = true;
            this.adminHomeFollowUp_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminHomeFollowUp_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminHomeFollowUp_lbl.Location = new System.Drawing.Point(42, 117);
            this.adminHomeFollowUp_lbl.Name = "adminHomeFollowUp_lbl";
            this.adminHomeFollowUp_lbl.Size = new System.Drawing.Size(362, 38);
            this.adminHomeFollowUp_lbl.TabIndex = 10;
            this.adminHomeFollowUp_lbl.Text = "TOTAL FOLLOW UPS";
            this.adminHomeFollowUp_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label9.Location = new System.Drawing.Point(410, 76);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(22, 41);
            this.label9.TabIndex = 8;
            // 
            // adminHomeTotalLead_lbl
            // 
            this.adminHomeTotalLead_lbl.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.adminHomeTotalLead_lbl.AutoSize = true;
            this.adminHomeTotalLead_lbl.BackColor = System.Drawing.SystemColors.Control;
            this.adminHomeTotalLead_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adminHomeTotalLead_lbl.Location = new System.Drawing.Point(42, 76);
            this.adminHomeTotalLead_lbl.Name = "adminHomeTotalLead_lbl";
            this.adminHomeTotalLead_lbl.Size = new System.Drawing.Size(362, 41);
            this.adminHomeTotalLead_lbl.TabIndex = 7;
            this.adminHomeTotalLead_lbl.Text = "TOTAL LEADS";
            this.adminHomeTotalLead_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(42, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(362, 47);
            this.label1.TabIndex = 0;
            this.label1.Text = "TO DO";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminHomefrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "adminHomefrm";
            this.Text = "Form10";
            this.Load += new System.EventHandler(this.AdminHomefrm_Load);
            this.Controls.SetChildIndex(this.tableLayoutPanel2, 0);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel8.ResumeLayout(false);
            this.tableLayoutPanel8.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.tableLayoutPanel9.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel7.ResumeLayout(false);
            this.tableLayoutPanel7.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel7;
        private System.Windows.Forms.Label adminDoneHot_lbl;
        private System.Windows.Forms.Label adminDoneMeeting_lbl;
        private System.Windows.Forms.Label adminDoneVisit_lbl;
        private System.Windows.Forms.Label adminDoneFollow_lbl;
        private System.Windows.Forms.Label adminDoneLead_lbl;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label adminHomeHot_lbl;
        private System.Windows.Forms.Label adminHomeMeeting_lbl;
        private System.Windows.Forms.Label adminHomeVisit_lbl;
        private System.Windows.Forms.Label adminHomeFollowUp_lbl;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label adminHomeTotalLead_lbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
    }
}