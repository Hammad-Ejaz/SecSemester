﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminEditLeadFrm : adminModel
    {
        public adminEditLeadFrm()
        {
            InitializeComponent();
        }
        private void AdminEditLeadFrm_Load(object sender, EventArgs e)
        {

            adminEditLead_GV.DataSource = InfoLeadDL.InfoClientsList;
            adminEditLead_GV.Columns["date"].Visible = false;
            adminEditLead_GV.Columns["response"].Visible = false;
            adminEditLead_GV.Columns["schedule"].Visible = false;
        }
        private void DataBind()
        {
            adminEditLead_GV.DataSource = null;
            adminEditLead_GV.DataSource = InfoLeadDL.InfoClientsList;
            adminEditLead_GV.Columns["date"].Visible = false;
            adminEditLead_GV.Columns["response"].Visible = false;
            adminEditLead_GV.Columns["schedule"].Visible = false;
            adminEditLead_GV.Refresh();
        }

        private void AdminEditLead_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            InfoClientsBL lead = (InfoClientsBL)adminEditLead_GV.CurrentRow.DataBoundItem;
            if (adminEditLead_GV.Columns["EDIT"].Index == e.ColumnIndex)
            {
                adminSubEditLeadFrm edit = new adminSubEditLeadFrm(lead);
                edit.ShowDialog();
                InfoLeadDL.saveData("Lead.txt");
                DataBind();
            }
            else if (adminEditLead_GV.Columns[1].Index == e.ColumnIndex)
            {
                InfoLeadDL.delLead(lead);
                InfoLeadDL.saveData("Lead.txt");
                DataBind();
            }
        }
    }
}
