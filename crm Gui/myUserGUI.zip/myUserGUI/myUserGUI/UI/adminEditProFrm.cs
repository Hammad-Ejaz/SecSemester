﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminEditProFrm : Form
    {
        List<ProjectBL> pro = new List<ProjectBL>();
        public adminEditProFrm()
        {
            InitializeComponent();
        }
        private void AdminEditProFrm_Load_1(object sender, EventArgs e)
        {
            admineditPro_GV.DataSource = ProjectDL.AllProjects;
        }
        private void HomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminHomefrm home = new adminHomefrm();
            home.Show();
        }

        private void ADDLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAddLeadFrm addLead = new adminAddLeadFrm();
            addLead.Show();
        }

        private void DELETELEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminEditLeadFrm editLead = new adminEditLeadFrm();
            editLead.Show();
        }

        private void VIEWTOTALLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminTotalLeadFrm totalLead = new adminTotalLeadFrm();
            totalLead.Show();
        }

        private void ADDPROJECTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAddProjectFrm project = new adminAddProjectFrm();
            project.Show();
        }

        private void VIEWALLPROJECTSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminViewAllPro allProject = new adminViewAllPro();
            allProject.Show();
        }
        private void SaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminSaleFrm sale = new adminSaleFrm();
            sale.Show();
        }
        private void ADDUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAddUserFrm addUser = new adminAddUserFrm();
            addUser.Show();
        }
        private void VIEWALLUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAllUserFrm allUser = new adminAllUserFrm();
            allUser.Show();
        }

        private void DELETEUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminDeleteUserFrm delUser = new adminDeleteUserFrm();
            delUser.Show();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
            login.Show();
        }
        private void DataBind()
        {
            admineditPro_GV.DataSource = null;
            admineditPro_GV.DataSource = ProjectDL.AllProjects;
            admineditPro_GV.Refresh();
        }
        private void AdmineditPro_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProjectBL project = (ProjectBL)admineditPro_GV.CurrentRow.DataBoundItem;
            if (admineditPro_GV.Columns["EDIT"].Index == e.ColumnIndex)
            {
                adminSubEditProjectFrm edit = new adminSubEditProjectFrm(project);
                edit.ShowDialog();
                ProjectDL.storeData("Project.txt");
                DataBind();
           }
           else if (admineditPro_GV.Columns[1].Index == e.ColumnIndex)
           {
               ProjectDL.deleteProject(project.Name ,project.City);
               ProjectDL.storeData("Project.txt");
               DataBind();
           }
        }
    }
}
