﻿namespace myUserGUI
{
    partial class adminAddUserFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.addUserPwd_txt = new System.Windows.Forms.TextBox();
            this.addUserName_txt = new System.Windows.Forms.TextBox();
            this.addUserEmail_txt = new System.Windows.Forms.TextBox();
            this.addUserSave_cmd = new System.Windows.Forms.Button();
            this.addUserCtgry_CmbTxt = new System.Windows.Forms.ComboBox();
            this.addUserCnic_txt = new System.Windows.Forms.MaskedTextBox();
            this.addUserPhoneNo_txt = new System.Windows.Forms.MaskedTextBox();
            this.addUserCity_txt = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 28.17372F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 71.82628F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(195, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(898, 660);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.addUserPwd_txt, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.addUserName_txt, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.addUserEmail_txt, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.addUserSave_cmd, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.addUserCtgry_CmbTxt, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.addUserCnic_txt, 0, 6);
            this.tableLayoutPanel5.Controls.Add(this.addUserPhoneNo_txt, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.addUserCity_txt, 0, 5);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(256, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 10;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.09375F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.90625F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 230F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(639, 654);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // addUserPwd_txt
            // 
            this.addUserPwd_txt.Dock = System.Windows.Forms.DockStyle.Left;
            this.addUserPwd_txt.Location = new System.Drawing.Point(3, 176);
            this.addUserPwd_txt.Multiline = true;
            this.addUserPwd_txt.Name = "addUserPwd_txt";
            this.addUserPwd_txt.Size = new System.Drawing.Size(201, 33);
            this.addUserPwd_txt.TabIndex = 3;
            // 
            // addUserName_txt
            // 
            this.addUserName_txt.Dock = System.Windows.Forms.DockStyle.Left;
            this.addUserName_txt.Location = new System.Drawing.Point(3, 98);
            this.addUserName_txt.Multiline = true;
            this.addUserName_txt.Name = "addUserName_txt";
            this.addUserName_txt.Size = new System.Drawing.Size(201, 33);
            this.addUserName_txt.TabIndex = 0;
            // 
            // addUserEmail_txt
            // 
            this.addUserEmail_txt.Dock = System.Windows.Forms.DockStyle.Left;
            this.addUserEmail_txt.Location = new System.Drawing.Point(3, 137);
            this.addUserEmail_txt.Multiline = true;
            this.addUserEmail_txt.Name = "addUserEmail_txt";
            this.addUserEmail_txt.Size = new System.Drawing.Size(201, 33);
            this.addUserEmail_txt.TabIndex = 2;
            // 
            // addUserSave_cmd
            // 
            this.addUserSave_cmd.Dock = System.Windows.Forms.DockStyle.Left;
            this.addUserSave_cmd.Location = new System.Drawing.Point(3, 392);
            this.addUserSave_cmd.Name = "addUserSave_cmd";
            this.addUserSave_cmd.Size = new System.Drawing.Size(201, 28);
            this.addUserSave_cmd.TabIndex = 8;
            this.addUserSave_cmd.Text = "SAVE";
            this.addUserSave_cmd.UseVisualStyleBackColor = true;
            this.addUserSave_cmd.Click += new System.EventHandler(this.AddUserSave_cmd_Click);
            // 
            // addUserCtgry_CmbTxt
            // 
            this.addUserCtgry_CmbTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addUserCtgry_CmbTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserCtgry_CmbTxt.FormattingEnabled = true;
            this.addUserCtgry_CmbTxt.Items.AddRange(new object[] {
            "Admin",
            "SPO"});
            this.addUserCtgry_CmbTxt.Location = new System.Drawing.Point(3, 353);
            this.addUserCtgry_CmbTxt.Name = "addUserCtgry_CmbTxt";
            this.addUserCtgry_CmbTxt.Size = new System.Drawing.Size(201, 33);
            this.addUserCtgry_CmbTxt.TabIndex = 6;
            // 
            // addUserCnic_txt
            // 
            this.addUserCnic_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addUserCnic_txt.Location = new System.Drawing.Point(3, 317);
            this.addUserCnic_txt.Mask = "00000-0000000-0";
            this.addUserCnic_txt.MinimumSize = new System.Drawing.Size(182, 31);
            this.addUserCnic_txt.Name = "addUserCnic_txt";
            this.addUserCnic_txt.Size = new System.Drawing.Size(201, 31);
            this.addUserCnic_txt.TabIndex = 11;
            // 
            // addUserPhoneNo_txt
            // 
            this.addUserPhoneNo_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addUserPhoneNo_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUserPhoneNo_txt.Location = new System.Drawing.Point(3, 216);
            this.addUserPhoneNo_txt.Mask = "00000000000";
            this.addUserPhoneNo_txt.MinimumSize = new System.Drawing.Size(182, 31);
            this.addUserPhoneNo_txt.Name = "addUserPhoneNo_txt";
            this.addUserPhoneNo_txt.Size = new System.Drawing.Size(201, 31);
            this.addUserPhoneNo_txt.TabIndex = 10;
            // 
            // addUserCity_txt
            // 
            this.addUserCity_txt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.addUserCity_txt.Location = new System.Drawing.Point(3, 260);
            this.addUserCity_txt.Multiline = true;
            this.addUserCity_txt.Name = "addUserCity_txt";
            this.addUserCity_txt.Size = new System.Drawing.Size(201, 31);
            this.addUserCity_txt.TabIndex = 5;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 138F));
            this.tableLayoutPanel3.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.label3, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel3.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.label7, 1, 7);
            this.tableLayoutPanel3.Controls.Add(this.label6, 1, 6);
            this.tableLayoutPanel3.Controls.Add(this.label5, 1, 5);
            this.tableLayoutPanel3.Controls.Add(this.label8, 1, 4);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 9;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 41F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 46F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 52F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 264F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(247, 654);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(113, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(112, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(132, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "EMAIL";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(112, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(132, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "PASSWORD";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(112, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD USER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(112, 354);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(132, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "CATAGORY";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(112, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 36);
            this.label6.TabIndex = 7;
            this.label6.Text = "CNIC";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(112, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 34);
            this.label5.TabIndex = 4;
            this.label5.Text = "CITY";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(112, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(132, 35);
            this.label8.TabIndex = 8;
            this.label8.Text = "PHONE NO";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminAddUserFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "adminAddUserFrm";
            this.Text = "SignUpFrm";
            this.Controls.SetChildIndex(this.tableLayoutPanel2, 0);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TextBox addUserPwd_txt;
        private System.Windows.Forms.TextBox addUserName_txt;
        private System.Windows.Forms.TextBox addUserEmail_txt;
        private System.Windows.Forms.Button addUserSave_cmd;
        private System.Windows.Forms.ComboBox addUserCtgry_CmbTxt;
        private System.Windows.Forms.TextBox addUserCity_txt;
        private System.Windows.Forms.MaskedTextBox addUserPhoneNo_txt;
        private System.Windows.Forms.MaskedTextBox addUserCnic_txt;
    }
}