﻿namespace myUserGUI.UI
{
    partial class adminModel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminModel));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btn = new System.Windows.Forms.ToolStrip();
            this.adminMhomeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.leadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.adminMAddLead_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMEditLead_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMVIewTotalLead_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.adminMaddProject_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMviewAllPro_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMdeletePro_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.adminMSaleCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.userCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.adminMAddUser_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMViewAllUser_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.adminMEditUser_cmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.adminMLogout_cmd = new System.Windows.Forms.ToolStripButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btn, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(-3, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 28.16265F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 71.83735F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(198, 664);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btn
            // 
            this.btn.AutoSize = false;
            this.btn.BackColor = System.Drawing.Color.Silver;
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminMhomeCmd,
            this.toolStripSeparator1,
            this.leadCmd,
            this.toolStripSeparator2,
            this.toolStripDropDownButton2,
            this.toolStripSeparator3,
            this.adminMSaleCmd,
            this.toolStripSeparator4,
            this.userCmd,
            this.toolStripSeparator5,
            this.adminMLogout_cmd});
            this.btn.Location = new System.Drawing.Point(0, 186);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(195, 478);
            this.btn.Stretch = true;
            this.btn.TabIndex = 14;
            this.btn.Text = "SideBar";
            // 
            // adminMhomeCmd
            // 
            this.adminMhomeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.adminMhomeCmd.ForeColor = System.Drawing.SystemColors.InfoText;
            this.adminMhomeCmd.Image = ((System.Drawing.Image)(resources.GetObject("adminMhomeCmd.Image")));
            this.adminMhomeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.adminMhomeCmd.Name = "adminMhomeCmd";
            this.adminMhomeCmd.Size = new System.Drawing.Size(193, 23);
            this.adminMhomeCmd.Text = "HOME      ";
            this.adminMhomeCmd.Click += new System.EventHandler(this.AdminMhomeCmd_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(193, 6);
            // 
            // leadCmd
            // 
            this.leadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminMAddLead_cmd,
            this.adminMEditLead_cmd,
            this.adminMVIewTotalLead_cmd});
            this.leadCmd.Image = ((System.Drawing.Image)(resources.GetObject("leadCmd.Image")));
            this.leadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leadCmd.Name = "leadCmd";
            this.leadCmd.Size = new System.Drawing.Size(193, 23);
            this.leadCmd.Text = "LEADS     ";
            // 
            // adminMAddLead_cmd
            // 
            this.adminMAddLead_cmd.Name = "adminMAddLead_cmd";
            this.adminMAddLead_cmd.Size = new System.Drawing.Size(206, 24);
            this.adminMAddLead_cmd.Text = "ADD LEADS";
            this.adminMAddLead_cmd.Click += new System.EventHandler(this.AdminMAddLead_cmd_Click_1);
            // 
            // adminMEditLead_cmd
            // 
            this.adminMEditLead_cmd.Name = "adminMEditLead_cmd";
            this.adminMEditLead_cmd.Size = new System.Drawing.Size(206, 24);
            this.adminMEditLead_cmd.Text = "EDIT LEADS";
            this.adminMEditLead_cmd.Click += new System.EventHandler(this.AdminMEditLead_cmd_Click);
            // 
            // adminMVIewTotalLead_cmd
            // 
            this.adminMVIewTotalLead_cmd.Name = "adminMVIewTotalLead_cmd";
            this.adminMVIewTotalLead_cmd.Size = new System.Drawing.Size(206, 24);
            this.adminMVIewTotalLead_cmd.Text = "VIEW TOTAL LEADS";
            this.adminMVIewTotalLead_cmd.Click += new System.EventHandler(this.AdminMVIewTotalLead_cmd_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(193, 6);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminMaddProject_cmd,
            this.adminMviewAllPro_cmd,
            this.adminMdeletePro_cmd});
            this.toolStripDropDownButton2.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(193, 23);
            this.toolStripDropDownButton2.Text = "PROJECT";
            this.toolStripDropDownButton2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // adminMaddProject_cmd
            // 
            this.adminMaddProject_cmd.Name = "adminMaddProject_cmd";
            this.adminMaddProject_cmd.Size = new System.Drawing.Size(211, 24);
            this.adminMaddProject_cmd.Text = "ADD PROJECT";
            this.adminMaddProject_cmd.Click += new System.EventHandler(this.AdminMaddProject_cmd_Click);
            // 
            // adminMviewAllPro_cmd
            // 
            this.adminMviewAllPro_cmd.Name = "adminMviewAllPro_cmd";
            this.adminMviewAllPro_cmd.Size = new System.Drawing.Size(211, 24);
            this.adminMviewAllPro_cmd.Text = "VIEW ALL PROJECTS";
            this.adminMviewAllPro_cmd.Click += new System.EventHandler(this.AdminMviewAllPro_cmd_Click);
            // 
            // adminMdeletePro_cmd
            // 
            this.adminMdeletePro_cmd.Name = "adminMdeletePro_cmd";
            this.adminMdeletePro_cmd.Size = new System.Drawing.Size(211, 24);
            this.adminMdeletePro_cmd.Text = "EDIT PROJECT";
            this.adminMdeletePro_cmd.Click += new System.EventHandler(this.AdminMdeletePro_cmd_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(193, 6);
            // 
            // adminMSaleCmd
            // 
            this.adminMSaleCmd.Image = ((System.Drawing.Image)(resources.GetObject("adminMSaleCmd.Image")));
            this.adminMSaleCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.adminMSaleCmd.Name = "adminMSaleCmd";
            this.adminMSaleCmd.Size = new System.Drawing.Size(193, 23);
            this.adminMSaleCmd.Text = "SALES        ";
            this.adminMSaleCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.adminMSaleCmd.Click += new System.EventHandler(this.AdminMSaleCmd_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(193, 6);
            // 
            // userCmd
            // 
            this.userCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.adminMAddUser_cmd,
            this.adminMViewAllUser_cmd,
            this.adminMEditUser_cmd});
            this.userCmd.Image = ((System.Drawing.Image)(resources.GetObject("userCmd.Image")));
            this.userCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.userCmd.Name = "userCmd";
            this.userCmd.Size = new System.Drawing.Size(193, 23);
            this.userCmd.Text = "USERS     ";
            // 
            // adminMAddUser_cmd
            // 
            this.adminMAddUser_cmd.Name = "adminMAddUser_cmd";
            this.adminMAddUser_cmd.Size = new System.Drawing.Size(178, 24);
            this.adminMAddUser_cmd.Text = "ADD USER";
            this.adminMAddUser_cmd.Click += new System.EventHandler(this.AdminMAddUser_cmd_Click);
            // 
            // adminMViewAllUser_cmd
            // 
            this.adminMViewAllUser_cmd.Name = "adminMViewAllUser_cmd";
            this.adminMViewAllUser_cmd.Size = new System.Drawing.Size(178, 24);
            this.adminMViewAllUser_cmd.Text = "VIEW ALL USER";
            this.adminMViewAllUser_cmd.Click += new System.EventHandler(this.AdminMViewAllUser_cmd_Click);
            // 
            // adminMEditUser_cmd
            // 
            this.adminMEditUser_cmd.Name = "adminMEditUser_cmd";
            this.adminMEditUser_cmd.Size = new System.Drawing.Size(178, 24);
            this.adminMEditUser_cmd.Text = "EDIT USER";
            this.adminMEditUser_cmd.Click += new System.EventHandler(this.AdminMEditUser_cmd_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(193, 6);
            // 
            // adminMLogout_cmd
            // 
            this.adminMLogout_cmd.Image = ((System.Drawing.Image)(resources.GetObject("adminMLogout_cmd.Image")));
            this.adminMLogout_cmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.adminMLogout_cmd.Name = "adminMLogout_cmd";
            this.adminMLogout_cmd.Size = new System.Drawing.Size(193, 23);
            this.adminMLogout_cmd.Text = "LOG OUT";
            this.adminMLogout_cmd.Click += new System.EventHandler(this.AdminMLogout_cmd_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::myUserGUI.Properties.Resources.Screenshot__22_2;
            this.pictureBox2.Location = new System.Drawing.Point(3, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(192, 178);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // adminModel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MinimumSize = new System.Drawing.Size(1109, 699);
            this.Name = "adminModel";
            this.Text = "adminModel";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.btn.ResumeLayout(false);
            this.btn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ToolStrip btn;
        private System.Windows.Forms.ToolStripButton adminMhomeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton leadCmd;
        private System.Windows.Forms.ToolStripMenuItem adminMAddLead_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMEditLead_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMVIewTotalLead_cmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem adminMaddProject_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMviewAllPro_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMdeletePro_cmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton adminMSaleCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton userCmd;
        private System.Windows.Forms.ToolStripMenuItem adminMAddUser_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMViewAllUser_cmd;
        private System.Windows.Forms.ToolStripMenuItem adminMEditUser_cmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton adminMLogout_cmd;
    }
}