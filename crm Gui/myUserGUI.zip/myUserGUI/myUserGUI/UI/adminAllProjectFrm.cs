﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI.UI
{
    public partial class adminViewAllPro : adminModel
    {
        public adminViewAllPro()
        {
            InitializeComponent();
        }
        private void AdminViewAllPro_Load(object sender, EventArgs e)
        {
            viewAllProPI_GV.DataSource = ProjectDL.AllProjects;
        }
        private void ViewAllProPI_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProjectBL project = (ProjectBL)viewAllProPI_GV.CurrentRow.DataBoundItem;
            if (viewAllProPI_GV.Columns[0].Index == e.ColumnIndex)
            {
                viewAllProAI_GV.DataSource = project.Area;
            }
        }
    }
}
