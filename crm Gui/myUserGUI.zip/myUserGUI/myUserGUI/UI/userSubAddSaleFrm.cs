﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class userSubAddSaleFrm : Form
    {
        private InfoClientsBL lead;
        public userSubAddSaleFrm(InfoClientsBL lead)
        {
            InitializeComponent();
            this.lead = lead;
        }
        private void UserSubAddSaleFrm_Load(object sender, EventArgs e)
        {
            name_lbl.Text = lead.Name;
            phone_lbl.Text = lead.Phone;
            spoName_lbl.Text = lead.SpoName;
            project_lbl.Text = lead.Project;
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                string spoName = lead.SpoName;
                string name = lead.Name;
                string phone = lead.Phone;
                string project = lead.Project;
                string source = lead.Source;
                string cnic = cnic_txt.Text;
                int area = int.Parse(area_txt.Text);
                int plotNo = int.Parse(plotNo_txt.Text);
                int price = int.Parse(price_txt.Text);
                string adress = blockNo_txt.Text;
                string city = city_txt.Text;
                if (phone.Length != 11 || cnic.Length != 15)
                {
                    throw new Exception("Invalid Data");
                }
                SaleClientsBL sale = new SaleClientsBL(spoName, name, phone, project, source, cnic, area, plotNo, price, adress, city);
                SaleDL.addSalesToList(sale);
                InfoLeadDL.delLead(lead);
                InfoLeadDL.saveData("Lead.txt");
                SaleDL.storeData("Sale.txt");
                this.Close();
            }
            catch 
            {
                MessageBox.Show("Invalid Data");
            }
        }
    }
}
