﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myUserGUI.UI
{
    public partial class adminModel : Form
    {
        public adminModel()
        {
            InitializeComponent();
        }
        private void AdminMAddLead_cmd_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            adminAddLeadFrm addLead = new adminAddLeadFrm();
            addLead.Show();

        }
        private void AdminMhomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminHomefrm home = new adminHomefrm();
            home.Show();
        }

        private void AdminMaddProject_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAddProjectFrm project = new adminAddProjectFrm();
            project.Show();
        }

        private void AdminMEditLead_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminEditLeadFrm editLead = new adminEditLeadFrm();
            editLead.Show();
        }

        private void AdminMVIewTotalLead_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminTotalLeadFrm totalLead = new adminTotalLeadFrm();
            totalLead.Show();
        }

        private void AdminMSaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminSaleFrm sale = new adminSaleFrm();
            sale.Show();
        }

        private void AdminMviewAllPro_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminViewAllPro allProject = new adminViewAllPro();
            allProject.Show();
        }

        private void AdminMdeletePro_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminEditProFrm editProject = new adminEditProFrm();
            editProject.Show();
        }

        private void AdminMAddUser_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAddUserFrm addUser = new adminAddUserFrm();
            addUser.Show();
        }

        private void AdminMViewAllUser_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminAllUserFrm allUser = new adminAllUserFrm();
            allUser.Show();
        }

        private void AdminMEditUser_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminDeleteUserFrm editUser = new adminDeleteUserFrm();
            editUser.Show();
        }

        private void AdminMLogout_cmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
            login.Show();
        }

    }
}
