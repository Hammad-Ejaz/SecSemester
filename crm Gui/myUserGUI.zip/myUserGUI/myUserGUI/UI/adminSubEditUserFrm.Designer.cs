﻿namespace myUserGUI.UI
{
    partial class adminSubEditUserFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.editUserPwd_txt = new System.Windows.Forms.TextBox();
            this.editUserName_txt = new System.Windows.Forms.TextBox();
            this.editUserEmail_txt = new System.Windows.Forms.TextBox();
            this.addUserSave_cmd = new System.Windows.Forms.Button();
            this.editUserCtgry_CmbTxt = new System.Windows.Forms.ComboBox();
            this.editUserCity_txt = new System.Windows.Forms.TextBox();
            this.editUserPhoneNo_txt = new System.Windows.Forms.MaskedTextBox();
            this.editUserCnic_txt = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 137F));
            this.tableLayoutPanel2.Controls.Add(this.label2, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.label3, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.label4, 1, 3);
            this.tableLayoutPanel2.Controls.Add(this.label7, 1, 7);
            this.tableLayoutPanel2.Controls.Add(this.label6, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.label5, 1, 5);
            this.tableLayoutPanel2.Controls.Add(this.label8, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.label1, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 9;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 53.125F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 46.875F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 44F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 251F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(258, 642);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(124, 84);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(131, 35);
            this.label2.TabIndex = 1;
            this.label2.Text = "NAME";
            this.label2.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(124, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "EMAIL";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(124, 167);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(131, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "PASSWORD";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(124, 355);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(131, 35);
            this.label7.TabIndex = 6;
            this.label7.Text = "CATEGORY";
            this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(124, 301);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(131, 36);
            this.label6.TabIndex = 7;
            this.label6.Text = "CNIC";
            this.label6.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(124, 258);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(131, 35);
            this.label5.TabIndex = 4;
            this.label5.Text = "CITY";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(124, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(131, 35);
            this.label8.TabIndex = 8;
            this.label8.Text = "PHONE NO";
            this.label8.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(124, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 37);
            this.label1.TabIndex = 0;
            this.label1.Text = "EDIT USER";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.26829F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.7317F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel5, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(902, 648);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 447F));
            this.tableLayoutPanel5.Controls.Add(this.editUserPwd_txt, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.editUserName_txt, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.editUserEmail_txt, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.addUserSave_cmd, 0, 8);
            this.tableLayoutPanel5.Controls.Add(this.editUserCtgry_CmbTxt, 0, 7);
            this.tableLayoutPanel5.Controls.Add(this.editUserCity_txt, 0, 5);
            this.tableLayoutPanel5.Controls.Add(this.editUserPhoneNo_txt, 0, 4);
            this.tableLayoutPanel5.Controls.Add(this.editUserCnic_txt, 0, 6);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(267, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 10;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 56.06061F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 43.93939F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 43F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 37F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 208F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(632, 642);
            this.tableLayoutPanel5.TabIndex = 4;
            // 
            // editUserPwd_txt
            // 
            this.editUserPwd_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserPwd_txt.Location = new System.Drawing.Point(3, 165);
            this.editUserPwd_txt.Multiline = true;
            this.editUserPwd_txt.Name = "editUserPwd_txt";
            this.editUserPwd_txt.Size = new System.Drawing.Size(179, 31);
            this.editUserPwd_txt.TabIndex = 3;
            // 
            // editUserName_txt
            // 
            this.editUserName_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserName_txt.Location = new System.Drawing.Point(3, 82);
            this.editUserName_txt.Multiline = true;
            this.editUserName_txt.Name = "editUserName_txt";
            this.editUserName_txt.Size = new System.Drawing.Size(179, 31);
            this.editUserName_txt.TabIndex = 0;
            // 
            // editUserEmail_txt
            // 
            this.editUserEmail_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserEmail_txt.Location = new System.Drawing.Point(3, 122);
            this.editUserEmail_txt.Multiline = true;
            this.editUserEmail_txt.Name = "editUserEmail_txt";
            this.editUserEmail_txt.Size = new System.Drawing.Size(179, 31);
            this.editUserEmail_txt.TabIndex = 2;
            // 
            // addUserSave_cmd
            // 
            this.addUserSave_cmd.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.addUserSave_cmd.Location = new System.Drawing.Point(31, 407);
            this.addUserSave_cmd.Name = "addUserSave_cmd";
            this.addUserSave_cmd.Size = new System.Drawing.Size(123, 23);
            this.addUserSave_cmd.TabIndex = 8;
            this.addUserSave_cmd.Text = "SAVE";
            this.addUserSave_cmd.UseVisualStyleBackColor = true;
            this.addUserSave_cmd.Click += new System.EventHandler(this.AddUserSave_cmd_Click);
            // 
            // editUserCtgry_CmbTxt
            // 
            this.editUserCtgry_CmbTxt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserCtgry_CmbTxt.FormattingEnabled = true;
            this.editUserCtgry_CmbTxt.Items.AddRange(new object[] {
            "Admin",
            "SPO"});
            this.editUserCtgry_CmbTxt.Location = new System.Drawing.Point(3, 361);
            this.editUserCtgry_CmbTxt.Name = "editUserCtgry_CmbTxt";
            this.editUserCtgry_CmbTxt.Size = new System.Drawing.Size(179, 21);
            this.editUserCtgry_CmbTxt.TabIndex = 6;
            // 
            // editUserCity_txt
            // 
            this.editUserCity_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserCity_txt.Location = new System.Drawing.Point(3, 254);
            this.editUserCity_txt.Multiline = true;
            this.editUserCity_txt.Name = "editUserCity_txt";
            this.editUserCity_txt.Size = new System.Drawing.Size(179, 32);
            this.editUserCity_txt.TabIndex = 5;
            // 
            // editUserPhoneNo_txt
            // 
            this.editUserPhoneNo_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserPhoneNo_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.editUserPhoneNo_txt.Location = new System.Drawing.Point(3, 210);
            this.editUserPhoneNo_txt.Mask = "00000000000";
            this.editUserPhoneNo_txt.MinimumSize = new System.Drawing.Size(182, 31);
            this.editUserPhoneNo_txt.Name = "editUserPhoneNo_txt";
            this.editUserPhoneNo_txt.Size = new System.Drawing.Size(182, 31);
            this.editUserPhoneNo_txt.TabIndex = 10;
            // 
            // editUserCnic_txt
            // 
            this.editUserCnic_txt.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.editUserCnic_txt.Location = new System.Drawing.Point(3, 311);
            this.editUserCnic_txt.Mask = "00000-0000000-0";
            this.editUserCnic_txt.MinimumSize = new System.Drawing.Size(182, 31);
            this.editUserCnic_txt.Name = "editUserCnic_txt";
            this.editUserCnic_txt.Size = new System.Drawing.Size(182, 31);
            this.editUserCnic_txt.TabIndex = 11;
            // 
            // adminSubEditUserFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(675, 607);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "adminSubEditUserFrm";
            this.Text = "adminSubEditUserFrm";
            this.Load += new System.EventHandler(this.AdminSubEditUserFrm_Load);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.TextBox editUserPwd_txt;
        private System.Windows.Forms.TextBox editUserName_txt;
        private System.Windows.Forms.TextBox editUserEmail_txt;
        private System.Windows.Forms.Button addUserSave_cmd;
        private System.Windows.Forms.ComboBox editUserCtgry_CmbTxt;
        private System.Windows.Forms.TextBox editUserCity_txt;
        private System.Windows.Forms.MaskedTextBox editUserPhoneNo_txt;
        private System.Windows.Forms.MaskedTextBox editUserCnic_txt;
    }
}