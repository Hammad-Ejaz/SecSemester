﻿namespace myUserGUI.UI
{
    partial class adminEditProFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminEditProFrm));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn = new System.Windows.Forms.ToolStrip();
            this.homeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.leadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETELEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWTOTALLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDPROJECTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLPROJECTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEPROJECTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saleCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.userCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.adminEditProGV = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.admineditPro_GV = new System.Windows.Forms.DataGridView();
            this.EDIT = new System.Windows.Forms.DataGridViewButtonColumn();
            this.DELETE = new System.Windows.Forms.DataGridViewButtonColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.adminEditProGV.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.admineditPro_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.11528F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.88472F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.adminEditProGV, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.21212F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1093, 660);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btn, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox2, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 26.75841F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.24159F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(192, 654);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // btn
            // 
            this.btn.AutoSize = false;
            this.btn.BackColor = System.Drawing.Color.Silver;
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeCmd,
            this.toolStripSeparator1,
            this.leadCmd,
            this.toolStripSeparator2,
            this.toolStripDropDownButton2,
            this.toolStripSeparator3,
            this.saleCmd,
            this.toolStripSeparator4,
            this.userCmd,
            this.toolStripSeparator5,
            this.toolStripButton1});
            this.btn.Location = new System.Drawing.Point(0, 174);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(191, 480);
            this.btn.Stretch = true;
            this.btn.TabIndex = 13;
            this.btn.Text = "SideBar";
            // 
            // homeCmd
            // 
            this.homeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.homeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.homeCmd.Image = ((System.Drawing.Image)(resources.GetObject("homeCmd.Image")));
            this.homeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.homeCmd.Name = "homeCmd";
            this.homeCmd.Size = new System.Drawing.Size(189, 23);
            this.homeCmd.Text = "HOME      ";
            this.homeCmd.Click += new System.EventHandler(this.HomeCmd_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(189, 6);
            // 
            // leadCmd
            // 
            this.leadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDLEADSToolStripMenuItem,
            this.dELETELEADSToolStripMenuItem,
            this.vIEWTOTALLEADSToolStripMenuItem});
            this.leadCmd.Image = ((System.Drawing.Image)(resources.GetObject("leadCmd.Image")));
            this.leadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leadCmd.Name = "leadCmd";
            this.leadCmd.Size = new System.Drawing.Size(189, 23);
            this.leadCmd.Text = "LEADS     ";
            // 
            // aDDLEADSToolStripMenuItem
            // 
            this.aDDLEADSToolStripMenuItem.Name = "aDDLEADSToolStripMenuItem";
            this.aDDLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.aDDLEADSToolStripMenuItem.Text = "ADD LEADS";
            this.aDDLEADSToolStripMenuItem.Click += new System.EventHandler(this.ADDLEADSToolStripMenuItem_Click);
            // 
            // dELETELEADSToolStripMenuItem
            // 
            this.dELETELEADSToolStripMenuItem.Name = "dELETELEADSToolStripMenuItem";
            this.dELETELEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.dELETELEADSToolStripMenuItem.Text = "EDIT LEADS";
            this.dELETELEADSToolStripMenuItem.Click += new System.EventHandler(this.DELETELEADSToolStripMenuItem_Click);
            // 
            // vIEWTOTALLEADSToolStripMenuItem
            // 
            this.vIEWTOTALLEADSToolStripMenuItem.Name = "vIEWTOTALLEADSToolStripMenuItem";
            this.vIEWTOTALLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.vIEWTOTALLEADSToolStripMenuItem.Text = "VIEW TOTAL LEADS";
            this.vIEWTOTALLEADSToolStripMenuItem.Click += new System.EventHandler(this.VIEWTOTALLEADSToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(189, 6);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDPROJECTToolStripMenuItem,
            this.vIEWALLPROJECTSToolStripMenuItem,
            this.dELETEPROJECTToolStripMenuItem});
            this.toolStripDropDownButton2.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(189, 23);
            this.toolStripDropDownButton2.Text = "PROJECT";
            this.toolStripDropDownButton2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // aDDPROJECTToolStripMenuItem
            // 
            this.aDDPROJECTToolStripMenuItem.Name = "aDDPROJECTToolStripMenuItem";
            this.aDDPROJECTToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.aDDPROJECTToolStripMenuItem.Text = "ADD PROJECT";
            this.aDDPROJECTToolStripMenuItem.Click += new System.EventHandler(this.ADDPROJECTToolStripMenuItem_Click);
            // 
            // vIEWALLPROJECTSToolStripMenuItem
            // 
            this.vIEWALLPROJECTSToolStripMenuItem.Name = "vIEWALLPROJECTSToolStripMenuItem";
            this.vIEWALLPROJECTSToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.vIEWALLPROJECTSToolStripMenuItem.Text = "VIEW ALL PROJECTS";
            this.vIEWALLPROJECTSToolStripMenuItem.Click += new System.EventHandler(this.VIEWALLPROJECTSToolStripMenuItem_Click);
            // 
            // dELETEPROJECTToolStripMenuItem
            // 
            this.dELETEPROJECTToolStripMenuItem.Name = "dELETEPROJECTToolStripMenuItem";
            this.dELETEPROJECTToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.dELETEPROJECTToolStripMenuItem.Text = "EDIT PROJECT";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(189, 6);
            // 
            // saleCmd
            // 
            this.saleCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleCmd.Image")));
            this.saleCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleCmd.Name = "saleCmd";
            this.saleCmd.Size = new System.Drawing.Size(189, 23);
            this.saleCmd.Text = "SALES        ";
            this.saleCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.saleCmd.Click += new System.EventHandler(this.SaleCmd_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(189, 6);
            // 
            // userCmd
            // 
            this.userCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDUSERToolStripMenuItem,
            this.vIEWALLUSERToolStripMenuItem,
            this.dELETEUSERToolStripMenuItem});
            this.userCmd.Image = ((System.Drawing.Image)(resources.GetObject("userCmd.Image")));
            this.userCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.userCmd.Name = "userCmd";
            this.userCmd.Size = new System.Drawing.Size(189, 23);
            this.userCmd.Text = "USERS     ";
            // 
            // aDDUSERToolStripMenuItem
            // 
            this.aDDUSERToolStripMenuItem.Name = "aDDUSERToolStripMenuItem";
            this.aDDUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.aDDUSERToolStripMenuItem.Text = "ADD USER";
            this.aDDUSERToolStripMenuItem.Click += new System.EventHandler(this.ADDUSERToolStripMenuItem_Click);
            // 
            // vIEWALLUSERToolStripMenuItem
            // 
            this.vIEWALLUSERToolStripMenuItem.Name = "vIEWALLUSERToolStripMenuItem";
            this.vIEWALLUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.vIEWALLUSERToolStripMenuItem.Text = "VIEW ALL USER";
            this.vIEWALLUSERToolStripMenuItem.Click += new System.EventHandler(this.VIEWALLUSERToolStripMenuItem_Click);
            // 
            // dELETEUSERToolStripMenuItem
            // 
            this.dELETEUSERToolStripMenuItem.Name = "dELETEUSERToolStripMenuItem";
            this.dELETEUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.dELETEUSERToolStripMenuItem.Text = "DELETE USER";
            this.dELETEUSERToolStripMenuItem.Click += new System.EventHandler(this.DELETEUSERToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(189, 6);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(189, 23);
            this.toolStripButton1.Text = "LOG OUT";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::myUserGUI.Properties.Resources.Screenshot__22_2;
            this.pictureBox2.Location = new System.Drawing.Point(3, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(185, 166);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // adminEditProGV
            // 
            this.adminEditProGV.BackColor = System.Drawing.SystemColors.Control;
            this.adminEditProGV.ColumnCount = 1;
            this.adminEditProGV.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.adminEditProGV.Controls.Add(this.label1, 0, 0);
            this.adminEditProGV.Controls.Add(this.admineditPro_GV, 0, 1);
            this.adminEditProGV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.adminEditProGV.Location = new System.Drawing.Point(201, 3);
            this.adminEditProGV.Name = "adminEditProGV";
            this.adminEditProGV.RowCount = 2;
            this.adminEditProGV.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.00917F));
            this.adminEditProGV.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.99083F));
            this.adminEditProGV.Size = new System.Drawing.Size(889, 654);
            this.adminEditProGV.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(883, 66);
            this.label1.TabIndex = 1;
            this.label1.Text = "EDIT PROJECTS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // admineditPro_GV
            // 
            this.admineditPro_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.admineditPro_GV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.EDIT,
            this.DELETE});
            this.admineditPro_GV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.admineditPro_GV.Location = new System.Drawing.Point(3, 74);
            this.admineditPro_GV.Name = "admineditPro_GV";
            this.admineditPro_GV.Size = new System.Drawing.Size(883, 577);
            this.admineditPro_GV.TabIndex = 2;
            this.admineditPro_GV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AdmineditPro_GV_CellContentClick);
            // 
            // EDIT
            // 
            this.EDIT.HeaderText = "EDIT";
            this.EDIT.Name = "EDIT";
            this.EDIT.Text = "EDIT";
            this.EDIT.ToolTipText = "EDIT";
            this.EDIT.UseColumnTextForButtonValue = true;
            // 
            // DELETE
            // 
            this.DELETE.HeaderText = "DELETE";
            this.DELETE.Name = "DELETE";
            this.DELETE.Text = "DELETE";
            this.DELETE.ToolTipText = "DELETE";
            this.DELETE.UseColumnTextForButtonValue = true;
            // 
            // adminEditProFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MaximumSize = new System.Drawing.Size(1109, 699);
            this.Name = "adminEditProFrm";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.AdminEditProFrm_Load_1);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.btn.ResumeLayout(false);
            this.btn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.adminEditProGV.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.admineditPro_GV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ToolStrip btn;
        private System.Windows.Forms.ToolStripButton homeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton leadCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETELEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWTOTALLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem aDDPROJECTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLPROJECTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEPROJECTToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton saleCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton userCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TableLayoutPanel adminEditProGV;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.DataGridView admineditPro_GV;
        private System.Windows.Forms.DataGridViewButtonColumn EDIT;
        private System.Windows.Forms.DataGridViewButtonColumn DELETE;
    }
}