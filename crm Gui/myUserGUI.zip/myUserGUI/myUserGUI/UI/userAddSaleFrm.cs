﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI.UI
{
    public partial class userAddSaleFrm : Form
    {
        MuserBL currentUser;
        public userAddSaleFrm(MuserBL currentUser) 
        {
            InitializeComponent();
            this.currentUser = currentUser;
        }

        public userSubAddSaleFrm userSubAddSaleFrm
        {
            get => default;
            set
            {
            }
        }

        private void UserAddSaleFrm_Load(object sender, EventArgs e)
        {
            userAddSale_GV.DataSource = InfoLeadDL.getLeadofSpecificSPO(currentUser.Name);
            userAddSale_GV.Columns["date"].Visible = false;
            userAddSale_GV.Columns["response"].Visible = false;
            userAddSale_GV.Columns["schedule"].Visible = false;
        }
        private void DataBind()
        {
            userAddSale_GV.DataSource = null;
            userAddSale_GV.DataSource = InfoLeadDL.getLeadofSpecificSPO(currentUser.Name);
            userAddSale_GV.Columns["date"].Visible = false;
            userAddSale_GV.Columns["response"].Visible = false;
            userAddSale_GV.Columns["schedule"].Visible = false;
            userAddSale_GV.Refresh();
        }
        private void SaleHomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMainHomeFrm home = new UserMainHomeFrm(currentUser);
            home.Show();
        }
        private void SaleTodayLeadCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTodayLeadsFrm lead = new userTodayLeadsFrm(currentUser);
            lead.Show();
        }
        private void SaleTotalLeadCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTotalLeadsFrm totalLead = new userTotalLeadsFrm(currentUser);
            totalLead.Show();
        }
        private void SaleProjectCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userProjectInfoFrm project = new userProjectInfoFrm(currentUser);
            project.Show();
        }
        private void SaleAddSaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userAddSaleFrm sale = new userAddSaleFrm(currentUser);
            sale.Show();
        }
        private void SaleViewAllCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userViewTotalSale TotalSale = new userViewTotalSale(currentUser);
            TotalSale.Show();
        }
        private void SaleLogoutCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
        }
        private void UserAddSale_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            InfoClientsBL lead = (InfoClientsBL)userAddSale_GV.CurrentRow.DataBoundItem;
            if (userAddSale_GV.Columns[0].Index == e.ColumnIndex)
            {
                userSubAddSaleFrm edit = new userSubAddSaleFrm(lead);
                edit.ShowDialog();
                DataBind();
            }
        }
    }
}
