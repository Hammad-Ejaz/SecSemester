﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminSubEditProjectFrm : Form
    {
        private ProjectBL project;
        public adminSubEditProjectFrm(ProjectBL project)
        {
            InitializeComponent();
            this.project = project;
        }

        private void AdminSubEditProjectFrm_Load(object sender, EventArgs e)
        {
            subAddProName_txt.Text = project.Name;
            SubAddProCity_txt.Text = project.City;
            subEditPro_cmb.DataSource = project.Area.Select(o => o.Marla).ToList();
            subEditPro_cmb.DisplayMember = "marla";
        }
        private void SubaddProSave_Cmd_Click(object sender, EventArgs e)
        {
            try
            {
                ProjectBL update = new ProjectBL(subAddProName_txt.Text, SubAddProCity_txt.Text);
                int Marla = int.Parse(subEditPro_cmb.Text.ToString());
                int Plots = int.Parse(adminSubEditPlots_txt.Text.ToString());
                AreaBL area = new AreaBL(Marla, Plots);
                update.Area.Add(area);
                ProjectDL.EditProject(project, update);
                MessageBox.Show("Updated Successfuly");
                this.Close();
            }
            catch
            {
                MessageBox.Show("Invalid");
            }
        }
    }
}
