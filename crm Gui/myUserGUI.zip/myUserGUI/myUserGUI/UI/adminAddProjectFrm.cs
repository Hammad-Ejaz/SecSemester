﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.UI;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI
{
    public partial class adminAddProjectFrm : adminModel
    {
        public adminAddProjectFrm()
        {
            InitializeComponent();
        }

        private void AddProAddMore_cmd_Click(object sender, EventArgs e)
        {
            if (addProName_txt.Text != null && addProCity_txt.Text != null && addProMarla_txt.Text != "" && addProPlots_txt.Text != "")
            {
                MessageBox.Show(addProMarla_txt.Text);
                int marla = int.Parse(addProMarla_txt.Text);
                int plots = int.Parse(addProPlots_txt.Text);
                AreaBL area = new AreaBL(marla, plots);
                if (ProjectDL.getSpecificProject(addProName_txt.Text, addProCity_txt.Text).areaExist(area)) MessageBox.Show("Area Exists AlReady");
                else if (ProjectDL.getSpecificProject(addProName_txt.Text, addProCity_txt.Text) == null) MessageBox.Show("Project doesnot Exists");
                else
                {
                    ProjectDL.getSpecificProject(addProName_txt.Text, addProCity_txt.Text).Area.Add(area);
                    ProjectDL.storeData("Project.txt");
                    addProMarla_txt.Text = null;
                    addProPlots_txt.Text = null;
                    MessageBox.Show("Area Added Successfuly");
                }
            }
            else MessageBox.Show("Something Went Wrong");
        }

        private void AddProSave_Cmd_Click(object sender, EventArgs e)
        {
            try
            {
                if (ProjectDL.getSpecificProject(addProName_txt.Text, addProCity_txt.Text) != null) MessageBox.Show("Project AlReady Exists");
                else
                {
                    string name = addProName_txt.Text;
                    string city = addProCity_txt.Text;
                    int marla = int.Parse(addProMarla_txt.Text);
                    int plots = int.Parse(addProPlots_txt.Text);
                    AreaBL area = new AreaBL(marla, plots);
                    ProjectBL project = new ProjectBL(name, city);
                    project.Area.Add(area);
                    ProjectDL.addProject(project);
                    ProjectDL.storeData("Project.txt");
                    MessageBox.Show("Project Added Successfuly");
                    addProMarla_txt.Text = null;
                    addProPlots_txt.Text = null;
                }
            }
            catch
            {
                MessageBox.Show("Invalid");
            }
        }
    }
}
