﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminSubEditLeadFrm : Form
    {
        private InfoClientsBL previous;
        public adminSubEditLeadFrm(InfoClientsBL previous)
        {
            InitializeComponent();
            this.previous = previous;
        }

        private void AdminSubEditLeadFrm_Load(object sender, EventArgs e)
        {
            editLeadName_txt.Text = previous.Name;
            editLeadPhone_txt.Text = previous.Phone;
            editLeadPro_cmb.DataSource = ProjectDL.AllProjects;
            editLeadPro_cmb.DisplayMember = "name";
            editLeadSpo_cmb.DataSource = MuserDL.myEmployes();
            editLeadSpo_cmb.DisplayMember = "name";
        }

        private void EditLeadSave_cmd_Click(object sender, EventArgs e)
        {
            if (editLeadName_txt.Text != null && editLeadPhone_txt.Text != null && editLeadPro_cmb.Text != "" && editLeadSource_cmb.Text != "" && editLeadSpo_cmb.Text != "" && editLeadPhone_txt.Text.Length == 11)
            {
                InfoClientsBL update = new InfoClientsBL(editLeadSpo_cmb.Text, editLeadName_txt.Text, editLeadPhone_txt.Text, editLeadPro_cmb.Text, editLeadSource_cmb.Text);
                update.Date = DateTime.Parse(editDate.Text);
                InfoLeadDL.editLead(previous, update);
                MessageBox.Show("Lead Updated successfuly");
                this.Close();
            }
            else MessageBox.Show("invalid");
        }
    }
}
