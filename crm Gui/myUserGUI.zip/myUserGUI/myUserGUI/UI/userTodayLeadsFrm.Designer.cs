﻿namespace myUserGUI.UI
{
    partial class userTodayLeadsFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userTodayLeadsFrm));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.todayLead_GV = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.saleHomeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saleLeadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.saleTodayLeadCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.saleTotalLeadCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.saleProjectCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.saleAddSaleCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.SaleViewAllCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.SaleLogoutCmd = new System.Windows.Forms.ToolStripButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.todayLead_GV)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.75572F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.24429F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1093, 660);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.BackColor = System.Drawing.SystemColors.Control;
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(207, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 1;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 24.61774F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(883, 654);
            this.tableLayoutPanel3.TabIndex = 4;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 1;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.todayLead_GV, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.49383F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.50617F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(877, 648);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // todayLead_GV
            // 
            this.todayLead_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.todayLead_GV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2});
            this.todayLead_GV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.todayLead_GV.Location = new System.Drawing.Point(3, 71);
            this.todayLead_GV.Name = "todayLead_GV";
            this.todayLead_GV.ReadOnly = true;
            this.todayLead_GV.Size = new System.Drawing.Size(871, 574);
            this.todayLead_GV.TabIndex = 3;
            this.todayLead_GV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TodayLead_GV_CellContentClick);
            // 
            // Column2
            // 
            this.Column2.HeaderText = "ADD RESPONSE";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            this.Column2.Text = "ADD RESPONSE";
            this.Column2.ToolTipText = "ADD RESPONSE";
            this.Column2.UseColumnTextForButtonValue = true;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(871, 68);
            this.label1.TabIndex = 2;
            this.label1.Text = "TODAY LEADS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.toolStrip1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.87879F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.12122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(198, 654);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.Silver;
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip1.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleHomeCmd,
            this.toolStripSeparator3,
            this.saleLeadCmd,
            this.toolStripSeparator6,
            this.saleProjectCmd,
            this.toolStripSeparator7,
            this.toolStripDropDownButton2,
            this.toolStripSeparator8,
            this.SaleLogoutCmd});
            this.toolStrip1.Location = new System.Drawing.Point(0, 180);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(198, 465);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 15;
            this.toolStrip1.Text = "SideBar";
            // 
            // saleHomeCmd
            // 
            this.saleHomeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.saleHomeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.saleHomeCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleHomeCmd.Image")));
            this.saleHomeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleHomeCmd.Name = "saleHomeCmd";
            this.saleHomeCmd.Size = new System.Drawing.Size(196, 23);
            this.saleHomeCmd.Text = "HOME            ";
            this.saleHomeCmd.Click += new System.EventHandler(this.SaleHomeCmd_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(196, 6);
            // 
            // saleLeadCmd
            // 
            this.saleLeadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleTodayLeadCmd,
            this.saleTotalLeadCmd});
            this.saleLeadCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleLeadCmd.Image")));
            this.saleLeadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleLeadCmd.Name = "saleLeadCmd";
            this.saleLeadCmd.Size = new System.Drawing.Size(196, 23);
            this.saleLeadCmd.Text = "LEADS             ";
            // 
            // saleTodayLeadCmd
            // 
            this.saleTodayLeadCmd.Name = "saleTodayLeadCmd";
            this.saleTodayLeadCmd.Size = new System.Drawing.Size(206, 24);
            this.saleTodayLeadCmd.Text = "TODAY LEADS";
            // 
            // saleTotalLeadCmd
            // 
            this.saleTotalLeadCmd.Name = "saleTotalLeadCmd";
            this.saleTotalLeadCmd.Size = new System.Drawing.Size(206, 24);
            this.saleTotalLeadCmd.Text = "VIEW TOTAL LEADS";
            this.saleTotalLeadCmd.Click += new System.EventHandler(this.SaleTotalLeadCmd_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(196, 6);
            // 
            // saleProjectCmd
            // 
            this.saleProjectCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleProjectCmd.Image")));
            this.saleProjectCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleProjectCmd.Name = "saleProjectCmd";
            this.saleProjectCmd.Size = new System.Drawing.Size(196, 23);
            this.saleProjectCmd.Text = "PROJETCS INFO";
            this.saleProjectCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.saleProjectCmd.Click += new System.EventHandler(this.SaleProjectCmd_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(196, 6);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleAddSaleCmd,
            this.SaleViewAllCmd});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(196, 23);
            this.toolStripDropDownButton2.Text = "SALE               ";
            // 
            // saleAddSaleCmd
            // 
            this.saleAddSaleCmd.Name = "saleAddSaleCmd";
            this.saleAddSaleCmd.Size = new System.Drawing.Size(184, 24);
            this.saleAddSaleCmd.Text = "ADD SALE";
            this.saleAddSaleCmd.Click += new System.EventHandler(this.SaleAddSaleCmd_Click);
            // 
            // SaleViewAllCmd
            // 
            this.SaleViewAllCmd.Name = "SaleViewAllCmd";
            this.SaleViewAllCmd.Size = new System.Drawing.Size(184, 24);
            this.SaleViewAllCmd.Text = "VIEW ALL SALES";
            this.SaleViewAllCmd.Click += new System.EventHandler(this.SaleViewAllCmd_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(196, 6);
            // 
            // SaleLogoutCmd
            // 
            this.SaleLogoutCmd.Image = ((System.Drawing.Image)(resources.GetObject("SaleLogoutCmd.Image")));
            this.SaleLogoutCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaleLogoutCmd.Name = "SaleLogoutCmd";
            this.SaleLogoutCmd.Size = new System.Drawing.Size(196, 23);
            this.SaleLogoutCmd.Text = "LOG OUT          ";
            this.SaleLogoutCmd.Click += new System.EventHandler(this.SaleLogoutCmd_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = global::myUserGUI.Properties.Resources.Screenshot__22_3;
            this.pictureBox3.Location = new System.Drawing.Point(3, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(192, 174);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // userTodayLeadsFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "userTodayLeadsFrm";
            this.Text = "Form14";
            this.Load += new System.EventHandler(this.UserTodayLeadsFrm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.todayLead_GV)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton saleHomeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton saleLeadCmd;
        private System.Windows.Forms.ToolStripMenuItem saleTodayLeadCmd;
        private System.Windows.Forms.ToolStripMenuItem saleTotalLeadCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton saleProjectCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem saleAddSaleCmd;
        private System.Windows.Forms.ToolStripMenuItem SaleViewAllCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton SaleLogoutCmd;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.DataGridView todayLead_GV;
        private System.Windows.Forms.DataGridViewButtonColumn Column2;
        private System.Windows.Forms.Label label1;
    }
}