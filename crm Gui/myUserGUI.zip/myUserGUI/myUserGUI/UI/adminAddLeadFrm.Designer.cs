﻿namespace myUserGUI.UI
{
    partial class adminAddLeadFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.addLeadPhone_txt = new System.Windows.Forms.MaskedTextBox();
            this.addLeadPro_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadSpo_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadSource_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadSave_cmd = new System.Windows.Forms.Button();
            this.addLeadName_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.adminAddLeadName_txt = new System.Windows.Forms.TextBox();
            this.Save_cmd = new System.Windows.Forms.Button();
            this.adminAddLeadSource_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadSpoName_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadProject_cmb = new System.Windows.Forms.ComboBox();
            this.addLeadPhoneNo_txt = new System.Windows.Forms.MaskedTextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.5771F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.4229F));
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 77);
            this.tableLayoutPanel4.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 8;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.73427F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.26574F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 353F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.TabIndex = 0;
            // 
            // addLeadPhone_txt
            // 
            this.addLeadPhone_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadPhone_txt.Location = new System.Drawing.Point(452, 196);
            this.addLeadPhone_txt.Mask = "00000000000";
            this.addLeadPhone_txt.Name = "addLeadPhone_txt";
            this.addLeadPhone_txt.Size = new System.Drawing.Size(171, 20);
            this.addLeadPhone_txt.TabIndex = 22;
            // 
            // addLeadPro_cmb
            // 
            this.addLeadPro_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadPro_cmb.FormattingEnabled = true;
            this.addLeadPro_cmb.Location = new System.Drawing.Point(452, 148);
            this.addLeadPro_cmb.Name = "addLeadPro_cmb";
            this.addLeadPro_cmb.Size = new System.Drawing.Size(171, 21);
            this.addLeadPro_cmb.TabIndex = 21;
            // 
            // addLeadSpo_cmb
            // 
            this.addLeadSpo_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadSpo_cmb.FormattingEnabled = true;
            this.addLeadSpo_cmb.Location = new System.Drawing.Point(452, 244);
            this.addLeadSpo_cmb.Name = "addLeadSpo_cmb";
            this.addLeadSpo_cmb.Size = new System.Drawing.Size(171, 21);
            this.addLeadSpo_cmb.TabIndex = 20;
            // 
            // addLeadSource_cmb
            // 
            this.addLeadSource_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadSource_cmb.FormattingEnabled = true;
            this.addLeadSource_cmb.Items.AddRange(new object[] {
            "Website",
            "Instagram",
            "Facebook",
            "Twitter"});
            this.addLeadSource_cmb.Location = new System.Drawing.Point(452, 99);
            this.addLeadSource_cmb.Name = "addLeadSource_cmb";
            this.addLeadSource_cmb.Size = new System.Drawing.Size(171, 21);
            this.addLeadSource_cmb.TabIndex = 19;
            // 
            // addLeadSave_cmd
            // 
            this.addLeadSave_cmd.Location = new System.Drawing.Point(452, 309);
            this.addLeadSave_cmd.Name = "addLeadSave_cmd";
            this.addLeadSave_cmd.Size = new System.Drawing.Size(171, 23);
            this.addLeadSave_cmd.TabIndex = 18;
            this.addLeadSave_cmd.Text = "SAVE";
            this.addLeadSave_cmd.UseVisualStyleBackColor = true;
            // 
            // addLeadName_txt
            // 
            this.addLeadName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadName_txt.Location = new System.Drawing.Point(452, 49);
            this.addLeadName_txt.Multiline = true;
            this.addLeadName_txt.Name = "addLeadName_txt";
            this.addLeadName_txt.Size = new System.Drawing.Size(171, 29);
            this.addLeadName_txt.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 32);
            this.label2.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 30);
            this.label4.TabIndex = 2;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 32);
            this.label6.TabIndex = 4;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 32);
            this.label8.TabIndex = 6;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 236);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 32);
            this.label10.TabIndex = 8;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1097, 74);
            this.label1.TabIndex = 1;
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(195, -1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.33334F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(900, 660);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.32913F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.67088F));
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 4);
            this.tableLayoutPanel2.Controls.Add(this.label7, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label11, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label12, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.adminAddLeadName_txt, 1, 0);
            this.tableLayoutPanel2.Controls.Add(this.Save_cmd, 1, 6);
            this.tableLayoutPanel2.Controls.Add(this.adminAddLeadSource_cmb, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.addLeadSpoName_cmb, 1, 4);
            this.tableLayoutPanel2.Controls.Add(this.addLeadProject_cmb, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.addLeadPhoneNo_txt, 1, 3);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 80);
            this.tableLayoutPanel2.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 8;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.73427F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.26574F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 353F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel2.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label5.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(3, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(154, 32);
            this.label5.TabIndex = 8;
            this.label5.Text = "ASSIGNED TO";
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label7.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 187);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(154, 32);
            this.label7.TabIndex = 6;
            this.label7.Text = "PHONE NO";
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label9.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(3, 140);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(154, 32);
            this.label9.TabIndex = 4;
            this.label9.Text = "PROJECT";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label11.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(3, 93);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(154, 30);
            this.label11.TabIndex = 2;
            this.label11.Text = "SOURCE";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label12.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 49);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(154, 32);
            this.label12.TabIndex = 0;
            this.label12.Text = "NAME";
            // 
            // adminAddLeadName_txt
            // 
            this.adminAddLeadName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.adminAddLeadName_txt.Location = new System.Drawing.Point(173, 49);
            this.adminAddLeadName_txt.Multiline = true;
            this.adminAddLeadName_txt.Name = "adminAddLeadName_txt";
            this.adminAddLeadName_txt.Size = new System.Drawing.Size(171, 29);
            this.adminAddLeadName_txt.TabIndex = 11;
            // 
            // Save_cmd
            // 
            this.Save_cmd.Location = new System.Drawing.Point(173, 309);
            this.Save_cmd.Name = "Save_cmd";
            this.Save_cmd.Size = new System.Drawing.Size(171, 23);
            this.Save_cmd.TabIndex = 18;
            this.Save_cmd.Text = "SAVE";
            this.Save_cmd.UseVisualStyleBackColor = true;
            this.Save_cmd.Click += new System.EventHandler(this.Save_cmd_Click);
            // 
            // adminAddLeadSource_cmb
            // 
            this.adminAddLeadSource_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.adminAddLeadSource_cmb.FormattingEnabled = true;
            this.adminAddLeadSource_cmb.Items.AddRange(new object[] {
            "Website",
            "Instagram",
            "Facebook",
            "Twitter"});
            this.adminAddLeadSource_cmb.Location = new System.Drawing.Point(173, 99);
            this.adminAddLeadSource_cmb.Name = "adminAddLeadSource_cmb";
            this.adminAddLeadSource_cmb.Size = new System.Drawing.Size(171, 21);
            this.adminAddLeadSource_cmb.TabIndex = 19;
            // 
            // addLeadSpoName_cmb
            // 
            this.addLeadSpoName_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadSpoName_cmb.FormattingEnabled = true;
            this.addLeadSpoName_cmb.Location = new System.Drawing.Point(173, 244);
            this.addLeadSpoName_cmb.Name = "addLeadSpoName_cmb";
            this.addLeadSpoName_cmb.Size = new System.Drawing.Size(171, 21);
            this.addLeadSpoName_cmb.TabIndex = 20;
            // 
            // addLeadProject_cmb
            // 
            this.addLeadProject_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadProject_cmb.FormattingEnabled = true;
            this.addLeadProject_cmb.Location = new System.Drawing.Point(173, 148);
            this.addLeadProject_cmb.Name = "addLeadProject_cmb";
            this.addLeadProject_cmb.Size = new System.Drawing.Size(171, 21);
            this.addLeadProject_cmb.TabIndex = 21;
            // 
            // addLeadPhoneNo_txt
            // 
            this.addLeadPhoneNo_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addLeadPhoneNo_txt.Location = new System.Drawing.Point(173, 196);
            this.addLeadPhoneNo_txt.Mask = "00000000000";
            this.addLeadPhoneNo_txt.Name = "addLeadPhoneNo_txt";
            this.addLeadPhoneNo_txt.Size = new System.Drawing.Size(171, 20);
            this.addLeadPhoneNo_txt.TabIndex = 22;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(894, 77);
            this.label3.TabIndex = 2;
            this.label3.Text = "ADD LEADS";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminAddLeadFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "adminAddLeadFrm";
            this.Text = "ADD LEAD";
            this.Load += new System.EventHandler(this.AdminAddLeadFrm_Load);
            this.Controls.SetChildIndex(this.tableLayoutPanel1, 0);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.MaskedTextBox addLeadPhone_txt;
        private System.Windows.Forms.ComboBox addLeadPro_cmb;
        private System.Windows.Forms.ComboBox addLeadSpo_cmb;
        private System.Windows.Forms.ComboBox addLeadSource_cmb;
        private System.Windows.Forms.Button addLeadSave_cmd;
        private System.Windows.Forms.TextBox addLeadName_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox adminAddLeadName_txt;
        private System.Windows.Forms.Button Save_cmd;
        private System.Windows.Forms.ComboBox adminAddLeadSource_cmb;
        private System.Windows.Forms.ComboBox addLeadSpoName_cmb;
        private System.Windows.Forms.ComboBox addLeadProject_cmb;
        private System.Windows.Forms.MaskedTextBox addLeadPhoneNo_txt;
        private System.Windows.Forms.Label label3;
    }
}