﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class userTodayLeadsFrm : Form
    {
        MuserBL currentUser;
        public userTodayLeadsFrm(MuserBL currentUser)
        {
            InitializeComponent();
            this.currentUser = currentUser;
        }
        private void DataBind()
        {
            todayLead_GV.DataSource = null;
            todayLead_GV.DataSource = InfoLeadDL.getTodayLeadsOfSpecificSpo(currentUser.Name);
            todayLead_GV.Columns["date"].Visible = false;
            todayLead_GV.Columns["response"].Visible = false;
            todayLead_GV.Columns["schedule"].Visible = false;
            todayLead_GV.Refresh();
        }
        private void UserTodayLeadsFrm_Load(object sender, EventArgs e)
        {
            todayLead_GV.DataSource = InfoLeadDL.getTodayLeadsOfSpecificSpo(currentUser.Name);
            todayLead_GV.Columns["date"].Visible = false;
            todayLead_GV.Columns["response"].Visible = false;
            todayLead_GV.Columns["schedule"].Visible = false;
        }

        private void TodayLead_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            InfoClientsBL lead = (InfoClientsBL)todayLead_GV.CurrentRow.DataBoundItem;
            if (todayLead_GV.Columns[0].Index == e.ColumnIndex)
            {
                userResponseFrm edit = new userResponseFrm(lead);
                edit.ShowDialog();
                InfoLeadDL.saveData("Lead.txt");
                DataBind();
            }
        }

        private void SaleHomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMainHomeFrm home = new UserMainHomeFrm(currentUser);
            home.Show();
        }

        private void SaleTotalLeadCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTotalLeadsFrm totalLead = new userTotalLeadsFrm(currentUser);
            totalLead.Show();
        }

        private void SaleProjectCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userProjectInfoFrm project = new userProjectInfoFrm(currentUser);
            project.Show();
        }

        private void SaleAddSaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userAddSaleFrm sale = new userAddSaleFrm(currentUser);
            sale.Show();
        }

        private void SaleViewAllCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userViewTotalSale allSale = new userViewTotalSale(currentUser);
            allSale.Show();
        }

        private void SaleLogoutCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
            login.Show();
        }
    }
}
