﻿namespace myUserGUI.UI
{
    partial class UserMainHomeFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserMainHomeFrm));
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.btn = new System.Windows.Forms.ToolStrip();
            this.homeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.leadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWTOTALLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.saleCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.userCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.userHomeTFollowUp_lbl = new System.Windows.Forms.Label();
            this.userHomeTMeeting_lbl = new System.Windows.Forms.Label();
            this.userHomeTHot_lbl = new System.Windows.Forms.Label();
            this.userHomeTvisits_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.userHomeTlead_lbl = new System.Windows.Forms.Label();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel9 = new System.Windows.Forms.TableLayoutPanel();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel9.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 34.33836F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 65.66164F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 495F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel6, 2, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1091, 676);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.btn, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox1, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox2, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.87879F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.12122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(198, 670);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // btn
            // 
            this.btn.AutoSize = false;
            this.btn.BackColor = System.Drawing.Color.Silver;
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeCmd,
            this.toolStripSeparator1,
            this.leadCmd,
            this.toolStripSeparator2,
            this.saleCmd,
            this.toolStripSeparator4,
            this.userCmd,
            this.toolStripSeparator5,
            this.toolStripButton1});
            this.btn.Location = new System.Drawing.Point(0, 184);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(198, 477);
            this.btn.Stretch = true;
            this.btn.TabIndex = 15;
            this.btn.Text = "SideBar";
            // 
            // homeCmd
            // 
            this.homeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.homeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.homeCmd.Image = ((System.Drawing.Image)(resources.GetObject("homeCmd.Image")));
            this.homeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.homeCmd.Name = "homeCmd";
            this.homeCmd.Size = new System.Drawing.Size(196, 23);
            this.homeCmd.Text = "HOME            ";
            this.homeCmd.Click += new System.EventHandler(this.HomeCmd_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(196, 6);
            // 
            // leadCmd
            // 
            this.leadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDLEADSToolStripMenuItem,
            this.vIEWTOTALLEADSToolStripMenuItem});
            this.leadCmd.Image = ((System.Drawing.Image)(resources.GetObject("leadCmd.Image")));
            this.leadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leadCmd.Name = "leadCmd";
            this.leadCmd.Size = new System.Drawing.Size(196, 23);
            this.leadCmd.Text = "LEADS             ";
            // 
            // aDDLEADSToolStripMenuItem
            // 
            this.aDDLEADSToolStripMenuItem.Name = "aDDLEADSToolStripMenuItem";
            this.aDDLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.aDDLEADSToolStripMenuItem.Text = "TODAY LEADS";
            this.aDDLEADSToolStripMenuItem.Click += new System.EventHandler(this.ADDLEADSToolStripMenuItem_Click);
            // 
            // vIEWTOTALLEADSToolStripMenuItem
            // 
            this.vIEWTOTALLEADSToolStripMenuItem.Name = "vIEWTOTALLEADSToolStripMenuItem";
            this.vIEWTOTALLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.vIEWTOTALLEADSToolStripMenuItem.Text = "VIEW TOTAL LEADS";
            this.vIEWTOTALLEADSToolStripMenuItem.Click += new System.EventHandler(this.VIEWTOTALLEADSToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(196, 6);
            // 
            // saleCmd
            // 
            this.saleCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleCmd.Image")));
            this.saleCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleCmd.Name = "saleCmd";
            this.saleCmd.Size = new System.Drawing.Size(196, 23);
            this.saleCmd.Text = "PROJETCS INFO";
            this.saleCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.saleCmd.Click += new System.EventHandler(this.SaleCmd_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(196, 6);
            // 
            // userCmd
            // 
            this.userCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDUSERToolStripMenuItem,
            this.vIEWALLUSERToolStripMenuItem});
            this.userCmd.Image = ((System.Drawing.Image)(resources.GetObject("userCmd.Image")));
            this.userCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.userCmd.Name = "userCmd";
            this.userCmd.Size = new System.Drawing.Size(196, 23);
            this.userCmd.Text = "SALE               ";
            // 
            // aDDUSERToolStripMenuItem
            // 
            this.aDDUSERToolStripMenuItem.Name = "aDDUSERToolStripMenuItem";
            this.aDDUSERToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.aDDUSERToolStripMenuItem.Text = "ADD SALE";
            this.aDDUSERToolStripMenuItem.Click += new System.EventHandler(this.ADDUSERToolStripMenuItem_Click);
            // 
            // vIEWALLUSERToolStripMenuItem
            // 
            this.vIEWALLUSERToolStripMenuItem.Name = "vIEWALLUSERToolStripMenuItem";
            this.vIEWALLUSERToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.vIEWALLUSERToolStripMenuItem.Text = "VIEW ALL SALES";
            this.vIEWALLUSERToolStripMenuItem.Click += new System.EventHandler(this.VIEWALLUSERToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(196, 6);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(196, 23);
            this.toolStripButton1.Text = "LOG OUT          ";
            this.toolStripButton1.Click += new System.EventHandler(this.ToolStripButton1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(3, 664);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 3);
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = global::myUserGUI.Properties.Resources.Screenshot__22_3;
            this.pictureBox2.Location = new System.Drawing.Point(3, 3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(192, 178);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 17;
            this.pictureBox2.TabStop = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel4, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.tableLayoutPanel5, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.userHomeTlead_lbl, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(207, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.34375F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.65625F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 505F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(385, 670);
            this.tableLayoutPanel3.TabIndex = 2;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Controls.Add(this.userHomeTFollowUp_lbl, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.userHomeTMeeting_lbl, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.userHomeTHot_lbl, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.userHomeTvisits_lbl, 1, 0);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 167);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(379, 500);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // userHomeTFollowUp_lbl
            // 
            this.userHomeTFollowUp_lbl.AutoSize = true;
            this.userHomeTFollowUp_lbl.BackColor = System.Drawing.SystemColors.ControlLight;
            this.userHomeTFollowUp_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userHomeTFollowUp_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userHomeTFollowUp_lbl.Location = new System.Drawing.Point(3, 0);
            this.userHomeTFollowUp_lbl.Name = "userHomeTFollowUp_lbl";
            this.userHomeTFollowUp_lbl.Size = new System.Drawing.Size(183, 250);
            this.userHomeTFollowUp_lbl.TabIndex = 11;
            this.userHomeTFollowUp_lbl.Text = "TOTAL FOLLOW UPS";
            this.userHomeTFollowUp_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // userHomeTMeeting_lbl
            // 
            this.userHomeTMeeting_lbl.AutoSize = true;
            this.userHomeTMeeting_lbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.userHomeTMeeting_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userHomeTMeeting_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userHomeTMeeting_lbl.Location = new System.Drawing.Point(3, 250);
            this.userHomeTMeeting_lbl.Name = "userHomeTMeeting_lbl";
            this.userHomeTMeeting_lbl.Size = new System.Drawing.Size(183, 250);
            this.userHomeTMeeting_lbl.TabIndex = 17;
            this.userHomeTMeeting_lbl.Text = "TOTAL MEETINGS";
            this.userHomeTMeeting_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // userHomeTHot_lbl
            // 
            this.userHomeTHot_lbl.AutoSize = true;
            this.userHomeTHot_lbl.BackColor = System.Drawing.SystemColors.ControlLight;
            this.userHomeTHot_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userHomeTHot_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userHomeTHot_lbl.Location = new System.Drawing.Point(192, 250);
            this.userHomeTHot_lbl.Name = "userHomeTHot_lbl";
            this.userHomeTHot_lbl.Size = new System.Drawing.Size(184, 250);
            this.userHomeTHot_lbl.TabIndex = 20;
            this.userHomeTHot_lbl.Text = "TOTAL HOT CLIENTS";
            this.userHomeTHot_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // userHomeTvisits_lbl
            // 
            this.userHomeTvisits_lbl.AutoSize = true;
            this.userHomeTvisits_lbl.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.userHomeTvisits_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userHomeTvisits_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userHomeTvisits_lbl.Location = new System.Drawing.Point(192, 0);
            this.userHomeTvisits_lbl.Name = "userHomeTvisits_lbl";
            this.userHomeTvisits_lbl.Size = new System.Drawing.Size(184, 250);
            this.userHomeTvisits_lbl.TabIndex = 14;
            this.userHomeTvisits_lbl.Text = "TOTAL VISITS";
            this.userHomeTvisits_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 1;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel5.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 1;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(379, 80);
            this.tableLayoutPanel5.TabIndex = 10;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(373, 80);
            this.label1.TabIndex = 9;
            this.label1.Text = "TODAY ACTIVITY";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // userHomeTlead_lbl
            // 
            this.userHomeTlead_lbl.AutoSize = true;
            this.userHomeTlead_lbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.userHomeTlead_lbl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userHomeTlead_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.userHomeTlead_lbl.Location = new System.Drawing.Point(3, 86);
            this.userHomeTlead_lbl.Name = "userHomeTlead_lbl";
            this.userHomeTlead_lbl.Size = new System.Drawing.Size(379, 78);
            this.userHomeTlead_lbl.TabIndex = 8;
            this.userHomeTlead_lbl.Text = "TOTAL LEADS";
            this.userHomeTlead_lbl.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 1;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel6.Controls.Add(this.tableLayoutPanel9, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.label3, 0, 0);
            this.tableLayoutPanel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel6.Location = new System.Drawing.Point(598, 3);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 3;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 13.81215F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 86.18784F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 110F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(490, 670);
            this.tableLayoutPanel6.TabIndex = 3;
            // 
            // tableLayoutPanel9
            // 
            this.tableLayoutPanel9.ColumnCount = 1;
            this.tableLayoutPanel9.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel9.Controls.Add(this.button1, 0, 0);
            this.tableLayoutPanel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel9.Location = new System.Drawing.Point(3, 562);
            this.tableLayoutPanel9.Name = "tableLayoutPanel9";
            this.tableLayoutPanel9.RowCount = 1;
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 73.52941F));
            this.tableLayoutPanel9.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel9.Size = new System.Drawing.Size(484, 105);
            this.tableLayoutPanel9.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(375, 3);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 41);
            this.button1.TabIndex = 2;
            this.button1.Text = "SAVE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(484, 77);
            this.label3.TabIndex = 1;
            this.label3.Text = "NOTES";
            this.label3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // UserMainHomeFrm
            // 
            this.ClientSize = new System.Drawing.Size(1091, 676);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UserMainHomeFrm";
            this.Text = "USER HOME";
            this.Load += new System.EventHandler(this.UserMainHomeFrm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.btn.ResumeLayout(false);
            this.btn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel9.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ToolStrip btn;
        private System.Windows.Forms.ToolStripButton homeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton leadCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWTOTALLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton saleCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton userCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label userHomeTlead_lbl;
        private System.Windows.Forms.Label userHomeTFollowUp_lbl;
        private System.Windows.Forms.Label userHomeTvisits_lbl;
        private System.Windows.Forms.Label userHomeTMeeting_lbl;
        private System.Windows.Forms.Label userHomeTHot_lbl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel9;
        private System.Windows.Forms.Button button1;
    }
}
