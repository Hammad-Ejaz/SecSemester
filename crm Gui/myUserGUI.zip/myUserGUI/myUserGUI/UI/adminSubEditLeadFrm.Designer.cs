﻿namespace myUserGUI.UI
{
    partial class adminSubEditLeadFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.editLeadName_txt = new System.Windows.Forms.TextBox();
            this.editLeadSave_cmd = new System.Windows.Forms.Button();
            this.editLeadSource_cmb = new System.Windows.Forms.ComboBox();
            this.editLeadSpo_cmb = new System.Windows.Forms.ComboBox();
            this.editLeadPro_cmb = new System.Windows.Forms.ComboBox();
            this.editLeadPhone_txt = new System.Windows.Forms.MaskedTextBox();
            this.DATE = new System.Windows.Forms.Label();
            this.editDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 0.7213706F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 31.21212F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 10.53391F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 89.46609F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(1103, 693);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.32913F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.67088F));
            this.tableLayoutPanel4.Controls.Add(this.label10, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.label8, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label2, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.editLeadName_txt, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.editLeadSave_cmd, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.editLeadSource_cmb, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.editLeadSpo_cmb, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.editLeadPro_cmb, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.editLeadPhone_txt, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.DATE, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.editDate, 1, 5);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 75);
            this.tableLayoutPanel4.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 8;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.73427F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.26574F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 38F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 353F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label10.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(3, 236);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(154, 32);
            this.label10.TabIndex = 8;
            this.label10.Text = "ASSIGNED TO";
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label8.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(3, 187);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(154, 32);
            this.label8.TabIndex = 6;
            this.label8.Text = "PHONE NO";
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(154, 32);
            this.label6.TabIndex = 4;
            this.label6.Text = "PROJECT";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 93);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(154, 30);
            this.label4.TabIndex = 2;
            this.label4.Text = "SOURCE";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 32);
            this.label2.TabIndex = 0;
            this.label2.Text = "NAME";
            // 
            // editLeadName_txt
            // 
            this.editLeadName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadName_txt.Location = new System.Drawing.Point(173, 49);
            this.editLeadName_txt.Multiline = true;
            this.editLeadName_txt.Name = "editLeadName_txt";
            this.editLeadName_txt.Size = new System.Drawing.Size(171, 29);
            this.editLeadName_txt.TabIndex = 11;
            // 
            // editLeadSave_cmd
            // 
            this.editLeadSave_cmd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadSave_cmd.Location = new System.Drawing.Point(173, 319);
            this.editLeadSave_cmd.Name = "editLeadSave_cmd";
            this.editLeadSave_cmd.Size = new System.Drawing.Size(171, 23);
            this.editLeadSave_cmd.TabIndex = 18;
            this.editLeadSave_cmd.Text = "SAVE";
            this.editLeadSave_cmd.UseVisualStyleBackColor = true;
            this.editLeadSave_cmd.Click += new System.EventHandler(this.EditLeadSave_cmd_Click);
            // 
            // editLeadSource_cmb
            // 
            this.editLeadSource_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadSource_cmb.FormattingEnabled = true;
            this.editLeadSource_cmb.Items.AddRange(new object[] {
            "Website",
            "Instagram",
            "Facebook",
            "Twitter"});
            this.editLeadSource_cmb.Location = new System.Drawing.Point(173, 99);
            this.editLeadSource_cmb.Name = "editLeadSource_cmb";
            this.editLeadSource_cmb.Size = new System.Drawing.Size(171, 21);
            this.editLeadSource_cmb.TabIndex = 19;
            // 
            // editLeadSpo_cmb
            // 
            this.editLeadSpo_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadSpo_cmb.FormattingEnabled = true;
            this.editLeadSpo_cmb.Location = new System.Drawing.Point(173, 244);
            this.editLeadSpo_cmb.Name = "editLeadSpo_cmb";
            this.editLeadSpo_cmb.Size = new System.Drawing.Size(171, 21);
            this.editLeadSpo_cmb.TabIndex = 20;
            // 
            // editLeadPro_cmb
            // 
            this.editLeadPro_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadPro_cmb.FormattingEnabled = true;
            this.editLeadPro_cmb.Location = new System.Drawing.Point(173, 148);
            this.editLeadPro_cmb.Name = "editLeadPro_cmb";
            this.editLeadPro_cmb.Size = new System.Drawing.Size(171, 21);
            this.editLeadPro_cmb.TabIndex = 21;
            // 
            // editLeadPhone_txt
            // 
            this.editLeadPhone_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editLeadPhone_txt.Location = new System.Drawing.Point(173, 196);
            this.editLeadPhone_txt.Mask = "00000000000";
            this.editLeadPhone_txt.Name = "editLeadPhone_txt";
            this.editLeadPhone_txt.Size = new System.Drawing.Size(171, 20);
            this.editLeadPhone_txt.TabIndex = 22;
            // 
            // DATE
            // 
            this.DATE.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.DATE.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.DATE.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DATE.Location = new System.Drawing.Point(3, 281);
            this.DATE.Name = "DATE";
            this.DATE.Size = new System.Drawing.Size(154, 25);
            this.DATE.TabIndex = 23;
            this.DATE.Text = "DATE";
            // 
            // editDate
            // 
            this.editDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.editDate.Location = new System.Drawing.Point(173, 283);
            this.editDate.Name = "editDate";
            this.editDate.Size = new System.Drawing.Size(171, 20);
            this.editDate.TabIndex = 24;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1097, 72);
            this.label1.TabIndex = 2;
            this.label1.Text = "EDIT LEADS";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminSubEditLeadFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(790, 535);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "adminSubEditLeadFrm";
            this.Text = "adminSubEditLeadFrm";
            this.Load += new System.EventHandler(this.AdminSubEditLeadFrm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox editLeadName_txt;
        private System.Windows.Forms.Button editLeadSave_cmd;
        private System.Windows.Forms.ComboBox editLeadSource_cmb;
        private System.Windows.Forms.ComboBox editLeadSpo_cmb;
        private System.Windows.Forms.ComboBox editLeadPro_cmb;
        private System.Windows.Forms.MaskedTextBox editLeadPhone_txt;
        private System.Windows.Forms.Label DATE;
        private System.Windows.Forms.DateTimePicker editDate;
    }
}