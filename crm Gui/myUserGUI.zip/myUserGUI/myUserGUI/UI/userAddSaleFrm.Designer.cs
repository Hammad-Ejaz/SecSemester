﻿namespace myUserGUI.UI
{
    partial class userAddSaleFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userAddSaleFrm));
            this.btn = new System.Windows.Forms.ToolStrip();
            this.homeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.leadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWTOTALLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.saleCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.userCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.saleHomeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saleLeadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.saleTodayLeadCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.saleTotalLeadCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.saleProjectCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.saleAddSaleCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.SaleViewAllCmd = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.SaleLogoutCmd = new System.Windows.Forms.ToolStripButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.userAddSale_GV = new System.Windows.Forms.DataGridView();
            this.dataGridViewButtonColumn1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userAddSale_GV)).BeginInit();
            this.SuspendLayout();
            // 
            // btn
            // 
            this.btn.AutoSize = false;
            this.btn.BackColor = System.Drawing.Color.Silver;
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeCmd,
            this.toolStripSeparator1,
            this.leadCmd,
            this.toolStripSeparator2,
            this.saleCmd,
            this.toolStripSeparator4,
            this.userCmd,
            this.toolStripSeparator5,
            this.toolStripButton1});
            this.btn.Location = new System.Drawing.Point(0, 185);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(198, 475);
            this.btn.Stretch = true;
            this.btn.TabIndex = 14;
            this.btn.Text = "SideBar";
            // 
            // homeCmd
            // 
            this.homeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.homeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.homeCmd.Image = ((System.Drawing.Image)(resources.GetObject("homeCmd.Image")));
            this.homeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.homeCmd.Name = "homeCmd";
            this.homeCmd.Size = new System.Drawing.Size(196, 23);
            this.homeCmd.Text = "HOME            ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(196, 6);
            // 
            // leadCmd
            // 
            this.leadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDLEADSToolStripMenuItem,
            this.vIEWTOTALLEADSToolStripMenuItem});
            this.leadCmd.Image = ((System.Drawing.Image)(resources.GetObject("leadCmd.Image")));
            this.leadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leadCmd.Name = "leadCmd";
            this.leadCmd.Size = new System.Drawing.Size(196, 23);
            this.leadCmd.Text = "LEADS             ";
            // 
            // aDDLEADSToolStripMenuItem
            // 
            this.aDDLEADSToolStripMenuItem.Name = "aDDLEADSToolStripMenuItem";
            this.aDDLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.aDDLEADSToolStripMenuItem.Text = "TODAY LEADS";
            // 
            // vIEWTOTALLEADSToolStripMenuItem
            // 
            this.vIEWTOTALLEADSToolStripMenuItem.Name = "vIEWTOTALLEADSToolStripMenuItem";
            this.vIEWTOTALLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.vIEWTOTALLEADSToolStripMenuItem.Text = "VIEW TOTAL LEADS";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(196, 6);
            // 
            // saleCmd
            // 
            this.saleCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleCmd.Image")));
            this.saleCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleCmd.Name = "saleCmd";
            this.saleCmd.Size = new System.Drawing.Size(196, 23);
            this.saleCmd.Text = "PROJETCS INFO";
            this.saleCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(196, 6);
            // 
            // userCmd
            // 
            this.userCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDUSERToolStripMenuItem,
            this.vIEWALLUSERToolStripMenuItem});
            this.userCmd.Image = ((System.Drawing.Image)(resources.GetObject("userCmd.Image")));
            this.userCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.userCmd.Name = "userCmd";
            this.userCmd.Size = new System.Drawing.Size(196, 23);
            this.userCmd.Text = "SALE               ";
            // 
            // aDDUSERToolStripMenuItem
            // 
            this.aDDUSERToolStripMenuItem.Name = "aDDUSERToolStripMenuItem";
            this.aDDUSERToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.aDDUSERToolStripMenuItem.Text = "ADD SALE";
            // 
            // vIEWALLUSERToolStripMenuItem
            // 
            this.vIEWALLUSERToolStripMenuItem.Name = "vIEWALLUSERToolStripMenuItem";
            this.vIEWALLUSERToolStripMenuItem.Size = new System.Drawing.Size(184, 24);
            this.vIEWALLUSERToolStripMenuItem.Text = "VIEW ALL SALES";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(196, 6);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(196, 23);
            this.toolStripButton1.Text = "LOG OUT          ";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::myUserGUI.Properties.Resources.Screenshot__22_2;
            this.pictureBox2.Location = new System.Drawing.Point(3, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(192, 177);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 18.75572F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 81.24429F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.54546F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1093, 660);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.toolStrip1, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.pictureBox3, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 3);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 27.87879F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 72.12122F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 8F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(198, 654);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // toolStrip1
            // 
            this.toolStrip1.AutoSize = false;
            this.toolStrip1.BackColor = System.Drawing.Color.Silver;
            this.toolStrip1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.toolStrip1.Dock = System.Windows.Forms.DockStyle.Left;
            this.toolStrip1.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleHomeCmd,
            this.toolStripSeparator3,
            this.saleLeadCmd,
            this.toolStripSeparator6,
            this.saleProjectCmd,
            this.toolStripSeparator7,
            this.toolStripDropDownButton2,
            this.toolStripSeparator8,
            this.SaleLogoutCmd});
            this.toolStrip1.Location = new System.Drawing.Point(0, 180);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(198, 465);
            this.toolStrip1.Stretch = true;
            this.toolStrip1.TabIndex = 15;
            this.toolStrip1.Text = "SideBar";
            // 
            // saleHomeCmd
            // 
            this.saleHomeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.saleHomeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.saleHomeCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleHomeCmd.Image")));
            this.saleHomeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleHomeCmd.Name = "saleHomeCmd";
            this.saleHomeCmd.Size = new System.Drawing.Size(196, 23);
            this.saleHomeCmd.Text = "HOME            ";
            this.saleHomeCmd.Click += new System.EventHandler(this.SaleHomeCmd_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(196, 6);
            // 
            // saleLeadCmd
            // 
            this.saleLeadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleTodayLeadCmd,
            this.saleTotalLeadCmd});
            this.saleLeadCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleLeadCmd.Image")));
            this.saleLeadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleLeadCmd.Name = "saleLeadCmd";
            this.saleLeadCmd.Size = new System.Drawing.Size(196, 23);
            this.saleLeadCmd.Text = "LEADS             ";
            // 
            // saleTodayLeadCmd
            // 
            this.saleTodayLeadCmd.Name = "saleTodayLeadCmd";
            this.saleTodayLeadCmd.Size = new System.Drawing.Size(206, 24);
            this.saleTodayLeadCmd.Text = "TODAY LEADS";
            this.saleTodayLeadCmd.Click += new System.EventHandler(this.SaleTodayLeadCmd_Click);
            // 
            // saleTotalLeadCmd
            // 
            this.saleTotalLeadCmd.Name = "saleTotalLeadCmd";
            this.saleTotalLeadCmd.Size = new System.Drawing.Size(206, 24);
            this.saleTotalLeadCmd.Text = "VIEW TOTAL LEADS";
            this.saleTotalLeadCmd.Click += new System.EventHandler(this.SaleTotalLeadCmd_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(196, 6);
            // 
            // saleProjectCmd
            // 
            this.saleProjectCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleProjectCmd.Image")));
            this.saleProjectCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleProjectCmd.Name = "saleProjectCmd";
            this.saleProjectCmd.Size = new System.Drawing.Size(196, 23);
            this.saleProjectCmd.Text = "PROJETCS INFO";
            this.saleProjectCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.saleProjectCmd.Click += new System.EventHandler(this.SaleProjectCmd_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(196, 6);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.saleAddSaleCmd,
            this.SaleViewAllCmd});
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(196, 23);
            this.toolStripDropDownButton2.Text = "SALE               ";
            // 
            // saleAddSaleCmd
            // 
            this.saleAddSaleCmd.Name = "saleAddSaleCmd";
            this.saleAddSaleCmd.Size = new System.Drawing.Size(184, 24);
            this.saleAddSaleCmd.Text = "ADD SALE";
            this.saleAddSaleCmd.Click += new System.EventHandler(this.SaleAddSaleCmd_Click);
            // 
            // SaleViewAllCmd
            // 
            this.SaleViewAllCmd.Name = "SaleViewAllCmd";
            this.SaleViewAllCmd.Size = new System.Drawing.Size(184, 24);
            this.SaleViewAllCmd.Text = "VIEW ALL SALES";
            this.SaleViewAllCmd.Click += new System.EventHandler(this.SaleViewAllCmd_Click);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(196, 6);
            // 
            // SaleLogoutCmd
            // 
            this.SaleLogoutCmd.Image = ((System.Drawing.Image)(resources.GetObject("SaleLogoutCmd.Image")));
            this.SaleLogoutCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.SaleLogoutCmd.Name = "SaleLogoutCmd";
            this.SaleLogoutCmd.Size = new System.Drawing.Size(196, 23);
            this.SaleLogoutCmd.Text = "LOG OUT          ";
            this.SaleLogoutCmd.Click += new System.EventHandler(this.SaleLogoutCmd_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = global::myUserGUI.Properties.Resources.Screenshot__22_3;
            this.pictureBox3.Location = new System.Drawing.Point(3, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(192, 174);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 17;
            this.pictureBox3.TabStop = false;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel3.Controls.Add(this.userAddSale_GV, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(207, 3);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 2;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 11.6208F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 88.3792F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(883, 654);
            this.tableLayoutPanel3.TabIndex = 3;
            // 
            // userAddSale_GV
            // 
            this.userAddSale_GV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userAddSale_GV.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewButtonColumn1});
            this.userAddSale_GV.Dock = System.Windows.Forms.DockStyle.Fill;
            this.userAddSale_GV.Location = new System.Drawing.Point(3, 79);
            this.userAddSale_GV.Name = "userAddSale_GV";
            this.userAddSale_GV.ReadOnly = true;
            this.userAddSale_GV.Size = new System.Drawing.Size(877, 572);
            this.userAddSale_GV.TabIndex = 9;
            this.userAddSale_GV.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.UserAddSale_GV_CellContentClick);
            // 
            // dataGridViewButtonColumn1
            // 
            this.dataGridViewButtonColumn1.HeaderText = "ADD SALE";
            this.dataGridViewButtonColumn1.Name = "dataGridViewButtonColumn1";
            this.dataGridViewButtonColumn1.ReadOnly = true;
            this.dataGridViewButtonColumn1.Text = "ADD SALE";
            this.dataGridViewButtonColumn1.ToolTipText = "ADD SALE";
            this.dataGridViewButtonColumn1.UseColumnTextForButtonValue = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(877, 76);
            this.label1.TabIndex = 8;
            this.label1.Text = "ADD SALE";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // userAddSaleFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel1);
            this.MinimumSize = new System.Drawing.Size(1109, 699);
            this.Name = "userAddSaleFrm";
            this.Text = "userAddSaleFrm";
            this.Load += new System.EventHandler(this.UserAddSaleFrm_Load);
            this.btn.ResumeLayout(false);
            this.btn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userAddSale_GV)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStrip btn;
        private System.Windows.Forms.ToolStripButton homeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton leadCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWTOTALLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton saleCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton userCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton saleHomeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton saleLeadCmd;
        private System.Windows.Forms.ToolStripMenuItem saleTodayLeadCmd;
        private System.Windows.Forms.ToolStripMenuItem saleTotalLeadCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton saleProjectCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem saleAddSaleCmd;
        private System.Windows.Forms.ToolStripMenuItem SaleViewAllCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripButton SaleLogoutCmd;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView userAddSale_GV;
        private System.Windows.Forms.DataGridViewButtonColumn dataGridViewButtonColumn1;
    }
}