﻿namespace myUserGUI.UI
{
    partial class adminSubEditProjectFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.SubaddProSave_Cmd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.citylbl = new System.Windows.Forms.Label();
            this.SubAddProCity_txt = new System.Windows.Forms.TextBox();
            this.subAddProName_txt = new System.Windows.Forms.TextBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.subEditPro_cmb = new System.Windows.Forms.ComboBox();
            this.adminSubEditPlots_txt = new System.Windows.Forms.MaskedTextBox();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AccessibleDescription = "CC";
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.77998F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.22002F));
            this.tableLayoutPanel4.Controls.Add(this.SubaddProSave_Cmd, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 5);
            this.tableLayoutPanel4.Controls.Add(this.label2, 1, 5);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.citylbl, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.SubAddProCity_txt, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.subAddProName_txt, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.nameLbl, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.subEditPro_cmb, 0, 6);
            this.tableLayoutPanel4.Controls.Add(this.adminSubEditPlots_txt, 1, 6);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel4.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 8;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.73427F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.26574F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 331F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // SubaddProSave_Cmd
            // 
            this.SubaddProSave_Cmd.AccessibleDescription = "CC";
            this.SubaddProSave_Cmd.Location = new System.Drawing.Point(177, 370);
            this.SubaddProSave_Cmd.Name = "SubaddProSave_Cmd";
            this.SubaddProSave_Cmd.Size = new System.Drawing.Size(171, 23);
            this.SubaddProSave_Cmd.TabIndex = 18;
            this.SubaddProSave_Cmd.Text = "SAVE";
            this.SubaddProSave_Cmd.UseVisualStyleBackColor = true;
            this.SubaddProSave_Cmd.Click += new System.EventHandler(this.SubaddProSave_Cmd_Click);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 81);
            this.label1.TabIndex = 24;
            this.label1.Text = "EDIT PROJECT";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // label6
            // 
            this.label6.AccessibleDescription = "CC";
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 284);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 32);
            this.label6.TabIndex = 4;
            this.label6.Text = "MARLA";
            // 
            // label2
            // 
            this.label2.AccessibleDescription = "CC";
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(177, 284);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 32);
            this.label2.TabIndex = 21;
            this.label2.Text = "PLOTS";
            // 
            // label4
            // 
            this.label4.AccessibleDescription = "CC";
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 238);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 30);
            this.label4.TabIndex = 2;
            this.label4.Text = "AREA";
            // 
            // citylbl
            // 
            this.citylbl.AccessibleDescription = "CC";
            this.citylbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.citylbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.citylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.citylbl.Location = new System.Drawing.Point(3, 187);
            this.citylbl.Name = "citylbl";
            this.citylbl.Size = new System.Drawing.Size(164, 32);
            this.citylbl.TabIndex = 19;
            this.citylbl.Text = "CITY";
            // 
            // SubAddProCity_txt
            // 
            this.SubAddProCity_txt.AccessibleDescription = "CC";
            this.SubAddProCity_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.SubAddProCity_txt.Location = new System.Drawing.Point(177, 187);
            this.SubAddProCity_txt.Multiline = true;
            this.SubAddProCity_txt.Name = "SubAddProCity_txt";
            this.SubAddProCity_txt.Size = new System.Drawing.Size(171, 29);
            this.SubAddProCity_txt.TabIndex = 11;
            // 
            // subAddProName_txt
            // 
            this.subAddProName_txt.AccessibleDescription = "CC";
            this.subAddProName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.subAddProName_txt.Location = new System.Drawing.Point(177, 140);
            this.subAddProName_txt.Multiline = true;
            this.subAddProName_txt.Name = "subAddProName_txt";
            this.subAddProName_txt.Size = new System.Drawing.Size(171, 29);
            this.subAddProName_txt.TabIndex = 20;
            // 
            // nameLbl
            // 
            this.nameLbl.AccessibleDescription = "CC";
            this.nameLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nameLbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(3, 140);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(164, 32);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "NAME";
            // 
            // subEditPro_cmb
            // 
            this.subEditPro_cmb.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.subEditPro_cmb.FormattingEnabled = true;
            this.subEditPro_cmb.Location = new System.Drawing.Point(3, 343);
            this.subEditPro_cmb.Name = "subEditPro_cmb";
            this.subEditPro_cmb.Size = new System.Drawing.Size(168, 21);
            this.subEditPro_cmb.TabIndex = 25;
            // 
            // adminSubEditPlots_txt
            // 
            this.adminSubEditPlots_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.adminSubEditPlots_txt.Location = new System.Drawing.Point(177, 344);
            this.adminSubEditPlots_txt.Mask = "00000";
            this.adminSubEditPlots_txt.Name = "adminSubEditPlots_txt";
            this.adminSubEditPlots_txt.Size = new System.Drawing.Size(164, 20);
            this.adminSubEditPlots_txt.TabIndex = 26;
            this.adminSubEditPlots_txt.ValidatingType = typeof(int);
            // 
            // adminSubEditProjectFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 495);
            this.Controls.Add(this.tableLayoutPanel4);
            this.Name = "adminSubEditProjectFrm";
            this.Text = "adminSubEditProjectFrm";
            this.Load += new System.EventHandler(this.AdminSubEditProjectFrm_Load);
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label citylbl;
        private System.Windows.Forms.TextBox SubAddProCity_txt;
        private System.Windows.Forms.TextBox subAddProName_txt;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Button SubaddProSave_Cmd;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox subEditPro_cmb;
        private System.Windows.Forms.MaskedTextBox adminSubEditPlots_txt;
    }
}