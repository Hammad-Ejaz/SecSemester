﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.UI;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI
{
    public partial class adminSaleFrm : adminModel
    {
        public adminSaleFrm()
        {
            InitializeComponent();
        }

        private void AdminSaleFrm_Load(object sender, EventArgs e)
        {
            adminSale_GV.DataSource = SaleDL.getTotalSalesList();
        }
    }
}
