﻿namespace myUserGUI
{
    partial class adminAddProjectFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(adminAddProjectFrm));
            this.btn = new System.Windows.Forms.ToolStrip();
            this.homeCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.leadCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETELEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWTOTALLEADSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripDropDownButton2 = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDPROJECTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLPROJECTSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEPROJECTToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.saleCmd = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.userCmd = new System.Windows.Forms.ToolStripDropDownButton();
            this.aDDUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vIEWALLUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dELETEUSERToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.nameLbl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.citylbl = new System.Windows.Forms.Label();
            this.addProCity_txt = new System.Windows.Forms.TextBox();
            this.addProName_txt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.addProMarla_txt = new System.Windows.Forms.MaskedTextBox();
            this.addProPlots_txt = new System.Windows.Forms.MaskedTextBox();
            this.kannalTxt = new System.Windows.Forms.TextBox();
            this.addProSave_Cmd = new System.Windows.Forms.Button();
            this.addProAddMore_cmd = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.btn.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn
            // 
            this.btn.AccessibleDescription = "CC";
            this.btn.AutoSize = false;
            this.btn.BackColor = System.Drawing.Color.Silver;
            this.btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn.Dock = System.Windows.Forms.DockStyle.Left;
            this.btn.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.btn.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeCmd,
            this.toolStripSeparator1,
            this.leadCmd,
            this.toolStripSeparator2,
            this.toolStripDropDownButton2,
            this.toolStripSeparator3,
            this.saleCmd,
            this.toolStripSeparator4,
            this.userCmd,
            this.toolStripSeparator5,
            this.toolStripButton1});
            this.btn.Location = new System.Drawing.Point(0, 150);
            this.btn.Name = "btn";
            this.btn.Size = new System.Drawing.Size(170, 543);
            this.btn.Stretch = true;
            this.btn.TabIndex = 13;
            this.btn.Text = "SideBar";
            // 
            // homeCmd
            // 
            this.homeCmd.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.homeCmd.ForeColor = System.Drawing.SystemColors.Window;
            this.homeCmd.Image = ((System.Drawing.Image)(resources.GetObject("homeCmd.Image")));
            this.homeCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.homeCmd.Name = "homeCmd";
            this.homeCmd.Size = new System.Drawing.Size(168, 23);
            this.homeCmd.Text = "HOME      ";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.AccessibleDescription = "CC";
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(168, 6);
            // 
            // leadCmd
            // 
            this.leadCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDLEADSToolStripMenuItem,
            this.dELETELEADSToolStripMenuItem,
            this.vIEWTOTALLEADSToolStripMenuItem});
            this.leadCmd.Image = ((System.Drawing.Image)(resources.GetObject("leadCmd.Image")));
            this.leadCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.leadCmd.Name = "leadCmd";
            this.leadCmd.Size = new System.Drawing.Size(168, 23);
            this.leadCmd.Text = "LEADS     ";
            // 
            // aDDLEADSToolStripMenuItem
            // 
            this.aDDLEADSToolStripMenuItem.Name = "aDDLEADSToolStripMenuItem";
            this.aDDLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.aDDLEADSToolStripMenuItem.Text = "ADD LEADS";
            // 
            // dELETELEADSToolStripMenuItem
            // 
            this.dELETELEADSToolStripMenuItem.Name = "dELETELEADSToolStripMenuItem";
            this.dELETELEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.dELETELEADSToolStripMenuItem.Text = "EDIT LEADS";
            // 
            // vIEWTOTALLEADSToolStripMenuItem
            // 
            this.vIEWTOTALLEADSToolStripMenuItem.Name = "vIEWTOTALLEADSToolStripMenuItem";
            this.vIEWTOTALLEADSToolStripMenuItem.Size = new System.Drawing.Size(206, 24);
            this.vIEWTOTALLEADSToolStripMenuItem.Text = "VIEW TOTAL LEADS";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.AccessibleDescription = "CC";
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(168, 6);
            // 
            // toolStripDropDownButton2
            // 
            this.toolStripDropDownButton2.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDPROJECTToolStripMenuItem,
            this.vIEWALLPROJECTSToolStripMenuItem,
            this.dELETEPROJECTToolStripMenuItem});
            this.toolStripDropDownButton2.Font = new System.Drawing.Font("Ebrima", 10F, System.Drawing.FontStyle.Bold);
            this.toolStripDropDownButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripDropDownButton2.Image")));
            this.toolStripDropDownButton2.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripDropDownButton2.Name = "toolStripDropDownButton2";
            this.toolStripDropDownButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripDropDownButton2.Size = new System.Drawing.Size(168, 23);
            this.toolStripDropDownButton2.Text = "PROJECT";
            this.toolStripDropDownButton2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // aDDPROJECTToolStripMenuItem
            // 
            this.aDDPROJECTToolStripMenuItem.Name = "aDDPROJECTToolStripMenuItem";
            this.aDDPROJECTToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.aDDPROJECTToolStripMenuItem.Text = "ADD PROJECT";
            // 
            // vIEWALLPROJECTSToolStripMenuItem
            // 
            this.vIEWALLPROJECTSToolStripMenuItem.Name = "vIEWALLPROJECTSToolStripMenuItem";
            this.vIEWALLPROJECTSToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.vIEWALLPROJECTSToolStripMenuItem.Text = "VIEW ALL PROJECTS";
            // 
            // dELETEPROJECTToolStripMenuItem
            // 
            this.dELETEPROJECTToolStripMenuItem.Name = "dELETEPROJECTToolStripMenuItem";
            this.dELETEPROJECTToolStripMenuItem.Size = new System.Drawing.Size(211, 24);
            this.dELETEPROJECTToolStripMenuItem.Text = "EDIT PROJECT";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.AccessibleDescription = "CC";
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(168, 6);
            // 
            // saleCmd
            // 
            this.saleCmd.Image = ((System.Drawing.Image)(resources.GetObject("saleCmd.Image")));
            this.saleCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saleCmd.Name = "saleCmd";
            this.saleCmd.Size = new System.Drawing.Size(168, 23);
            this.saleCmd.Text = "SALES        ";
            this.saleCmd.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.AccessibleDescription = "CC";
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(168, 6);
            // 
            // userCmd
            // 
            this.userCmd.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDDUSERToolStripMenuItem,
            this.vIEWALLUSERToolStripMenuItem,
            this.dELETEUSERToolStripMenuItem});
            this.userCmd.Image = ((System.Drawing.Image)(resources.GetObject("userCmd.Image")));
            this.userCmd.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.userCmd.Name = "userCmd";
            this.userCmd.Size = new System.Drawing.Size(168, 23);
            this.userCmd.Text = "USERS     ";
            // 
            // aDDUSERToolStripMenuItem
            // 
            this.aDDUSERToolStripMenuItem.Name = "aDDUSERToolStripMenuItem";
            this.aDDUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.aDDUSERToolStripMenuItem.Text = "ADD USER";
            // 
            // vIEWALLUSERToolStripMenuItem
            // 
            this.vIEWALLUSERToolStripMenuItem.Name = "vIEWALLUSERToolStripMenuItem";
            this.vIEWALLUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.vIEWALLUSERToolStripMenuItem.Text = "VIEW ALL USER";
            // 
            // dELETEUSERToolStripMenuItem
            // 
            this.dELETEUSERToolStripMenuItem.Name = "dELETEUSERToolStripMenuItem";
            this.dELETEUSERToolStripMenuItem.Size = new System.Drawing.Size(178, 24);
            this.dELETEUSERToolStripMenuItem.Text = "DELETE USER";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.AccessibleDescription = "CC";
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(168, 6);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(168, 23);
            this.toolStripButton1.Text = "LOG OUT";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::myUserGUI.Properties.Resources.Screenshot__22_2;
            this.pictureBox2.Location = new System.Drawing.Point(3, 4);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(164, 142);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 12;
            this.pictureBox2.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel4, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Right;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(193, 0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 12.72727F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 87.27273F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(900, 660);
            this.tableLayoutPanel2.TabIndex = 1;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.AccessibleDescription = "CC";
            this.tableLayoutPanel4.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15.32913F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 84.67088F));
            this.tableLayoutPanel4.Controls.Add(this.nameLbl, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.label6, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label4, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.citylbl, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.addProCity_txt, 1, 1);
            this.tableLayoutPanel4.Controls.Add(this.addProName_txt, 1, 0);
            this.tableLayoutPanel4.Controls.Add(this.label2, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.addProMarla_txt, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.addProPlots_txt, 1, 4);
            this.tableLayoutPanel4.Controls.Add(this.kannalTxt, 1, 7);
            this.tableLayoutPanel4.Controls.Add(this.addProSave_Cmd, 1, 6);
            this.tableLayoutPanel4.Controls.Add(this.addProAddMore_cmd, 0, 6);
            this.tableLayoutPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel4.Location = new System.Drawing.Point(3, 86);
            this.tableLayoutPanel4.MinimumSize = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 8;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 65.73427F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 34.26574F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 49F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 51F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 331F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(1109, 699);
            this.tableLayoutPanel4.TabIndex = 3;
            // 
            // nameLbl
            // 
            this.nameLbl.AccessibleDescription = "CC";
            this.nameLbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.nameLbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.nameLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLbl.Location = new System.Drawing.Point(3, 49);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(164, 32);
            this.nameLbl.TabIndex = 0;
            this.nameLbl.Text = "NAME";
            // 
            // label6
            // 
            this.label6.AccessibleDescription = "CC";
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label6.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(3, 187);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(164, 32);
            this.label6.TabIndex = 4;
            this.label6.Text = "MARLA";
            // 
            // label4
            // 
            this.label4.AccessibleDescription = "CC";
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label4.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 30);
            this.label4.TabIndex = 2;
            this.label4.Text = "AREA";
            // 
            // citylbl
            // 
            this.citylbl.AccessibleDescription = "CC";
            this.citylbl.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.citylbl.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.citylbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.citylbl.Location = new System.Drawing.Point(3, 91);
            this.citylbl.Name = "citylbl";
            this.citylbl.Size = new System.Drawing.Size(164, 32);
            this.citylbl.TabIndex = 19;
            this.citylbl.Text = "CITY";
            // 
            // addProCity_txt
            // 
            this.addProCity_txt.AccessibleDescription = "CC";
            this.addProCity_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addProCity_txt.Location = new System.Drawing.Point(173, 91);
            this.addProCity_txt.Multiline = true;
            this.addProCity_txt.Name = "addProCity_txt";
            this.addProCity_txt.Size = new System.Drawing.Size(171, 29);
            this.addProCity_txt.TabIndex = 11;
            // 
            // addProName_txt
            // 
            this.addProName_txt.AccessibleDescription = "CC";
            this.addProName_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addProName_txt.Location = new System.Drawing.Point(173, 49);
            this.addProName_txt.Multiline = true;
            this.addProName_txt.Name = "addProName_txt";
            this.addProName_txt.Size = new System.Drawing.Size(171, 29);
            this.addProName_txt.TabIndex = 20;
            // 
            // label2
            // 
            this.label2.AccessibleDescription = "CC";
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.label2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(173, 187);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 32);
            this.label2.TabIndex = 21;
            this.label2.Text = "PLOTS";
            // 
            // addProMarla_txt
            // 
            this.addProMarla_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addProMarla_txt.Location = new System.Drawing.Point(3, 245);
            this.addProMarla_txt.Mask = "00000000000000000000000000";
            this.addProMarla_txt.Name = "addProMarla_txt";
            this.addProMarla_txt.Size = new System.Drawing.Size(164, 20);
            this.addProMarla_txt.TabIndex = 22;
            this.addProMarla_txt.ValidatingType = typeof(int);
            // 
            // addProPlots_txt
            // 
            this.addProPlots_txt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.addProPlots_txt.Location = new System.Drawing.Point(173, 245);
            this.addProPlots_txt.Mask = "000000000000000000000000000";
            this.addProPlots_txt.Name = "addProPlots_txt";
            this.addProPlots_txt.Size = new System.Drawing.Size(164, 20);
            this.addProPlots_txt.TabIndex = 23;
            this.addProPlots_txt.ValidatingType = typeof(int);
            // 
            // kannalTxt
            // 
            this.kannalTxt.AccessibleDescription = "CC";
            this.kannalTxt.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.kannalTxt.Location = new System.Drawing.Point(173, 667);
            this.kannalTxt.Multiline = true;
            this.kannalTxt.Name = "kannalTxt";
            this.kannalTxt.Size = new System.Drawing.Size(171, 29);
            this.kannalTxt.TabIndex = 17;
            // 
            // addProSave_Cmd
            // 
            this.addProSave_Cmd.AccessibleDescription = "CC";
            this.addProSave_Cmd.Location = new System.Drawing.Point(173, 319);
            this.addProSave_Cmd.Name = "addProSave_Cmd";
            this.addProSave_Cmd.Size = new System.Drawing.Size(171, 23);
            this.addProSave_Cmd.TabIndex = 18;
            this.addProSave_Cmd.Text = "SAVE";
            this.addProSave_Cmd.UseVisualStyleBackColor = true;
            this.addProSave_Cmd.Click += new System.EventHandler(this.AddProSave_Cmd_Click);
            // 
            // addProAddMore_cmd
            // 
            this.addProAddMore_cmd.AccessibleDescription = "CC";
            this.addProAddMore_cmd.Location = new System.Drawing.Point(3, 319);
            this.addProAddMore_cmd.Name = "addProAddMore_cmd";
            this.addProAddMore_cmd.Size = new System.Drawing.Size(164, 23);
            this.addProAddMore_cmd.TabIndex = 24;
            this.addProAddMore_cmd.Text = "ADD MORE";
            this.addProAddMore_cmd.UseVisualStyleBackColor = true;
            this.addProAddMore_cmd.Click += new System.EventHandler(this.AddProAddMore_cmd_Click);
            // 
            // label1
            // 
            this.label1.AccessibleDescription = "CC";
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(894, 83);
            this.label1.TabIndex = 2;
            this.label1.Text = "PROJECT";
            this.label1.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // adminAddProjectFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1093, 660);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Name = "adminAddProjectFrm";
            this.Text = "Form4";
            this.Controls.SetChildIndex(this.tableLayoutPanel2, 0);
            this.btn.ResumeLayout(false);
            this.btn.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.ToolStripButton homeCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton leadCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETELEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWTOTALLEADSToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripDropDownButton toolStripDropDownButton2;
        private System.Windows.Forms.ToolStripMenuItem aDDPROJECTToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLPROJECTSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEPROJECTToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton saleCmd;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripDropDownButton userCmd;
        private System.Windows.Forms.ToolStripMenuItem aDDUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vIEWALLUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dELETEUSERToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.ToolStrip btn;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label citylbl;
        private System.Windows.Forms.TextBox addProCity_txt;
        private System.Windows.Forms.TextBox addProName_txt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.MaskedTextBox addProMarla_txt;
        private System.Windows.Forms.MaskedTextBox addProPlots_txt;
        private System.Windows.Forms.TextBox kannalTxt;
        private System.Windows.Forms.Button addProSave_Cmd;
        private System.Windows.Forms.Button addProAddMore_cmd;
    }
}