﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI.UI
{
    public partial class adminAddLeadFrm : adminModel
    {
        public adminAddLeadFrm()
        {
            InitializeComponent();
        }
        private void AdminAddLeadFrm_Load(object sender, EventArgs e)
        {

            // addLead assigned to combo box
            addLeadSpoName_cmb.DataSource = MuserDL.myEmployes();
            addLeadSpoName_cmb.DisplayMember = "name";
            //addLead project combo box
            addLeadProject_cmb.DataSource = ProjectDL.AllProjects;
            addLeadProject_cmb.DisplayMember = "name";
        }

        private void Save_cmd_Click(object sender, EventArgs e)
        {
            string name = adminAddLeadName_txt.Text;
            string spoName = addLeadSpoName_cmb.Text;
            string phone = addLeadPhoneNo_txt.Text;
            string source = adminAddLeadSource_cmb.Text;
            string project = addLeadProject_cmb.Text;
            if (phone.Length != 11 || name == null || spoName == null || source == null || project == null) MessageBox.Show("invalid");
            else
            {
                InfoClientsBL Lead = new InfoClientsBL(spoName, name, phone, project, source);
                InfoLeadDL.addLeadToList(Lead);
                InfoLeadDL.saveData("Lead.txt");
                adminAddLeadName_txt.Text = "";
                addLeadPhoneNo_txt.Text = "";
                MessageBox.Show("lead Added Successfuly");
            }
        }
    }
}
