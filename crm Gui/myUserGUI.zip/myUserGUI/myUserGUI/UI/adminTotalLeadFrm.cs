﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class adminTotalLeadFrm : adminModel
    {
        public adminTotalLeadFrm()
        {
            InitializeComponent();
        }
        private void AdminTotalLeadFrm_Load(object sender, EventArgs e)
        {
            adminViewALlLead_GV.DataSource = InfoLeadDL.InfoClientsList;
            adminViewALlLead_GV.Columns["date"].Visible = false;
            adminViewALlLead_GV.Columns["response"].Visible = false;
            adminViewALlLead_GV.Columns["schedule"].Visible = false;
        }
    }
}
