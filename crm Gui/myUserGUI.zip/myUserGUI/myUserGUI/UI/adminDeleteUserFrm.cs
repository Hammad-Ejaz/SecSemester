﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.UI;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI
{
    public partial class adminDeleteUserFrm : adminModel
    {
        public adminDeleteUserFrm()
        {
            InitializeComponent();
        }

        private void AdminDeleteUserFrm_Load(object sender, EventArgs e)
        {
            editUser_GV.DataSource = MuserDL.MyUsers;
        }
        private void DataBind()
        {
            editUser_GV.DataSource = null;
            editUser_GV.DataSource = MuserDL.MyUsers;
            editUser_GV.Refresh();
        }

        private void EditUser_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MuserBL user = (MuserBL)editUser_GV.CurrentRow.DataBoundItem;
            if (editUser_GV.Columns["EDIT"].Index == e.ColumnIndex)
            {
                adminSubEditUserFrm edit = new adminSubEditUserFrm(user);
                edit.ShowDialog();
                MuserDL.saveUserData("Store.txt");
                DataBind();
            }
            else if (editUser_GV.Columns[0].Index == e.ColumnIndex)
            {
                MuserDL.delUser(user);
                MuserDL.saveUserData("Store.txt");
                DataBind();
            }
        }
    }
}
