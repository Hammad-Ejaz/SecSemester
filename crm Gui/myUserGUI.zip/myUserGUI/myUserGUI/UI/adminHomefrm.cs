﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
namespace myUserGUI.UI
{
    public partial class adminHomefrm : adminModel
    {
       
        public adminHomefrm()
        {
            InitializeComponent();
        }
        private void setTotalBoard()
        {
            List<InfoClientsBL> Lead = InfoLeadDL.InfoClientsList;
            // admin total board
            adminHomeTotalLead_lbl.Text = $"TOTAL LEADS   :  {Lead.Count}";
            adminHomeFollowUp_lbl.Text = $"TOTAL FOLLOW UPS   :  {InfoLeadDL.getClientNoBySchedule("FOLLOW UPS", Lead)}";
            adminHomeMeeting_lbl.Text = $"TOTAL MEETINGS   :  {InfoLeadDL.getClientNoBySchedule("MEETING", Lead)}";
            adminHomeVisit_lbl.Text = $"TOTAL VISITS   :  {InfoLeadDL.getClientNoBySchedule("VISITS", Lead)}";
            adminHomeHot_lbl.Text = $"TOTAL HOT CLIENTS   :  {InfoLeadDL.getClientNoBySchedule("HOT CLIENT", Lead)}";
        }
        private void setTodayBoard()
        {
            List<InfoClientsBL> Lead = InfoLeadDL.TodayTotalLeads();
            // admin done board
            adminDoneLead_lbl.Text = $"LEADS   :  {Lead.Count}";
            adminDoneFollow_lbl.Text = $"FOLLOW UP :  {InfoLeadDL.getClientNoBySchedule("FOLLOW UPS", Lead)}";
            adminDoneHot_lbl.Text = $"TOTAL HOT CLIENTS   :  {InfoLeadDL.getClientNoBySchedule("HOT CLIENT", Lead)}";
            adminDoneMeeting_lbl.Text = $"TOTAL MEETINGS   :  {InfoLeadDL.getClientNoBySchedule("MEETING", Lead)}"; 
            adminDoneVisit_lbl.Text = $"TOTAL VISITS   :  {InfoLeadDL.getClientNoBySchedule("VISITS", Lead)}";

        }
        private void AdminHomefrm_Load(object sender, EventArgs e)
        {
            setTotalBoard();
            setTodayBoard();
        }
    }
}
