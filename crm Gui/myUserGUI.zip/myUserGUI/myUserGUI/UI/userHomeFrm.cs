﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class UserMainHomeFrm : Form
    {
        MuserBL currentUser;
        public UserMainHomeFrm(MuserBL currentUser) 
        {
            InitializeComponent();
            this.currentUser = currentUser;
        }

        private void setTodayUserBoard()
        {
            List<InfoClientsBL> Lead = InfoLeadDL.getTodayLeadsOfSpecificSpo(currentUser.Name); // gives Me the todayLead of user
            userHomeTlead_lbl.Text = $"TODAY LEADS   :  {Lead.Count}"; 
            userHomeTFollowUp_lbl.Text = $"TODAY FOLLOW UPS   :  {InfoLeadDL.getClientNoBySchedule("FOLLOW UPS", Lead)}"; ;
            userHomeTMeeting_lbl.Text = $"TODAY MEETINGS   :  {InfoLeadDL.getClientNoBySchedule("MEETING", Lead)}"; ;
            userHomeTvisits_lbl.Text = $"TODAY VISITS   :  {InfoLeadDL.getClientNoBySchedule("VISITS", Lead)}"; ;
            userHomeTHot_lbl.Text = $"TODAY HOT CLIENTS   :  {InfoLeadDL.getClientNoBySchedule("HOT CLIENT", Lead)}";   
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            setTodayUserBoard();
        }
        private void HomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMainHomeFrm home = new UserMainHomeFrm(currentUser);
            home.Show();
        }

        private void ADDLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTodayLeadsFrm todayLead = new userTodayLeadsFrm(currentUser);
            todayLead.Show();
        }

        private void VIEWTOTALLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTotalLeadsFrm totalLead = new userTotalLeadsFrm(currentUser);
            totalLead.Show();
        }

        private void SaleCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            userProjectInfoFrm Project = new userProjectInfoFrm(currentUser);
            Project.Show();
        }

        private void ADDUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userAddSaleFrm sale = new userAddSaleFrm(currentUser);
            sale.Show();
        }

        private void VIEWALLUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userViewTotalSale totalSale = new userViewTotalSale(currentUser);
            totalSale.Show();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login = new mainLoginFrm();
            login.Show();
        }

        private void UserMainHomeFrm_Load(object sender, EventArgs e)
        {
            setTodayUserBoard();
        }
    }
}
