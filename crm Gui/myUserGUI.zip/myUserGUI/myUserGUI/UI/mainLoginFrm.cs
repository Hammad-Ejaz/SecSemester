﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.DL;
using myUserGUI.BL;
using myUserGUI.UI;
namespace myUserGUI
{
    public partial class mainLoginFrm : Form
    {
        
        public mainLoginFrm()
        {
            InitializeComponent();
                MuserDL.loadUserData("Store.txt");
                ProjectDL.readData("Project.txt");
                InfoLeadDL.loadData("Lead.txt");
                SaleDL.readData("Sale.txt");
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            MuserBL user;
            try
            {
                if ((user = MuserDL.isValidUser(loginEmail_txt.Text, loginPwd_txt.Text)) != null)
                {
                    if (user.isAdmin())
                    {
                        this.Hide();
                        adminHomefrm home = new adminHomefrm();
                        home.Show();
                    }
                    else
                    {
                        this.Hide();
                        UserMainHomeFrm home = new UserMainHomeFrm(user);
                        home.Show();
                    }
                }
                else MessageBox.Show("Invalid Data");
            }
            catch (Exception exp) { MessageBox.Show(exp.ToString()); }
        }
    }
}
