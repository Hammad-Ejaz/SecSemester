﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using myUserGUI.BL;
using myUserGUI.DL;
namespace myUserGUI.UI
{
    public partial class userProjectInfoFrm : Form
    {
        MuserBL currentUser;
        public userProjectInfoFrm(MuserBL currentUser)
        {
            InitializeComponent();
            this.currentUser = currentUser;
        }

        private void UserProjectInfoFrm_Load(object sender, EventArgs e)
        {
             userViewAllPloPI_GV.DataSource = ProjectDL.AllProjects;
        }

        private void UserViewAllPloPI_GV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            ProjectBL project = (ProjectBL)userViewAllPloPI_GV.CurrentRow.DataBoundItem;
            if (userViewAllPloPI_GV.Columns[0].Index == e.ColumnIndex)
            {
                userViewAllPloAI_GV.DataSource = project.Area;
            }
        }

        private void HomeCmd_Click(object sender, EventArgs e)
        {
            this.Hide();
            UserMainHomeFrm home = new UserMainHomeFrm(currentUser);
            home.Show();
        }

        private void ADDLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTodayLeadsFrm todayLead = new userTodayLeadsFrm(currentUser);
            todayLead.Show();
        }

        private void VIEWTOTALLEADSToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userTotalLeadsFrm totalLead = new userTotalLeadsFrm(currentUser);
            totalLead.Show();
        }

        private void ADDUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userAddSaleFrm sale = new userAddSaleFrm(currentUser);
            sale.Show();
        }

        private void VIEWALLUSERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Hide();
            userViewTotalSale totalSale = new userViewTotalSale(currentUser);
            totalSale.Show();
        }

        private void ToolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            mainLoginFrm login= new mainLoginFrm();
            login.Show();
        }
    }
}
