﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
namespace marioFrameWork.collisions
{
    public class BonusCollision : IAction
    {
        public void performAction(Game game, GameObjects source1, GameObjects source2)
        {
            GameObjects bonus;
            if (source1.Type == MyEnumTypes.bonus)
            {
                bonus = source1;
            }
            else
            {
                bonus = source2;
            }
            game.riseEnemyHealthDec(bonus);
        }
    }
}
