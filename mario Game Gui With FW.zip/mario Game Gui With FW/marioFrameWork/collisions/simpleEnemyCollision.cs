﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
namespace marioFrameWork.collisions
{
    public class simpleEnemyCollision : IAction
    {
        public void performAction(Game game, GameObjects source1, GameObjects source2)
        {
            GameObjects Enemy;
            if (source1.Type == MyEnumTypes.simpleEnemy)
            {
                Enemy = source1;
            }
            else
            {
                Enemy = source2;
            }

            Enemy.IsExists = false;
        }
    }
}
