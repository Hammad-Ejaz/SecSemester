﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
namespace marioFrameWork.collisions
{
    public interface IAction
    {
        void performAction(Game game, GameObjects source1, GameObjects source2);
    }
}
