﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace marioFrameWork.collisions
{
    public enum MyEnumTypes
    {
        player,
        simpleEnemy,
        fireEnemy,
        bullet,
        bonus,
        obstacle
    }
}
