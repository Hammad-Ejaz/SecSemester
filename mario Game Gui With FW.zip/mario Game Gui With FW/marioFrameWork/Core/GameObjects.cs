﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
using marioFrameWork.Movements;
using marioFrameWork.collisions;
namespace marioFrameWork.Core
{
    public class GameObjects
    {
        private PictureBox pb;
        private Imovement movement;
        private MyEnumTypes type;
        private bool isExists;
        public GameObjects(Image image , int top , int left , Imovement movement , MyEnumTypes type)
        {
            pb = new PictureBox();
            pb.Image = image;
            pb.Width = image.Width;
            pb.Height = image.Height;
            pb.BackColor = Color.Transparent;
            pb.Top = top;
            pb.Left = left;
            this.movement = movement;
            this.Type = type;
            IsExists = true;
        }
        public PictureBox Pb { get => pb; set => pb = value; }
        public Imovement Movement { get => movement; set => movement = value; }
        public MyEnumTypes Type { get => type; set => type = value; }
        public bool IsExists { get => isExists; set => isExists = value; }
        public void move()
        {
           
            Pb.Location = Movement.move(pb.Location);
        }

    }
}
