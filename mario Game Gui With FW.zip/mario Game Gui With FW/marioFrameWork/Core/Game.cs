﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using marioFrameWork.collisions;
using marioFrameWork.Core;
using System.Windows.Forms;
using marioFrameWork.Movements;
namespace marioFrameWork.Core
{
    public class Game : IGame
    {
        private List<GameObjects> gameObjectsList = new List<GameObjects>();
        private List<Collision> collisions = new List<Collision>();
        public event EventHandler onGameObjectAdded;
        public event EventHandler onGameObjectRemove;
        public event EventHandler onPlayerDies;
        public event EventHandler onPlayerHealthDecrement;
        public event EventHandler onEnemyHealthDecrement;
        public Game()
        {
            gameObjectsList = new List<GameObjects>();
        }
        public GameObjects getPlayer()
        {
            foreach(GameObjects i in gameObjectsList)
            {
                if (i.Type == MyEnumTypes.player) return i;
            }
            return null;
        }
        public List<GameObjects> getSpecifiObjectsList(MyEnumTypes type)
        {
            List<GameObjects> enemies = new List<GameObjects>();
            foreach (GameObjects i in gameObjectsList)
            {
                if (i.Type == type)
                {
                    enemies.Add(i);
                }
            }
            return enemies;
        }
        public void addCollision(Collision collision) => collisions.Add(collision);
        public void addGameObject(GameObjects gameObject)
        {
            gameObjectsList.Add(gameObject);
            onGameObjectAdded?.Invoke(gameObject.Pb, EventArgs.Empty);
        }
        public void update()
        {
            detectCollision();
            foreach(GameObjects i in gameObjectsList)
            {
                i.move();
            }
        }
        public void removeGameObject(GameObjects Object)
        {
            gameObjectsList.Remove(Object);
            onGameObjectRemove?.Invoke(Object, EventArgs.Empty);
        }
        public void detectCollision()
        {
            for(int i = 0; i < gameObjectsList.Count; i++)
            {
                for (int j = 0; j < gameObjectsList.Count; j++)
                {
                    if(gameObjectsList[i].Pb.Bounds.IntersectsWith(gameObjectsList[j].Pb.Bounds))
                    {
                        foreach (Collision c in collisions)
                        {
                            if(gameObjectsList[i].Type == c.G1 && gameObjectsList[j].Type == c.G2)
                            {
                                c.Behaviour.performAction(this , gameObjectsList[i] , gameObjectsList[j]);
                            }
                        }
                    }
                }
            }
        }
       public void GameObjectsDie()
        {
            try
            {
                foreach (GameObjects g in gameObjectsList)
                {
                    if (g.IsExists == false)
                    {
                        risePlayerDieEvent(g);
                        removeGameObject(g);
                    }
                }
            }
            catch { }
        }
        public void risePlayerDieEvent(GameObjects Object)
        {
            onGameObjectRemove?.Invoke(Object, EventArgs.Empty);
        }

        public void risePlayerHealthDec(GameObjects player)
        {
            onPlayerHealthDecrement?.Invoke(player, EventArgs.Empty);
        }
        public void riseEnemyHealthDec(GameObjects Enemy)
        {
            onEnemyHealthDecrement?.Invoke(Enemy, EventArgs.Empty);
        }
    }
}
