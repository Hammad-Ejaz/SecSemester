﻿namespace marioGame
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameLoop = new System.Windows.Forms.Timer(this.components);
            this.Lives_lbl = new System.Windows.Forms.Label();
            this.Score_lbl = new System.Windows.Forms.Label();
            this.MaxScore_lbl = new System.Windows.Forms.Label();
            this.Level_lbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GameLoop
            // 
            this.GameLoop.Enabled = true;
            this.GameLoop.Interval = 30;
            this.GameLoop.Tick += new System.EventHandler(this.GameLoop_Tick);
            // 
            // Lives_lbl
            // 
            this.Lives_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lives_lbl.Location = new System.Drawing.Point(12, 9);
            this.Lives_lbl.Name = "Lives_lbl";
            this.Lives_lbl.Size = new System.Drawing.Size(83, 19);
            this.Lives_lbl.TabIndex = 0;
            this.Lives_lbl.Text = "Lives : ";
            // 
            // Score_lbl
            // 
            this.Score_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score_lbl.Location = new System.Drawing.Point(12, 28);
            this.Score_lbl.Name = "Score_lbl";
            this.Score_lbl.Size = new System.Drawing.Size(83, 21);
            this.Score_lbl.TabIndex = 1;
            this.Score_lbl.Text = "Score :";
            // 
            // MaxScore_lbl
            // 
            this.MaxScore_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxScore_lbl.Location = new System.Drawing.Point(12, 49);
            this.MaxScore_lbl.Name = "MaxScore_lbl";
            this.MaxScore_lbl.Size = new System.Drawing.Size(135, 19);
            this.MaxScore_lbl.TabIndex = 2;
            this.MaxScore_lbl.Text = "MaxScore : ";
            // 
            // Level_lbl
            // 
            this.Level_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Level_lbl.Location = new System.Drawing.Point(12, 68);
            this.Level_lbl.Name = "Level_lbl";
            this.Level_lbl.Size = new System.Drawing.Size(83, 19);
            this.Level_lbl.TabIndex = 3;
            this.Level_lbl.Text = "Level : ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1144, 507);
            this.Controls.Add(this.Level_lbl);
            this.Controls.Add(this.MaxScore_lbl);
            this.Controls.Add(this.Score_lbl);
            this.Controls.Add(this.Lives_lbl);
            this.MaximumSize = new System.Drawing.Size(1160, 546);
            this.MinimumSize = new System.Drawing.Size(1160, 546);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer GameLoop;
        private System.Windows.Forms.Label Lives_lbl;
        private System.Windows.Forms.Label Score_lbl;
        private System.Windows.Forms.Label MaxScore_lbl;
        private System.Windows.Forms.Label Level_lbl;
    }
}

