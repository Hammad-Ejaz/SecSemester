﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using marioFrameWork.Core;
using marioFrameWork.Movements;
using marioFrameWork.collisions;
using System.Drawing;
using System.Windows.Forms;
namespace marioGame.MyExtendedBLs
{
    class LiveObjectsBL : GameObjects
    {
        private ProgressBar health;
        private int ResetHealthValue;
        private int lifes;
        public LiveObjectsBL(Image image , int top , int left , Imovement movement , MyEnumTypes type , int health , int lifes):base(image ,top , left , movement , type)
        {
            Pb = new PictureBox();
            this.health = new ProgressBar();
            Pb.Image = image;
            Pb.Width = image.Width;
            Pb.Height = image.Height;
            Pb.BackColor = Color.Transparent;
            Pb.Top = top;
            Pb.Left = left;
            this.Movement = movement;
            this.Type = type;
            this.Lifes = lifes;
            this.Health.Value = health;
            this.ResetHealthValue1 = this.Health.Value;
            healthBarLocationSet();
        }

        public ProgressBar Health { get => health; set => health = value; }
        public int ResetHealthValue1 { get => ResetHealthValue; set => ResetHealthValue = value; }
        public int Lifes { get => lifes; set => lifes = value; }

        public void healthBarLocationSet()
        {
            Point lct = new Point();
            lct.X = Pb.Width / 2;
            lct.Y = Pb.Bottom - 50;
            Health.Location = lct;
            Health.Left = Pb.Left - 30;
            Health.ForeColor = Color.Green;
            Health.Height = 8;
            Health.Width = 50;
        }
    }
}
