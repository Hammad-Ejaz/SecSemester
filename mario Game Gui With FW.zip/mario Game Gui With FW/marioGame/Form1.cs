﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using marioFrameWork.collisions;
using marioFrameWork.Core;
using marioFrameWork.Movements;
using marioGame.MyExtendedBLs;
using marioGame.DL;
namespace marioGame
{
    public partial class Form1 : Form
    {
        private Game g;
        private LiveObjectsBL player;
        private int TimeCount;
        private int EnemyCounter = 500;
        private int Score;
        private int MaxsScore = 20;
        private int Levels = 1;
        private int bonusCount = 490;
        private Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            g = new Game();
            g.onGameObjectAdded += new EventHandler(Game_ObjectsAdded);
            g.onPlayerHealthDecrement += G_onHealthDecrement;
            g.onEnemyHealthDecrement += G_onEnemyHealthDecrement;
            g.onGameObjectRemove += new EventHandler(Game_objectsDies);
            Rectangle boundary = this.Bounds;
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.simpleEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.fireEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bullet, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bonus, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.simpleEnemy, MyEnumTypes.bullet, new simpleEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.fireEnemy, MyEnumTypes.bullet, new fireEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.bonus, MyEnumTypes.bullet, new BonusCollision()));
            player = new LiveObjectsBL(Properties.Resources.mario_move_2, this.Height - 200, 10, new Manual(5, boundary), MyEnumTypes.player, 100, 1);
            g.addGameObject(player);
            addProgressbarIntoControls(player.Health);
            GenerateEnemy();
        }
        private void GenerateEnemy()
        {
            if (EnemyCounter == 5 || EnemyCounter == bonusCount)
            {
                LiveObjectsBL fireEnemyBonus = new LiveObjectsBL(Properties.Resources.fireEnemy, 20, 10, new Horizontal(5, 10, 1000, "left"), MyEnumTypes.bonus, 100, 1);
                g.addGameObject(fireEnemyBonus);
                addProgressbarIntoControls(fireEnemyBonus.Health);
            }
            LiveObjectsBL fireEnemy = new LiveObjectsBL(Properties.Resources.fireEnemy, rand.Next(5, 500), 1160, new Left(1), MyEnumTypes.fireEnemy, 100, 1);
            g.addGameObject(fireEnemy);
            addProgressbarIntoControls(fireEnemy.Health);
            LiveObjectsBL simpleEnemy = new LiveObjectsBL(Properties.Resources.enemy1_left_1, rand.Next(5, 500), 1160, new Left(2), MyEnumTypes.simpleEnemy, 100, 1);
            g.addGameObject(simpleEnemy);
        }
        private void G_onEnemyHealthDecrement(object sender, EventArgs e)
        {
            LiveObjectsBL Enemy = (LiveObjectsBL)sender;
            if (Enemy.Type == MyEnumTypes.bonus)
            {
                if(player.Health.Value < 100) player.Health.Value += 1;
            }
            if (Enemy.Health.Value <= 0)
            {
                Enemy.IsExists = false;
                this.Controls.Remove(Enemy.Health);
            }
            else Enemy.Health.Value -= 1;
        }
        private void G_onHealthDecrement(object sender, EventArgs e)
        {
            LiveObjectsBL player = (LiveObjectsBL)sender;
            if (player.Health.Value <= 0 && player.Lifes > 0)
            {
                player.Health.Value = player.ResetHealthValue1;
                player.Lifes--;
            }
            else if (player.Lifes > 0) player.Health.Value -= 1;
            else if (player.Lifes <= 0) showEndGame();
        }
        private void addProgressbarIntoControls(ProgressBar health) => this.Controls.Add(health);
        private void Game_objectsDies(object sender, EventArgs e)
        {
            GameObjects g = (GameObjects)sender;
            if(g.Type != MyEnumTypes.bullet && g.Type != MyEnumTypes.player) Score += 5;
            this.Controls.Remove(g.Pb);
        }
        private void Game_ObjectsAdded(object sender, EventArgs e)
        {
            this.Controls.Add((PictureBox)sender);
        }
        private void updatePbLocation(MyEnumTypes type)
        {
            LiveObjectsBL enemy;
            foreach(GameObjects i in g.getSpecifiObjectsList(type))
            {
                enemy = (LiveObjectsBL)i;
                enemy.healthBarLocationSet();
            }
        }
        private void GameLoop_Tick(object sender, EventArgs e)
        {
            if(EnemyCounter == 0)
            {
                GenerateEnemy();
                EnemyCounter = 500;
            }
            g.update();
            g.GameObjectsDie();
            player.healthBarLocationSet();
            updatePbLocation(MyEnumTypes.fireEnemy);
            updatePbLocation(MyEnumTypes.bonus);
            FIresDL.PlayerBulltetsFired(g);
            TimeCount += GameLoop.Interval;
            if (TimeCount % 900 == 0)
            {
               FIresDL.EnemyBulletsFires(g);
            }
            FIresDL.RemoveExtraFIres(this.Bounds, g);
            ScoreBoard();
            EnemyCounter--;
            win();
        }
        private bool checkWiningCondition()
        {
            if (MaxsScore < Score) return true;
            return false;
        }
        private void levelChanger()
        {
            if (checkWiningCondition()) Levels++;
        }
        private void ScoreBoard()
        {
            Lives_lbl.Text ="LIVES :" + player.Lifes.ToString();
            Level_lbl.Text = "LEVEL :" + Levels.ToString();
            Score_lbl.Text = "SCORE :" + Score.ToString();
            MaxScore_lbl.Text = "MAX SCORE :" + MaxsScore.ToString();
        }
        private void showEndGame()
        {
            GameLoop.Enabled = false;
            GAME_OVER_FRM game = new GAME_OVER_FRM();
            DialogResult result = game.ShowDialog();
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
            if (result == DialogResult.No)
            {
                restartGame();
            }
        }
        private void restartGame()
        {
            this.Controls.Clear();
            g = new Game();
            Rectangle boundary = this.Bounds;
            g.onGameObjectAdded += new EventHandler(Game_ObjectsAdded);
            g.onPlayerHealthDecrement += G_onHealthDecrement;
            g.onEnemyHealthDecrement += G_onEnemyHealthDecrement;
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.simpleEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.fireEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bullet, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bonus, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.simpleEnemy, MyEnumTypes.bullet, new simpleEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.fireEnemy, MyEnumTypes.bullet, new fireEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.bonus, MyEnumTypes.bullet, new BonusCollision()));
            player = new LiveObjectsBL(Properties.Resources.mario_move_2, this.Height - 200, 10, new Manual(5, boundary), MyEnumTypes.player, 100, 1);
            g.addGameObject(player);
            addProgressbarIntoControls(player.Health);
            GenerateEnemy();
            g.onGameObjectRemove += new EventHandler(Game_objectsDies);
            GameLoop.Enabled = true;
            this.Controls.Add(Lives_lbl);
            this.Controls.Add(Level_lbl);
            this.Controls.Add(Score_lbl);
            this.Controls.Add(MaxScore_lbl);
            Lives_lbl.Text = "LIVES :" + player.Lifes.ToString();
            Level_lbl.Text = "LEVEL :" + Levels.ToString();
            Score_lbl.Text = "SCORE :" + Score.ToString();
            MaxScore_lbl.Text = "MAX SCORE :" + MaxsScore.ToString();
        }
        private void Level2()
        {
            this.Controls.Clear();
            EnemyCounter = 300;
            MaxsScore = 50;
            Levels = 2;
            bonusCount = 300;
            g = new Game();
            Rectangle boundary = this.Bounds;
            g.onGameObjectAdded += new EventHandler(Game_ObjectsAdded);
            g.onPlayerHealthDecrement += G_onHealthDecrement;
            g.onEnemyHealthDecrement += G_onEnemyHealthDecrement;
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.simpleEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.fireEnemy, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bullet, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.player, MyEnumTypes.bonus, new playerCollision()));
            g.addCollision(new Collision(MyEnumTypes.simpleEnemy, MyEnumTypes.bullet, new simpleEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.fireEnemy, MyEnumTypes.bullet, new fireEnemyCollision()));
            g.addCollision(new Collision(MyEnumTypes.bonus, MyEnumTypes.bullet, new BonusCollision()));
            player = new LiveObjectsBL(Properties.Resources.mario_move_2 , this.Height - 200, 10, new Manual(5, boundary), MyEnumTypes.player, 100, 1);
            g.addGameObject(player);
            addProgressbarIntoControls(player.Health);
            GenerateEnemy();
            g.onGameObjectRemove += new EventHandler(Game_objectsDies);
            GameLoop.Enabled = true;
            this.Controls.Add(Lives_lbl);
            this.Controls.Add(Level_lbl);
            this.Controls.Add(Score_lbl);
            this.Controls.Add(MaxScore_lbl);
            Lives_lbl.Text = "LIVES :" + player.Lifes.ToString();
            Level_lbl.Text = "LEVEL :" + Levels.ToString();
            Score_lbl.Text = "SCORE :" + Score.ToString();
            MaxScore_lbl.Text = "MAX SCORE :" + MaxsScore.ToString();
        }
        private void win()
        {
            if (MaxsScore <= Score && Levels < 2)
            {
                levelChanger();
                Level2();
            }
            else if (MaxsScore <= Score && Levels == 2)
            {
                WinFrm win = new WinFrm();
                GameLoop.Enabled = false;
                DialogResult result = win.ShowDialog();
                if (result == DialogResult.Yes)
                {
                    this.Close();
                }
            }
        }
    }
}
