﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EZInput;
using System.Drawing;
using marioFrameWork.Core;
using marioFrameWork.collisions;
using marioFrameWork.Movements;
namespace marioGame.DL
{
    public class FIresDL
    {
        static int count = 0;
        public static void PlayerBulltetsFired(Game g)
        {
            if (count == 10)
            {
                if (Keyboard.IsKeyPressed(Key.Space))
                {
                    GameObjects bullet = new GameObjects(Properties.Resources.playerbullet, g.getPlayer().Pb.Top + g.getPlayer().Pb.Height / 2, g.getPlayer().Pb.Left + 50, new Left(-5), MyEnumTypes.bullet);
                    g.addGameObject(bullet);
                }
                count = 0;
            }
            count++;
        }
        public static void EnemyBulletsFires(Game g)
        {
            foreach (GameObjects i in g.getSpecifiObjectsList(MyEnumTypes.fireEnemy))
            {
                GameObjects bullet = new GameObjects(Properties.Resources.playerbullet, i.Pb.Top + i.Pb.Height / 2, i.Pb.Left - 25, new Left(5), MyEnumTypes.bullet);
                g.addGameObject(bullet);
            }
            foreach (GameObjects i in g.getSpecifiObjectsList(MyEnumTypes.bonus))
            {
                GameObjects bullet = new GameObjects(Properties.Resources.playerbullet, i.Pb.Top + 50, i.Pb.Left + i.Pb.Width / 2 , new FreeFalling(5), MyEnumTypes.bullet);
                g.addGameObject(bullet);
            }
        }
        public static void RemoveExtraFIres(Rectangle bounds , Game g)
        {
            List<GameObjects> bullet = g.getSpecifiObjectsList(MyEnumTypes.bullet);
            for (int i =0; i < bullet.Count; i++)
            {
                if(!bullet[i].Pb.Bounds.IntersectsWith(bounds))
                {

                    g.removeGameObject(bullet[i]);
                }
            }
        }
    }
}
